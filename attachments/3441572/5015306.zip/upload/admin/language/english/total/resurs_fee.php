<?php
// Heading					
$_['heading_title']		      = 'Resurs Bank Fee';
$_['text_total']		      = 'Order Totals';
$_['entry_fee']		      = 'The fee for this payment method without VAT';
$_['entry_sort_order']		      = 'Sort order'; 
$_['entry_fee_tax']		      = 'The fee in %';
$_['text_none']		      = 'None';
$_['entry_invoice_line']		      = 'The invoice line that should appear on the invoice.';

$_['info_table_paymentmethod_id']		      = 'Payment method Id';
$_['info_table_paymentmethod_name']		      = 'Payment method name';
$_['info_table_paymentmethod_fee']		      = 'Fee(Without Tax)';
$_['info_table_paymentmethod_taxclass']		      = 'Tax Class';
$_['info_table_paymentmethod_invoiceline']		      = 'Invoice Line';




?>