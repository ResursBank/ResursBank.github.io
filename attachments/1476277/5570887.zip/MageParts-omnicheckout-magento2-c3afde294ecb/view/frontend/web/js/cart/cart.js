/**
 * Created by Bossehasse on 16/08/16.
 */
define(['jquery'], function () {
    
});