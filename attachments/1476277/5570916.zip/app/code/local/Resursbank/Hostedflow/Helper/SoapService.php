<?php
class Resursbank_Hostedflow_Helper_SoapService extends SoapClient{
    
    public function __construct()
    {
        $soapOptions = array(
            'exceptions' => 1,
            'connection_timeout' => 60,
            'login' => Mage::getStoreConfig('adv_config/credentials/merchantlogin'),
            'password' => Mage::getStoreConfig('adv_config/credentials/merchantpassword'),
            'trace' => 1
        );
        //$wsdl = 'https://test.resurs.com/ecommerce-test/ws/V4/SimplifiedShopFlowService?wsdl';
        $wsdl=Mage::getStoreConfig('payment/hostedflow/wsdl_service_url');

        parent::__construct($wsdl,$soapOptions);
    }
    var $paymentMethodsParameters=array();
    public function getPaymentMethods($parameters)
    {
        return $this->__soapCall('getPaymentMethods', $parameters);
    }
    
    

}