<?php
class Resursbank_Hostedflow_Model_Paymentmethod extends Mage_Payment_Model_Method_Abstract {
    protected $_code  = 'hostedflow';
    protected $_formBlockType = 'hostedflow/form_hostedflow';
    protected $_infoBlockType = 'hostedflow/info_hostedflow';
    public function getOrderPlaceRedirectUrl()
    {
        return Mage::getUrl('resursbank_hostedflow/payment/redirect', array('_secure' => false));
    }
    public function assignData($data)
    {
        $info = $this->getInfoInstance();
        if ($data->getHostedflowPaymentMethodId())
        {
            $info->setHostedflowPaymentMethodId($data->getHostedflowPaymentMethodId());
        }
        return $this;
    }
}