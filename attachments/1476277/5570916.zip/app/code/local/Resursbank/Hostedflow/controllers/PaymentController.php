<?php
class Resursbank_Hostedflow_PaymentController extends Mage_Core_Controller_Front_Action
{
    public function gatewayAction()
    {
        if ($this->getRequest()->get("orderId"))
        {
            $arr_querystring = array(
                'flag' => 1,
                'orderId' => $this->getRequest()->get("orderId")
            );

            Mage_Core_Controller_Varien_Action::_redirect('resursbank_hostedflow/payment/', array('_secure' => false, '_query'=> $arr_querystring));
        }
    }

    public function redirectAction()
    {

        $orderId=Mage::getSingleton('checkout/session')->getLastOrderId();
        $incrementId=Mage::getModel('sales/order')->load($orderId)->getIncrementId();
        $hostedflowUrl=json_decode(Mage::helper('hostedflow')->getHostedflowUrl($orderId,$incrementId),true)['location'];
        if (filter_var($hostedflowUrl, FILTER_VALIDATE_URL) === FALSE) {
            echo Mage::helper('hostedflow')->getHostedflowUrl($orderId,$incrementId);
            die;
        }

        $this->_redirectUrl($hostedflowUrl);
    }

    public function successAction()
    {
        if ($orderId = $this->getRequest()->get("id"))
        {
            $order = Mage::getModel('sales/order')->load($orderId);
            $orderAmount=$order->getGrandTotal();
            $order->setState(Mage_Sales_Model_Order::STATE_PROCESSING, true);
            $order->save();
            Mage::getSingleton('core/session')->addSuccess(Mage::helper('hostedflow')->__(Mage::getStoreConfig('adv_config/messages/success_message')));
            Mage_Core_Controller_Varien_Action::_redirect('checkout/onepage/success', array('_secure'=> false));
        }
    }
    public function failAction()
    {

       if ($orderId = $this->getRequest()->get("id"))
        {
            $order = Mage::getModel('sales/order')->load($orderId);
            $order->setState(Mage_Sales_Model_Order::STATE_CANCELED,true);
            $order->save();
        }
        Mage::getSingleton('core/session')->addError(Mage::helper('hostedflow')->__(Mage::getStoreConfig('adv_config/messages/fail_message')));
        echo $this->getRequest()->get("id");
        $this->_redirect('/');

    }
    public function backAction(){

        if ($orderId = $this->getRequest()->get("id")) {
            $this->_getSession()->clear();
            $order = Mage::getModel('sales/order')->load($orderId);
            if (!Mage::helper('sales/reorder')->canReorder($order)) {
                Mage::getSingleton('core/session')->addError(Mage::helper('hostedflow')->__('Sorry, you cannot reorder this order'));
                $this->_redirect('checkout/cart');
                //return $this->_forward('noRoute');
            }

            if ($order->getId()) {
                $order->setReordered(true);
                $this->_getSession()->setUseOldShippingMethod(true);
                $this->_getOrderCreateModel()->initFromOrder($order);
                //$order = Mage::registry('current_order');

                $cart = Mage::getSingleton('checkout/cart');
                $cartTruncated = false;
                /* @var $cart Mage_Checkout_Model_Cart */

                $items = $order->getItemsCollection();
                foreach ($items as $item) {
                    try {
                        $cart->addOrderItem($item);
                    } catch (Mage_Core_Exception $e) {
                        if (Mage::getSingleton('checkout/session')->getUseNotice(true)) {
                            Mage::getSingleton('checkout/session')->addNotice($e->getMessage());
                        } else {
                            Mage::getSingleton('checkout/session')->addError($e->getMessage());
                        }
                        $this->_redirect('*/*/history');
                    } catch (Exception $e) {
                        Mage::getSingleton('checkout/session')->addException($e,
                            Mage::helper('checkout')->__('Cannot add the item to shopping cart.')
                        );
                        $this->_redirect('checkout/cart');
                    }
                }
                if(!$order->canCancel()) {
                    Mage::getSingleton('checkout/session')->addError('Sorry, we already place order. Please, contact us to cancel it ');
                }
                else {
                    $order->registerCancellation();
                    $order->setState(Mage_Sales_Model_Order::STATE_CANCELED, true);
                    $order->save();
                    $this->_eraseOrder($orderId);
                }


                /*}*/
                $cart->save();

                $this->_redirect('checkout/cart');


            } else {
                $this->_redirect('*/sales_order/');
            }
        }
        else
        {
            $this->_redirect('/');
        }

    }
    protected function _getSession(){
        return Mage::getSingleton('adminhtml/session_quote');
    }
    protected function _getOrderCreateModel()
    {
        return Mage::getSingleton('adminhtml/sales_order_create');
    }
    protected function _eraseOrder($orderId){
        $resource = Mage::getSingleton('core/resource');
        $delete = $resource->getConnection('core_read');
        $tableSfo = $resource->getTableName('sales_flat_order');
        $tableSfog = $resource->getTableName('sales_flat_order_grid');


        $sql = "DELETE FROM " . $tableSfo . " WHERE entity_id = " . $orderId . ";";

        $delete->query($sql);
        $sql = "DELETE FROM  " . $tableSfog . " WHERE entity_id = " . $orderId . ";";
        $delete->query($sql);
    }

}