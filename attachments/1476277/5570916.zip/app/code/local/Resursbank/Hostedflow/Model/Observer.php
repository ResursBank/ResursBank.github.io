<?php
class Resursbank_Hostedflow_Model_Observer {
    public function saveQuoteBefore($observer) {
        $post = Mage::app()->getFrontController()->getRequest()->getPost();
        if(isset($post['payment']['hostedflow_payment_method_id'])){

            $paymentMethodId=$post['payment']['hostedflow_payment_method_id'];
            $quote = $observer->getEvent()->getQuote();
            Mage::helper('hostedflow')->setQuoteData($quote,$paymentMethodId);
        }

    }
  
}