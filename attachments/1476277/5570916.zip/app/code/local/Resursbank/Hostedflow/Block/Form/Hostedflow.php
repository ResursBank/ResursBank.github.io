<?php
class Resursbank_Hostedflow_Block_Form_Hostedflow extends Mage_Payment_Block_Form
{
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('resursbank/form/hostedflow.phtml');
    }
}