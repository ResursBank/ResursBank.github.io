<?php
class Resursbank_Hostedflow_Block_Info_Hostedflow extends Mage_Payment_Block_Info
{
    protected function _prepareSpecificInformation($transport = null)
    {
        if (null !== $this->_paymentSpecificInformation)
        {
            return $this->_paymentSpecificInformation;
        }

        $data = array();
        if ($this->getInfo()->getHostedflowPaymentMethodId())
        {
            $data['hostedflow_payment_method_id'] = $this->getInfo()->getHostedflowPaymentMethodId();
        }
        $transport = parent::_prepareSpecificInformation($transport);

        return $transport->setData(array_merge($data, $transport->getData()));
    }
   
}