<?php
class Resursbank_Hostedflow_Helper_Data extends Mage_Core_Helper_Abstract
{
    function getPaymentGatewayUrl()
    {
        return Mage::getUrl('resursbank_hostedflow/payment/gateway', array('_secure' => false));
    }
    function getHostedflowUrl($orderId,$incrementalOrderId)
    {
        $merchantLogin=Mage::getStoreConfig('adv_config/credentials/merchantlogin');
        $merchantPassword=Mage::getStoreConfig('adv_config/credentials/merchantpassword');
        $serviceUrl=Mage::getStoreConfig('payment/hostedflow/service_url');
        if(Mage::getStoreConfig('adv_config/testing/is_active')){
            $serviceUrl=Mage::getStoreConfig('adv_config/testing/test_mode_url');
        }
        $preparedJson=$this->prepareJSON($orderId,$incrementalOrderId);
        //file_put_contents('rb_hf_log_at_'.now().'.json',$preparedJson);
        $curl=curl_init();
        curl_setopt_array($curl,array(
            CURLOPT_URL=>$serviceUrl,
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>$preparedJson,
            CURLOPT_HEADER=>false,
            CURLOPT_USERPWD => $merchantLogin.':'.$merchantPassword,
            CURLOPT_HTTPHEADER=>array(
                'Content-Type: application/json',
                'HTTP POST '.$serviceUrl
            )
        ));
        $hostedFlowUrl=curl_exec($curl);
        return $hostedFlowUrl;
    }
    function prepareJSON($orderId,$incrementOrderId){
        if($quoteData=Mage::getSingleton('core/session')->getData('quoteData')){
            Mage::getSingleton('core/session')->setData('quoteData','');
            $quoteData['paymentData']['preferredId']=$incrementOrderId;
            $quoteData['waitForFraudControl']=true;
            $quoteData['annulIfFrozen']=false;
            $quoteData['finalizeIfBooked']=false;
            
            $quoteData['successUrl']=Mage::getBaseUrl().'resursbank_hostedflow/payment/success/id/'.$orderId;
            $quoteData['failUrl']=Mage::getBaseUrl().'resursbank_hostedflow/payment/fail/id/'.$orderId;
            $quoteData['backUrl']=Mage::getBaseUrl().'/resursbank_hostedflow/payment/back/id/'.$orderId;
        return json_encode($quoteData);
        }
        return false;
    }
    function setQuoteData($quote,$paymentMethodId){
        $cartItems =$quote->getAllVisibleItems();
        $quoteData=array();
        $paymentData=array();
        //$paymentData['preferredId']=$orderIncrementId;
        $paymentData['paymentMethodId']=$paymentMethodId;
        $quoteData['paymentData']=$paymentData;

        $orderData=array();

        $itemIndex=0;
        $orderLines=array();
        foreach ($cartItems as $item){
            $orderLines[$itemIndex]=$this->setOrderItemData($item);
            $itemIndex++;
        }
        $orderLines[]=$this->setDiscountData($quote);
        $orderLines[]=$this->setShippingData($quote);
        $orderData['orderLines']=$orderLines;
        $orderData['totalAmount']=$quote->getGrandTotal();
        $orderData['totalVatAmount']=$this->getTotalTaxesAmount($cartItems);

        $quoteData['orderData']=$orderData;

        $billingAddress=$quote->getBillingAddress();
        $customerData=array();
        $addressData=array(
            'fullName' => $quote->getCustomerFirstname().' '.$quote->getCustomerLastname(),
            'firstName' => $quote->getCustomerFirstname(),
            'lastName' => $quote->getCustomerLastname(),
            'addressRow1' => is_array($billingAddress->getStreet())?$billingAddress->getStreet()[0]:$billingAddress->getStreet(),
            'addressRow2' => is_array($billingAddress->getStreet())?$billingAddress->getStreet()[1]:'',
            'postalArea' => $billingAddress->getCity(),
            'postalCode' => $billingAddress->getPostcode(),
            'countryCode' => $billingAddress->getCountryId()
        );
        $customerData['address']=$addressData;
        $customerData['phone']=$billingAddress->getTelephone();
        $customerData['email']=$billingAddress->getEmail();
        $customerData['type']='NATURAL';
        $quoteData['customer']=$customerData;
        Mage::getSingleton('core/session')->setData('quoteData',$quoteData);

    }
    function setOrderItemData($item)
    {
        $product = Mage::getModel('catalog/product')->loadByAttribute('sku', $item->getSku());
        $productDescription=$product->getDescription();
        return array(
            'artNo'=>$item->getSku(),
            'description'=>$productDescription,
            'quantity'=>$item->getQty(),
            'unitAmountWithoutVat'=>$item->getPrice(),
            'vatPct'=>$item->getTaxPercent(),
            'totalVatAmount'=>$item->getTaxAmount(),
            'totalAmount'=>$item->getRowTotalInclTax()/*$item->getPriceInclTax()*$item->getQty()*/
        );
    }
    function setShippingData($quote){
        $shippingAmount=$quote->getShippingAddress()->getShippingAmount();
        return array(
            'artNo'=>'shippingArtNo',
            'description'=>'Shipping & Handling',
            'quantity'=>'1.0',
            'unitAmountWithoutVat'=>$shippingAmount,
            'vatPct'=>'0.0',
            'totalVatAmount'=>'0.0',
            'totalAmount'=>$shippingAmount
        );
    }
    function setDiscountData($quote){
       $totalDiscountAmount=$this->getTotalDiscountAmount($quote);
        return array(
            'artNo'=>'discountArtNo',
            'description'=>'Discount',
            'quantity'=>'1.0',
            'unitAmountWithoutVat'=>'-'.$totalDiscountAmount,
            'vatPct'=>'0.0',
            'totalVatAmount'=>'0.0',
            'totalAmount'=>'-'.$totalDiscountAmount
        );

    }
    function getTotalDiscountAmount($quote){
        $shippingDiscount=$quote->getShippingAddress()->getShippingDiscountAmount();
        $quoteItems=$quote->getAllVisibleItems();
        $itemsDiscount=0;
        foreach ($quoteItems as $quoteItem){
            $itemsDiscount+=$quoteItem->getDiscountAmount();
        }
        $totalDiscountAmount=$shippingDiscount+$itemsDiscount;
        return $totalDiscountAmount;
    }
    function getTotalTaxesAmount($items){
        $totalTaxAmount=0;
        foreach ($items as $item){
            $totalTaxAmount+=$item->getTaxAmount();
        }
        return $totalTaxAmount;
    }

}