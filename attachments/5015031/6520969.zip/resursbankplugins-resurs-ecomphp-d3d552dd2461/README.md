# EComPHP - PHP Gateway for Resurs Bank ECommerce Services #

Resurs EComPHP Gateway is a webservice simplifier with functionality for getting started fast. It communicates with the Simplified Flow API for booking payments, Configuration Service and the After Shop Service for finalizing, crediting and annullments, etc.

The current version is set to 1.0.0-beta and since we're continuosly updating the files, the package is delivered as-is.
