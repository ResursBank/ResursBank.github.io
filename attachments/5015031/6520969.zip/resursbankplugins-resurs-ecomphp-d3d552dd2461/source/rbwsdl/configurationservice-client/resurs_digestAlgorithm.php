<?php

if (!class_exists("resurs_digestAlgorithm", false)) 
{
class resurs_digestAlgorithm
{
    const __default = 'MD5';
    const MD5 = 'MD5';
    const SHA1 = 'SHA1';


}

}
