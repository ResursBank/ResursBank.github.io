<?php

if (!class_exists("resurs_sortAlternative", false)) 
{
class resurs_sortAlternative
{
    const __default = 'PAYMENT_ID';
    const PAYMENT_ID = 'PAYMENT_ID';
    const CUSTOMER_GOVERNMENT_ID = 'CUSTOMER_GOVERNMENT_ID';
    const CUSTOMER_NAME = 'CUSTOMER_NAME';
    const BOOKED_TIME = 'BOOKED_TIME';
    const MODIFIED_TIME = 'MODIFIED_TIME';
    const FINALIZED_TIME = 'FINALIZED_TIME';
    const AMOUNT = 'AMOUNT';
    const BONUS_POINTS = 'BONUS_POINTS';


}

}
