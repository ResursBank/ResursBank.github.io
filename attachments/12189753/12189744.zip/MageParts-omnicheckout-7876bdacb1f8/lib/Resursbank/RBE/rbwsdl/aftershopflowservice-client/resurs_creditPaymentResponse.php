<?php

if (!class_exists("resurs_creditPaymentResponse", false)) 
{
class resurs_creditPaymentResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
