<?php

if (!class_exists("resurs_unregisterEventCallbackResponse", false)) 
{
class resurs_unregisterEventCallbackResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
