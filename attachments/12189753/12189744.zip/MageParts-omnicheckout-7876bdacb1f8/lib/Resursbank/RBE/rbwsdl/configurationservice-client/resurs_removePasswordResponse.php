<?php

if (!class_exists("resurs_removePasswordResponse", false)) 
{
class resurs_removePasswordResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
