<?php

class Resursbank_Omnicheckout_Model_Order_Api
{

    /**
     * API client.
     *
     * @var ResursBank
     */
    protected $client;

    /**
     * Retrieve API client.
     *
     * @return ResursBank
     */
    protected function getClient()
    {
        if (is_null($this->client)) {
            $this->injectLoader();
            $this->client = new ResursBank();
        }

        return $this->client;
    }

    protected function injectLoader()
    {
        if (!class_exists('ResursBank')) {
            $file = Mage::getBaseDir() . '/lib/Resursbank/RBE/classes/rbapiloader.php';

            if (!file_exists($file)) {
                throw new Exception("Failed to locate Resursbank Order API library ({$file}). Please contact your developer for support.");
            }

            require_once $file;
        }

        return $this;
    }

    public function getInformation(Mage_Sales_Model_Order $order, $key = null)
    {
        $test = $this->getClient();
        $a = 'asd';
    }



}
