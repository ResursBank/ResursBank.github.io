<?php

/**
 * The original
 *
 * Class Resursbank_Omnicheckout_Model_Rest_Client
 */
class Resursbank_Omnicheckout_Model_Rest_Client extends Zend_Rest_Client
{

    const ENC_JSON = 'application/json';

    /**
     * Custom request enc type.
     *
     * @var string
     */
    protected $customEncType;

    /**
     * Perform a POST or PUT
     *
     * Performs a POST or PUT request. Any data provided is set in the HTTP
     * client. String data is pushed in as raw POST data; array or object data
     * is pushed in as POST parameters.
     *
     * - This extends the original function from Zend_Rest_Client to allow custom enc types, like application/json.
     *
     * @param mixed $method
     * @param mixed $data
     * @return Zend_Http_Response
     * @throws Zend_Http_Client_Exception
     */
    protected function _performPost($method, $data = null)
    {
        $client = self::getHttpClient();

        if (is_null($this->customEncType)) {
            if (is_string($data)) {
                $client->setRawData($data);
            } elseif (is_array($data) || is_object($data)) {
                $client->setParameterPost((array)$data);
            }
        } else {
            $enctype = (string) $this->customEncType;

            if ($enctype === self::ENC_JSON) {
                $client->setRawData(Mage::helper('core')->jsonEncode($data));
                $client->setEncType(self::ENC_JSON);
            } else {
                throw new Zend_Http_Client_Exception("Invalid enctype {$enctype}.");
            }
        }

        return $client->request($method);
    }

    /**
     * Set custom enc type.
     *
     * @param string $val
     * @return $this
     */
    public function setCustomEncType($val)
    {
        $this->customEncType = $val;

        return $this;
    }

}
