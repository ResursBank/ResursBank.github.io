<?php

class Resursbank_Omnicheckout_Model_Payment_Method_Resursbank_Invoice extends Mage_Payment_Model_Method_Abstract
{

    protected $_code  = 'resursbank_invoice';

}
