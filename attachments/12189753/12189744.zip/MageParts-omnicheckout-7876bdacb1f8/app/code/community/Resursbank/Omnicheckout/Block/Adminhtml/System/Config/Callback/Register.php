<?php

/**
 * Class of the button used to register callback URLs.
 *
 * Class Resursbank_Omnicheckout_Block_Adminhtml_System_Config_Callback_Button
 */
class Resursbank_Omnicheckout_Block_Adminhtml_System_Config_Callback_Register extends Mage_Adminhtml_Block_System_Config_Form_Field
{

    /**
     * Render button to update callback URLs.
     *
     * @param Varien_Data_Form_Element_Abstract $element
     * @return mixed
     */
    protected function _getElementHtml(Varien_Data_Form_Element_Abstract $element)
    {
        $this->setElement($element);

        return $this->getLayout()
            ->createBlock('adminhtml/widget_button')
            ->setType('button')
            ->setClass('scalable')
            ->setLabel($this->_getHelper()->__('Update callbacks'))
            ->setOnClick("setLocation('" . $this->getUrl('adminhtml/omnicheckout_config/register') . "')")
            ->toHtml();
    }

    /**
     * Retrieve general helper.
     *
     * @return Resursbank_Omnicheckout_Helper_Callback
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout/callback');
    }

}
