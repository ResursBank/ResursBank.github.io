<?php

/**
 * This class is used to inject custom checkout javascript on the omnicheckout page. Its included through the layout.
 *
 * Class Resursbank_Omnicheckout_Block_Js
 */
class Resursbank_Omnicheckout_Block_Js extends Mage_Core_Block_Template
{

}
