<?php

/**
 * This class is used to render the payment session iframe at checkout.
 *
 * Class Resursbank_Omnicheckout_Block_Css
 */
class Resursbank_Omnicheckout_Block_Iframe extends Mage_Core_Block_Template
{

    /**
     * Retrieve session iframe from API singleton.
     *
     * @return string
     */
    public function getIframe()
    {
        return $this->_getHelper()->getApiModel()->getSessionIframeHtml();
    }

    /**
     * Check if a payment session has been initialized.
     *
     * @return bool
     */
    public function paymentSessionInitialized()
    {
        return $this->_getHelper()->getApiModel()->paymentSessionInitialized();
    }

    /**
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

}
