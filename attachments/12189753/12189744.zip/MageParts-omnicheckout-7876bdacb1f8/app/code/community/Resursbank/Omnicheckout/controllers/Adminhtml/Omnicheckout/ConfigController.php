<?php

/**
 * Actions available from the module system configuration section.
 *
 * Class Resursbank_Omnicheckout_Adminhtml_Omnicheckout_ConfigController
 */
class Resursbank_Omnicheckout_Adminhtml_Omnicheckout_ConfigController extends Mage_Adminhtml_Controller_Action
{

    /**
     * Register callback URLs.
     */
    public function registerAction()
    {
        try {
            $this->_getHelper()->registerApiCallbacks();
        } catch (Exception $e) {
            Mage::getSingleton('adminhtml/session')->addError('The connection to the payment gateway failed and thus we could not register your callback URLs. Please try again in a few minutes.');
        }

        $this->_getHelper()->redirectBack();
    }

    /**
     * Retrieve general helper.
     *
     * @return Resursbank_Omnicheckout_Helper_Callback
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout/callback');
    }

}
