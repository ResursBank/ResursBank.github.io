<?php

/**
 * Handles redirect to Omnicheckout.
 *
 * Class Resursbank_Omnicheckout_Model_Redirect
 * @todo Read through the vanilla checkout/cart controllers properly and test all actions to ensure they work as expected, on CE 1.7 - 1.9.
 */
class Resursbank_Omnicheckout_Model_Api extends Mage_Core_Model_Abstract
{

    /**
     * Name of error log file.
     */
    const ERROR_LOG = 'resurs_api.log';

    /**
     * Test API URL.
     */
    const TEST_URL = 'https://omnitest.resurs.com/';

    /**
     * Production API URL.
     */
    const PRODUCTION_URL = 'https://checkout.resurs.com/';

    /**
     * Key in checkout/session where we store the payment session id provided by the API.
     */
    const PAYMENT_SESSION_ID_KEY = 'omnicheckout_payment_session_id';

    /**
     * Key in checkout/session where we store the resulting iframe provided by the API when we initialize a new session.
     */
    const PAYMENT_SESSION_IFRAME_KEY = 'omnicheckout_payment_session_iframe';

    /**
     * Initialize payment session.
     *
     * @return stdClass
     * @throws Exception
     */
    public function initPaymentSession()
    {
        // Collect data submitted in the API request.
        $data = array(
            'orderLines' => $this->getOrderLines(),
            'successUrl' => $this->getSuccessCallbackUrl(),
            'backUrl'    => $this->getFailureCallbackUrl(),
            'shopUrl'    => $this->getShopUrl(),
            'customer'   => $this->getCustomerInformation()
        );

        // Allows observers to modify the data submitted to the API.
        Mage::dispatchEvent(
            'omnicheckout_api_init_session_before',
            array(
                'data'  => $data,
                'quote' => $this->getQuote()
            )
        );

        // Perform API request.
        $result = $this->call("checkout/payments/{$this->getQuoteToken(true)}", 'post', $data);

        // Allows observers to perform actions based on API response.
        Mage::dispatchEvent(
            'omnicheckout_api_init_session_after',
            array(
                'data'      => $data,
                'response'  => $result,
                'quote'     => $this->getQuote()
            )
        );

        // Handle API response.
        $result = @json_decode($result);

        if (!is_object($result) || !isset($result->paymentSessionId) || !isset($result->html)) {
            throw new Exception($this->_getHelper()->__('Failed to create payment session, unexpected return value.'));
        }

        $this->_getHelper()->getCheckoutSession()->setData(self::PAYMENT_SESSION_ID_KEY, $result->paymentSessionId);
        $this->_getHelper()->getCheckoutSession()->setData(self::PAYMENT_SESSION_IFRAME_KEY, $result->html);

        return $result;
    }

    /**
     * Update existing payment session.
     *
     * @return Zend_Http_Response
     * @throws Exception
     */
    public function updatePaymentSession()
    {
        if (!$this->paymentSessionInitialized()) {
            throw new Exception("Please initialize your payment session before you updating it.");
        }

        $data = array(
            'orderLines' => $this->getOrderLines()
        );

        // Allows observers to modify the data submitted to the API.
        Mage::dispatchEvent(
            'omnicheckout_api_update_session_before',
            array(
                'data'  => $data,
                'quote' => $this->getQuote()
            )
        );

        // Perform API request.
        $result = $this->call("checkout/payments/{$this->getQuoteToken()}", 'put', $data);

        // Allows observers to perform actions based on API response.
        Mage::dispatchEvent(
            'omnicheckout_api_update_session_after',
            array(
                'data'      => $data,
                'response'  => $result,
                'quote'     => $this->getQuote()
            )
        );

        return $result;
    }

    /**
     * Retrieve completed payment by quote id.
     *
     * @param $quoteToken
     * @return stdClass
     */
    public function getPayment($quoteToken)
    {
        // Allows observers to take actions before performing the API request.
        Mage::dispatchEvent(
            'omnicheckout_api_get_session_before',
            array(
                'quote_token' => $quoteToken
            )
        );

        $result = $this->call("checkout/payments/{$quoteToken}", 'get');

        // Allows observers to perform actions based on API response.
        Mage::dispatchEvent(
            'omnicheckout_api_get_session_after',
            array(
                'response'    => $result,
                'quote_token' => $quoteToken
            )
        );

        if (!empty($result)) {
            $result = @json_decode($result);
        }

        return $result;
    }

    /**
     * Delete active payment session.
     *
     * @return Zend_Http_Response
     */
    public function deletePaymentSession()
    {
        // Allows observers to take actions before performing the API request.
        Mage::dispatchEvent(
            'omnicheckout_api_delete_session_before',
            array(
                'quote' => $this->getQuote()
            )
        );

        $result = $this->call("checkout/payments/{$this->getQuoteToken()}", 'delete');

        // Allows observers to perform actions based on API response.
        Mage::dispatchEvent(
            'omnicheckout_api_delete_session_after',
            array(
                'response'  => $result,
                'quote'     => $this->getQuote()
            )
        );

        return $result;
    }

    /**
     * Register all callback methods.
     *
     * @return $this
     */
    public function registerCallbacks()
    {
        // Register all callbacks.
        $this->registerTestCallback();
        $this->registerCallback('unfreeze');
        $this->registerCallback('automatic_fraud_control');
        $this->registerCallback('annulment');
        $this->registerCallback('finalization');
//        $this->registerCallback('update');
        $this->registerCallback('booked');

        return $this;
    }

    /**
     * Register callback configuration.
     *
     * Available callbacks:
     *
     *  UNFREEZE
     *  AUTOMATIC_FRAUD_CONTROL
     *  TEST
     *  ANNULMENT
     *  FINALIZATION
     *  UPDATE
     *  BOOKED
     *
     * @param string $type
     * @return Zend_Http_Response
     * @todo basic_username and basic_password should be tested (.htpasswd)
     */
    public function registerCallback($type)
    {
        $type = strtolower((string) $type);

        return $this->call($this->getCallbackTypePath($type), 'post', array(
            'uriTemplate' => Mage::getUrl("omnicheckout/callback/{$type}"),
            'basicAuthUserName' => Mage::helper('omnicheckout/callback')->getCallbackSetting('basic_username'),
            'basicAuthPassword' => Mage::helper('omnicheckout/callback')->getCallbackSetting('basic_password')
        ));
    }

    /**
     * Register test callback. This will only work while we are in test mode.
     *
     * @return $this
     */
    public function registerTestCallback()
    {
        // The test callback should only be registered when we are in test mode.
        if ($this->isInTestMode()) {
            $this->registerCallback('test');
        }

        return $this;
    }

    /**
     * Retrieve callback configuration.
     *
     * Available callbacks:
     *
     *  UNFREEZE
     *  AUTOMATIC_FRAUD_CONTROL
     *  TEST
     *  ANNULMENT
     *  FINALIZATION
     *  UPDATE
     *  BOOKED
     *
     * @param string $type
     * @return Zend_Http_Response
     */
    public function getCallback($type)
    {
        return $this->call($this->getCallbackTypePath($type), 'get');
    }

    /**
     * Get list of all registered callbacks.
     *
     * @return array
     */
    public function getCallbacks()
    {
        $result = $this->call('callbacks', 'get');

        if (is_string($result) && !empty($result)) {
            $result = @json_decode($result);
        }

        if (!is_array($result)) {
            $result = array();
        }

        return $result;
    }

    /**
     * Retrieve the URL path to a callback on Resursbank servers (the actual callback name should be all uppercase).
     *
     * @param string $type
     * @return string
     */
    public function getCallbackTypePath($type)
    {
        return 'callbacks/' . strtoupper((string) $type);
    }

    /**
     * Perform API call.
     *
     * If it's ever necessary to urlencode data sent to the API please refer to the urlencodeArray() method in
     * Helper\Data.php
     *
     * @param string $action
     * @param string $method (post|put|delete|get)
     * @param string|array $data
     * @return Zend_Http_Response
     * @throws Exception
     * @throws Zend_Http_Client_Exception
     */
    public function call($action, $method, $data = null)
    {
        $this->validateCallMethod($method);

        /** @var Resursbank_Omnicheckout_Model_Rest_Client $client */
        $client = $this->prepareClient();

        try {
            // Perform API call.
            $response = $this->handleCall($client, $method, "/{$action}", $data);
        } catch (Exception $e) {
            // Clear the payment session, ensuring that a new session will be started once the API is reachable again.
            $this->_getHelper()->clearPaymentSession();

            // Throw the error forward.
            throw $e;
        }

        // Handle potential errors.
        $this->handleErrors($response);

        return $response->getBody();
    }

    /**
     * This method should never be called directly, only through call().
     *
     * @param Resursbank_Omnicheckout_Model_Rest_Client $client
     * @param string $method
     * @param string $path
     * @param string|null $data
     * @return Zend_Http_Response
     */
    private function handleCall(Resursbank_Omnicheckout_Model_Rest_Client $client, $method, $path, $data = null)
    {
        $result = null;

        if ($method === 'post') {
            $result = $client->setCustomEncType(Resursbank_Omnicheckout_Model_Rest_Client::ENC_JSON)
                ->restPost($path, $data);
        } else if ($method === 'put') {
            $result = $client->setCustomEncType(Resursbank_Omnicheckout_Model_Rest_Client::ENC_JSON)
                ->restPut($path, $data);
        } else if ($method === 'get') {
            $result = $client->restGet($path, $data);
        } else if ($method === 'delete') {
            $result = $client->restDelete($path, $data);
        }

        return $result;
    }

    /**
     * Prepare API client.
     *
     * @return Resursbank_Omnicheckout_Model_Rest_Client
     * @throws Zend_Http_Client_Exception
     */
    public function prepareClient()
    {
        $client = new Resursbank_Omnicheckout_Model_Rest_Client($this->getApiUrl());
        $client->getHttpClient()->setAuth($this->getUsername(), $this->getPassword());

        return $client;
    }

    /**
     * Validate API request method.
     *
     * @param string $method
     * @return $this
     * @throws Exception
     */
    public function validateCallMethod($method)
    {
        if ($method !== 'get' && $method !== 'put' && $method !== 'post' && $method !== 'delete') {
            throw new Exception($this->_getHelper()->__('Invalid API method requested.'));
        }

        return $this;
    }

    /**
     * Retrieve iframe of current payment session from checkout/session.
     *
     * @return string
     */
    public function getSessionIframeHtml()
    {
        return (string) $this->_getHelper()->getCheckoutSession()->getData(self::PAYMENT_SESSION_IFRAME_KEY);
    }

    /**
     * Handle errors on response object.
     *
     * @param Zend_Http_Response $response
     * @return $this
     * @throws Exception
     * @todo Maybe this could do more? Perhaps there are errors which aren't considered by $response->isError()?
     */
    public function handleErrors(Zend_Http_Response $response)
    {
        if ($response->isError()) {
            // Log the error.
            Mage::log(($response->getStatus() . ': ' . $response->getMessage() . '. Complete error: ' . PHP_EOL . $response->getBody()), null, self::ERROR_LOG, $this->getApiSetting('debug_enabled', true));

            // Get readable error message.
            $error = $this->_getHelper()->__('We apologize, an error occurred while communicating with the payment gateway. Please contact us as soon as possible so we can review this problem.');

            // Add error to message stack.
            Mage::getSingleton('core/session')->addError($error);

            // Stop script.
            throw new Exception($error);
        }

        return $this;
    }

    /**
     * Retrieve payment session id.
     *
     * @return string
     * @throws Exception
     */
    public function getPaymentSessionId()
    {
        return (string) $this->_getHelper()->getCheckoutSession()->getData(self::PAYMENT_SESSION_ID_KEY);
    }

    /**
     * Retrieve quote token.
     *
     * @param bool $refresh
     * @return int
     * @throws Exception
     */
    public function getQuoteToken($refresh = false)
    {
        if (!$this->getQuote()) {
            throw new Exception($this->_getHelper()->__('Missing quote object.'));
        }

        return $this->_getHelper()->getQuoteToken($this->getQuote(), $refresh);
    }

    /**
     * Shorthand to get current quote object.
     *
     * @return Mage_Sales_Model_Quote
     */
    public function getQuote()
    {
        return $this->_getHelper()->getQuote();
    }

    /**
     * Check if a payment session has been initialized.
     *
     * @return bool
     * @throws Exception
     */
    public function paymentSessionInitialized()
    {
        return (bool) $this->getPaymentSessionId();
    }

    /**
     * Get a setting from the API configuration.
     *
     * @param string $key
     * @param bool $flag
     * @return mixed
     */
    public function getApiSetting($key, $flag = false)
    {
        $key = (string) $key;

        return !$flag ? Mage::getStoreConfig("omnicheckout/api/{$key}", $this->_getHelper()->getStoreId()) : Mage::getStoreConfigFlag("omnicheckout/api/{$key}", $this->_getHelper()->getStoreId());
    }

    /**
     * Check if API is in development/test mode.
     *
     * @return bool
     */
    public function isInTestMode()
    {
        return $this->getApiSetting('test_mode');
    }

    /**
     * Retrieve API username.
     *
     * @return string
     */
    public function getUsername()
    {
        return (string) $this->getApiSetting('username');
    }

    /**
     * Retrieve API password.
     *
     * @return string
     */
    public function getPassword()
    {
        return (string) $this->getApiSetting('password');
    }

    /**
     * Retrieve API URL.
     *
     * @param string $action
     * @return string
     */
    public function getApiUrl($action = '')
    {
        return $this->isInTestMode() ? (self::TEST_URL . $action) : (self::PRODUCTION_URL . $action);
    }

    /**
     * Retrieve order lines submitted to the API with initialize / update requests.
     *
     * @return array
     * @throws Exception
     */
    public function getOrderLines()
    {
        $data = $this->getProductLines();

        // Add discount row to order lines.
        $discount = $this->getDiscountLine();

        if (count($discount)) {
            $data[] = $discount;
        }

        // Add shipping cost row to order lines.
        $shipping = $this->getShippingLine();

        if (count($shipping)) {
            $data[] = $shipping;
        }

        return $data;
    }

    /**
     * Retrieve order line for discount amount.
     *
     * @return array
     */
    public function getDiscountLine()
    {
        $result = array();

        $amount = (float) ($this->getQuote()->getSubtotal() - $this->getQuote()->getSubtotalWithDiscount());

        if ($amount > 0) {
            $name = 'Discount';
            $code = (string) $this->getQuote()->getCouponCode();

            if (strlen($code)) {
                $name.= ' (%s)';
            }

            $result = array(
                'artNo'                 => $code ? $code : 'discount',
                'description'           => $this->_getHelper()->__($name, array($code)),
                'quantity'              => 1,
                'unitMeasure'           => 'pcs',
                'unitAmountWithoutVat'  => -$amount,
                'vatPct'                => 0
            );
        }

        return $result;
    }

    /**
     * Retrieve order line for shipping amount.
     *
     * @return array
     */
    public function getShippingLine()
    {
        $result = array();

        $amount = (float) $this->getQuote()->getShippingAddress()->getShippingAmount();

        if ($amount > 0) {
            $result = array(
                'artNo'                 => 'shipping',
                'description'           => $this->_getHelper()->__('Shipping'),
                'quantity'              => 1,
                'unitMeasure'           => 'pcs',
                'unitAmountWithoutVat'  => $amount,
                'vatPct'                => $this->getShippingTax()
            );
        }

        return $result;
    }

    /**
     * Retrieve shipping tax percentage from quote.
     *
     * @return float|int
     */
    public function getShippingTax()
    {
        $result = 0;

        $inclTax = (float) $this->getQuote()->getShippingAddress()->getShippingInclTax();
        $exclTax = (float) $this->getQuote()->getShippingAddress()->getShippingAmount();

        if ($inclTax > $exclTax) {
            $result = ((($inclTax / $exclTax) - 1) * 100);
        }

        return $result;
    }

    /**
     * Retrieve array of all order lines in quote.
     *
     * @return array
     * @throws Exception
     */
    public function getProductLines()
    {
        $result = array();

        $items = $this->getQuote()->getAllItems();

        if (!count($items)) {
            throw new Exception($this->_getHelper()->__('No items in shopping cart.'));
        }

        /** @var Mage_Sales_Model_Quote_Item $item */
        foreach ($items as $item) {
            if ($this->validateProductLine($item)) {
                $result[] = $this->getProductLine($item);
            }
        }

        return $result;
    }

    /**
     * Validate product before including it in product lines sent to Resursbank.
     *
     * @param Mage_Sales_Model_Quote_Item $item
     * @return array|bool
     */
    public function validateProductLine(Mage_Sales_Model_Quote_Item $item)
    {
        $result = ((float) $item->getQty() > 0 && !$item->getParentItem());

        if ($item->getProductType() === 'configurable') {
            $result = $item->getChildren();
        }

        return $result;
    }

    /**
     * Convert Mage_Sales_Model_Quote_Item to an order line for the API.
     *
     * @param Mage_Sales_Model_Quote_Item $item
     * @return array
     */
    public function getProductLine(Mage_Sales_Model_Quote_Item $item)
    {
        return array(
            'artNo'                 => $item->getSku(),
            'description'           => $item->getName(),
            'quantity'              => (float) $item->getQty(),
            'unitMeasure'           => $this->getApiSetting('weight_unit'),
            'unitAmountWithoutVat'  => (float) $item->getPrice(),
            'vatPct'                => (float) $item->getTaxPercent()
        );
    }

    /**
     * Retrieve customer information used when initializing a payment session.
     *
     * @return array
     */
    public function getCustomerInformation()
    {
        return array(
            'mobile' => $this->getCustomer()->getPrimaryBillingAddress() ? $this->getCustomer()->getPrimaryBillingAddress()->getData('telephone') : null,
            'email'  => $this->getCustomer()->getData('email')
        );
    }

    /**
     * Get the currently logged in customer.
     *
     * @return Mage_Customer_Model_Customer
     */
    public function getCustomer()
    {
        return Mage::getSingleton('customer/session')->getCustomer();
    }

    /**
     * Retrieve shop url (used for iframe communication, the return value will be the target origin). Basically this is
     * your Magento websites protocol:domain without any trailing slashes. For example http://www.testing.com
     *
     * @return string
     */
    public function getShopUrl()
    {
        return rtrim(Mage::getBaseUrl(), '/');
    }

    /**
     * Retrieve iframe protocol:domain. This is used for iframe communication (from JavaScript). This follows the same
     * rules as getShopUrl() above, so no trailing slashes (e.g https://resursbank.com)
     *
     * @return string
     */
    public function getIframeUrl()
    {
        return rtrim($this->getApiUrl(), '/');
    }

    /**
     * Retrieve URL for order success callback from API.
     *
     * @return string
     */
    public function getSuccessCallbackUrl()
    {
        return Mage::getUrl('checkout/onepage/success');
    }

    /**
     * Retrieve URL for order failure callback from API.
     *
     * @return string
     */
    public function getFailureCallbackUrl()
    {
        return Mage::getUrl('checkout/onepage/failure');
    }

    /**
     * Check if we have credentials for the API.
     *
     * @return bool
     */
    public function hasCredentials()
    {
        $username = $this->getApiSetting('username');
        $password = $this->getApiSetting('password');

        return (!empty($username) && !empty($password));
    }

    /**
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

}
