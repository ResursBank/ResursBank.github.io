<?php

require_once Mage::getModuleDir('controllers', 'Mage_Checkout') . DS . 'OnepageController.php';

class Resursbank_Omnicheckout_IndexController extends Mage_Checkout_OnepageController
{

    /**
     * @return Mage_Checkout_OnepageController
     */
    public function preDispatch()
    {
        $action = Mage::app()->getRequest()->getActionName();

        if ($action === 'saveBilling') {
            $this->_parseJsonParameter('billing');
        } else if ($action === 'saveShipping') {
            $this->_parseJsonParameter('shipping');
        } else if ($action === 'saveOrder') {
            $this->_parseJsonParameter('agreement');
        } else if ($action === 'savePayment') {
            $this->_parseJsonParameter('payment');
            $this->_correctPaymentMethod();
        }

        return parent::preDispatch();
    }

    /**
     * Index action, sets default address information. starts payment session.
     */
    public function indexAction()
    {
        if (!$this->_getHelper()->getApiModel()->paymentSessionInitialized()) {
            try {
                // Assign default address information.
                $this->_assignDefaultAddressInformationToQuote();

                // Assign default payment method.
                $this->_assignDefaultPaymentMethod();

                // Assign default shipping method.
                $this->_assignDefaultShippingMethod();

                // Initialize payment session (if needed).
                $this->_getHelper()->initPaymentSession();
            } catch (Exception $e) {
                // Do nothing.
            }
        }

        // Run parent action.
        parent::indexAction();
    }

    /**
     * Save order object.
     *
     * Expected parameters:
     *
     *  'agreement' => [
     *      '2' => '1' // Required if there are any agreements setup.
     *  ];
     */
    public function saveOrderAction()
    {
        if ($this->_expireAjax()) {
            return;
        }

        $result = Mage::helper('omnicheckout/ajax')->getActionResultShell();

        try {
            if (!$this->_validateFormKey()) {
                Mage::throwException('Invalid form key');
            }

            // Collect totals on quote (must proceed order saving).
            $this->getOnepage()->getQuote()->collectTotals();

            // Run parent action.
            parent::saveOrderAction();

            // Extract errors form response body (from parent function).
            $errors = $this->_extractErrorsFromParentResponseBody($this->getResponse()->getBody());

            if (count($errors)) {
                $result['message']['error'] = $errors;
            } else {
                // Render and append updated checkout elements to $result.
                $this->_renderUpdatedElements($result);

                // Clear redirect and collect messages.
                Mage::helper('omnicheckout/ajax')->collectMessages($result['message']);

                // Clear payment session information from checkout session.
                $this->_getHelper()->clearPaymentSession();
            }
        } catch (Exception $e) {
            $result['message']['error'][] = $e->getMessage();
        }

        // Correct response headers.
        Mage::helper('omnicheckout/ajax')->correctResponseHeaders($this);

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Zend_Json::encode($result));
    }

    /**
     * Store billing address on quote object.
     *
     * Expected parameters:
     *
     *  'billing' => [
     *      'company'           => '',                  // Optional
     *      'email'             => 'test@info.com',     // Required
     *      'street'            => [
     *          'First street line', 'Second street line'
     *      ],                                          // Required
     *      'vat_id'            => '',                  // Optional
     *      'city'              => 'New York',          // Required
     *      'region'            => 'New York',          // Optional
     *      'postcode'          => '12312',             // Required
     *      'telephone'         => '123123123',         // Required
     *      'fax'               => '',                  // Optional
     *      'firstname'         => 'Carl',              // Required
     *      'lastname'          => 'Jan',               // Required
     *      'country_id'        => 'se'                 // Required,
     *      'use_for_shipping'  => 1                    // Set this to use the same information for the shipping address.
     *  ];
     */
    public function saveBillingAction()
    {
        if ($this->_expireAjax()) {
            return;
        }

        $result = Mage::helper('omnicheckout/ajax')->getActionResultShell();

        try {
            if (!$this->_validateFormKey()) {
                Mage::throwException('Invalid form key');
            }

            // Run parent action.
            parent::saveBillingAction();

            // Extract errors form response body (from parent function).
            $errors = $this->_extractErrorsFromParentResponseBody($this->getResponse()->getBody());

            if (count($errors)) {
                $result['message']['error'] = $errors;
            } else {
                // Render and append updated checkout elements to $result.
                $this->_renderUpdatedElements($result);

                // Clear redirect and collect messages.
                Mage::helper('omnicheckout/ajax')->collectMessages($result['message']);
            }
        } catch (Exception $e) {
            $result['message']['error'][] = $e->getMessage();
        }

        // Correct response headers.
        Mage::helper('omnicheckout/ajax')->correctResponseHeaders($this);

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Zend_Json::encode($result));
    }

    /**
     * Store shipping address on quote object:
     *
     * Expected parameters:
     *
     *  'shipping' => [
     *      'company'       => '',                  // Optional
     *      'street'        => [
     *          'First street line', 'Second street line'
     *      ],                                      // Required
     *      'vat_id'        => '',                  // Optional
     *      'city'          => 'New York',          // Required
     *      'region'        => 'New York',          // Optional
     *      'postcode'      => '12312',             // Required
     *      'telephone'     => '123123123',         // Required
     *      'fax'           => '',                  // Optional
     *      'firstname'     => 'Carl',              // Required
     *      'lastname'      => 'Jan',               // Required
     *      'country_id'    => 'se'                 // Required
     *  ];
     */
    public function saveShippingAction()
    {
        if ($this->_expireAjax()) {
            return;
        }

        $result = Mage::helper('omnicheckout/ajax')->getActionResultShell();

        try {
            if (!$this->_validateFormKey()) {
                Mage::throwException('Invalid form key');
            }

            // Append telephone number to shipping address information. No telephone field exist for shipping address.
            $this->_appendTelephoneNumberToShippingAddress();

            // Run parent action.
            parent::saveShippingAction();

            // Extract errors form response body (from parent function).
            $errors = $this->_extractErrorsFromParentResponseBody($this->getResponse()->getBody());

            if (count($errors)) {
                $result['message']['error'] = $errors;
            } else {
                // Render and append updated checkout elements to $result.
                $this->_renderUpdatedElements($result);

                // Clear redirect and collect messages.
                Mage::helper('omnicheckout/ajax')->collectMessages($result['message']);
            }
        } catch (Exception $e) {
            $result['message']['error'][] = $e->getMessage();
        }

        // Correct response headers.
        Mage::helper('omnicheckout/ajax')->correctResponseHeaders($this);

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Zend_Json::encode($result));
    }

    /**
     * Store payment method on quote.
     *
     * Expected parameters:
     *
     *  'payment' => [
     *      'method' => 'checkmo' // Required
     *  ];
     */
    public function savePaymentAction()
    {
        if ($this->_expireAjax()) {
            return;
        }

        $result = Mage::helper('omnicheckout/ajax')->getActionResultShell();

        try {
            if (!$this->_validateFormKey()) {
                Mage::throwException('Invalid form key');
            }

            // Run parent action.
            parent::savePaymentAction();

            // Extract errors form response body (from parent function).
            $errors = $this->_extractErrorsFromParentResponseBody($this->getResponse()->getBody());

            if (count($errors)) {
                $result['message']['error'] = $errors;
            } else {
                // Render and append updated checkout elements to $result.
                $this->_renderUpdatedElements($result);

                // Clear redirect and collect messages.
                Mage::helper('omnicheckout/ajax')->collectMessages($result['message']);
            }
        } catch (Exception $e) {
            $result['message']['error'][] = $e->getMessage();
        }

        // Correct response headers.
        Mage::helper('omnicheckout/ajax')->correctResponseHeaders($this);

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Zend_Json::encode($result));
    }

    /**
     * Store shipping method on quote.
     *
     * Expected parameters:
     *
     *  'shipping_method' => 'flatrate_flatrate' // Required
     */
    public function saveShippingMethodAction()
    {
        if ($this->_expireAjax()) {
            return;
        }

        $result = Mage::helper('omnicheckout/ajax')->getActionResultShell();

        try {
            if (!$this->_validateFormKey()) {
                Mage::throwException('Invalid form key');
            }

            // Run parent action.
            parent::saveShippingMethodAction();

            // Extract errors form response body (from parent function).
            $errors = $this->_extractErrorsFromParentResponseBody($this->getResponse()->getBody());

            if (count($errors)) {
                $result['message']['error'] = $errors;
            } else {
                // Render and append updated checkout elements to $result.
                $this->_renderUpdatedElements($result);

                // Clear redirect and collect messages.
                Mage::helper('omnicheckout/ajax')->collectMessages($result['message']);
            }
        } catch (Exception $e) {
            $result['message']['error'][] = $e->getMessage();
        }

        // Correct response headers.
        Mage::helper('omnicheckout/ajax')->correctResponseHeaders($this);

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Zend_Json::encode($result));
    }
    
    /**
     * Extract errors from parent function response body (useful to extract errors when applying billing/shipping
     * address).
     *
     * @param string $body
     * @return array
     */
    public function _extractErrorsFromParentResponseBody($body)
    {
        $result = array();

        $data = Mage::helper('core')->jsonDecode($body);

        if (is_array($data) && isset($data['error'])) {
            if (is_int($data['error'])) {
                if (isset($data['message'])) {
                    $result = is_array($data['message']) ? $data['message'] : (array) $data['message'];
                }
            } else if (is_string($data['error'])) {
                $result[] = $data['error'];
            } else if (is_bool($data['error'])) {
                if ($data['error'] && isset($data['error_messages'])) {
                    $result = is_array($data['error_messages']) ? $data['error_messages'] : (array) $data['error_messages'];
                }
            }
        }

        return $result;
    }

    /**
     * Render all (relevant) blocks that has been changed.
     *
     * @param array $result
     * @return $this
     */
    public function _renderUpdatedElements(array &$result)
    {
        if (isset($result['elements'])) {
            $this->loadLayout();

            $elements = $this->_getHelper()->renderCheckoutElements($this->getLayout(), true);

            if (count($elements)) {
                $result['elements'] = $elements;
            }
        }

        return $this;
    }

    /**
     * Assign default address information to the quote object.
     *
     * @return $this
     */
    public function _assignDefaultAddressInformationToQuote()
    {
        if ($this->_getHelper()->quoteIsMissingAddress()) {
            $this->_getHelper()->quoteAssignDefaultAddress();
        }

        return $this;
    }

    /**
     * Assign default shipping method (this only applies if there is only one shipping method available).
     *
     * @return $this
     * @throws Exception
     */
    public function _assignDefaultShippingMethod()
    {
        if ($this->_getHelper()->getQuote()) {
            $this->_getHelper()->getQuote()->getShippingAddress()->collectShippingRates()->save();

            $methods = $this->_getHelper()->getQuote()->getShippingAddress()->getGroupedAllShippingRates();

            // @todo I'm not sure if this can cause any problems, we shold try this with various configurations to find out for sure.
            if (count($methods) === 1) {
                foreach ($methods as $code => $method) {
                    if (is_array($method) && isset($method[0])) {
                        $this->getOnepage()->saveShippingMethod($method[0]->getCode());
                        $this->getOnepage()->getQuote()->collectTotals()->save();
                    }
                }
            }
        }

        return $this;
    }

    /**
     * Assign default payment method (this ensures that all shipping methods are accurately displayed for some reason).
     *
     * @return $this
     */
    public function _assignDefaultPaymentMethod()
    {
        $this->getOnepage()->savePayment(array(
            'method' => 'resursbank_default'
        ));

        return $this;
    }

    /**
     * Convert a stringified JSON parameter to an array.
     *
     * @param string $parameter
     * @return $this
     */
    public function _parseJsonParameter($parameter)
    {
        $parameter = (string) $parameter;
        $parameters = Mage::app()->getRequest()->getParams();

        if (isset($parameters[$parameter])) {
            Mage::app()->getRequest()->setParam($parameter, (array) json_decode($parameters[$parameter]));
            Mage::app()->getRequest()->setPost($parameter, (array) json_decode($parameters[$parameter]));
        }

        return $this;
    }

    /**
     * Correct the name of the submitted payment method.
     *
     * @return $this
     */
    public function _correctPaymentMethod()
    {
        $param = Mage::app()->getRequest()->getParam('payment');

        if (is_array($param) && isset($param['method'])) {
            $method = 'resursbank_default';

            $code = str_replace(' ', '_',  strtolower((string) $param['method']));

            $translate = array(
                'resurskort'    => 'card',
                'faktura'       => 'invoice',
                'kort'          => 'netscard',
                'nytt_kort'     => 'newcard',
                'delbetalning'  => 'partpayment'
            );

            if (array_key_exists($code, $translate)) {
                $code = $translate[$code];

                $paymentMethod = Mage::getModel("omnicheckout/payment_method_resursbank_{$code}");

                if ($paymentMethod) {
                    $method = "resursbank_{$code}";
                }
            }

            Mage::app()->getRequest()->setParam('payment', array('method' => $method));
            Mage::app()->getRequest()->setPost('payment', array('method' => $method));
        }

        return $this;
    }

    /**
     * Append telephone number to shipping address, copying the one applied for billing address. This is re required
     * since there is no telephone field for the shipping address in the firame form.
     *
     * @return $this
     */
    public function _appendTelephoneNumberToShippingAddress()
    {
        $address = Mage::app()->getRequest()->getParam('shipping');

        if (!isset($address['telephone']) && $this->getOnepage()->getQuote() && $this->getOnepage()->getQuote()->getBillingAddress()) {
            $address['telephone'] = $this->getOnepage()->getQuote()->getBillingAddress()->getData('telephone');

            Mage::app()->getRequest()->setParam('shipping', $address);
            Mage::app()->getRequest()->setPost('shipping', $address);
        }

        return $this;
    }

    /**
     * Retrieve general helper.
     *
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

}
