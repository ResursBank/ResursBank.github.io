<?php

if (!class_exists("resurs_peekInvoiceSequence", false)) 
{
class resurs_peekInvoiceSequence
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
