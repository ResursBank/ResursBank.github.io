<?php

if (!class_exists("resurs_additionalDebitOfPaymentResponse", false)) 
{
class resurs_additionalDebitOfPaymentResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
