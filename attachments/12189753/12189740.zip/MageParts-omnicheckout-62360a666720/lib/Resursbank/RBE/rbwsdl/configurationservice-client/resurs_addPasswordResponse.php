<?php

if (!class_exists("resurs_addPasswordResponse", false)) 
{
class resurs_addPasswordResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
