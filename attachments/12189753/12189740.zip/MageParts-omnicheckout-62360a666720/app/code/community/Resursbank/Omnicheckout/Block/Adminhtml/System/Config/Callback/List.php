<?php

/**
 * List displaying all registered callbacks.
 *
 * Class Resursbank_Omnicheckout_Block_Adminhtml_System_Config_Callback_List
 */
class Resursbank_Omnicheckout_Block_Adminhtml_System_Config_Callback_List extends Mage_Adminhtml_Block_System_Config_Form_Field
{

    /**
     * Potential error message received while fetching registered callback URLs.
     *
     * @var string
     */
    protected $_error = '';

    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('resursbank/omnicheckout/system/config/callback/list.phtml');
    }

    /**
     * Render element.
     *
     * @param Varien_Data_Form_Element_Abstract $element
     * @return string
     */
    protected function _getElementHtml(Varien_Data_Form_Element_Abstract $element)
    {
        return $this->_toHtml();
    }

    /**
     * Retrieve list of all registered callbacks.
     *
     * @return array
     */
    public function getCallbacks()
    {
        $result = array();

        try {
            $result = $this->_getHelper()->getCallbacks();
        } catch (Exception $e) {
            $this->setErrorMessage($this->_getHelper()->__('The connection to the payment gateway failed and thus we could not retrieve a list of your callback URLs. Please try again in a few minutes.'));
        }

        return is_array($result) ? $result : array();
    }

    /**
     * Set error message received while fetching registered callback URLs.
     *
     * @param string $message
     */
    public function setErrorMessage($message)
    {
        $this->_error = (string) $message;
    }

    /**
     * Retrieve error message.
     *
     * @return string
     */
    public function getErrorMessage()
    {
        return (string) $this->_error;
    }

    /**
     * Retrieve general helper.
     *
     * @return Resursbank_Omnicheckout_Helper_Callback
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout/callback');
    }

}
