<?php

/**
 * This class is used to inject custom checkout stylesheets on the omnicheckout page. Its included through the layout.
 *
 * The reason we do it this way is to ensure this CSS is loaded lastly, and thus it can override all previous CSS.
 *
 * Class Resursbank_Omnicheckout_Block_Css
 */
class Resursbank_Omnicheckout_Block_Css extends Mage_Core_Block_Text
{

    /**
     * @return string
     */
    public function getText()
    {
        return '<link rel="stylesheet" type="text/css" href="' . $this->getSkinUrl('resursbank/omnicheckout/css/checkout.css') . '" />' . PHP_EOL;
    }

}
