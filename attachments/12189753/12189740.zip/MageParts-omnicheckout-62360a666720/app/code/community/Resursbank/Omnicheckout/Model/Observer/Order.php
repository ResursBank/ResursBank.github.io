<?php

/**
 * Observes order events.
 *
 * Class Resursbank_Omnicheckout_Model_Observer_Order
 */
class Resursbank_Omnicheckout_Model_Observer_Order
{

    /**
     * Redirect incoming calls to omnicheckout (if necessary).
     *
     * @param Varien_Event_Observer $observer
     */
    public function appendResursbankToken(Varien_Event_Observer $observer)
    {
        if ($this->_getHelper()->isEnabled()) {
            /** @var Mage_Sales_Model_Order $order */
            $order = $observer->getOrder();

            if ($order && $order->isObjectNew()) {
                $order->setData('resursbank_token', $this->_getHelper()->getQuoteToken($this->_getHelper()->getQuote()));
            }
        }
    }

    /**
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

}
