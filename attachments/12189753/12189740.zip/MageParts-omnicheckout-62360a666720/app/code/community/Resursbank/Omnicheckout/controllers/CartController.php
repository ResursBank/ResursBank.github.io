<?php

require_once Mage::getModuleDir('controllers', 'Mage_Checkout') . DS . 'CartController.php';

class Resursbank_Omnicheckout_CartController extends Mage_Checkout_CartController
{

    /**
     * Remove an item from shopping cart.
     */
    public function deleteAction()
    {
        if ($this->_expireAjax()) {
            return;
        }

        $result = Mage::helper('omnicheckout/ajax')->getActionResultShell();

        try {
            // Run parent method.
            parent::deleteAction();

            // Render and append updated checkout elements to $result.
            $this->_renderUpdatedElements($result);

            // Add other information to $result.
            $result['id'] = (int) $this->getRequest()->getParam('id');
            $result['cart_qty'] = Mage::getSingleton('checkout/cart')->getSummaryQty();

            // Clear redirect and collected messages (avoid messages being shown duplicate times when navigating).
            Mage::helper('omnicheckout/ajax')->collectMessages($result['message']);
        } catch (Exception $e) {
            $result['message']['error'][] = $e->getMessage();
        }

        // Correct response headers.
        Mage::helper('omnicheckout/ajax')->correctResponseHeaders($this);

        // Return result.
        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Zend_Json::encode($result));
    }

    /**
     * Update an item in the shopping cart.
     */
    public function updateAction()
    {
        if ($this->_expireAjax()) {
            return;
        }

        $result = Mage::helper('omnicheckout/ajax')->getActionResultShell();

        $id = (int) $this->getRequest()->getParam('id');
        $qty = (float) $this->getRequest()->getParam('qty');

        try {
            $quoteItem = $this->_getCart()->getQuote()->getItemById($id);

            // Run parent action.
            if (!$this->_getHelper()->legacySetup()) {
                parent::ajaxUpdateAction();
            } else {
                $this->_legacyAjaxUpdateAction();
            }

            // Render and append updated checkout elements to $result.
            $this->_renderUpdatedElements($result);

            // Add other information to $result.
            $result['id'] = (int)$this->getRequest()->getParam('id');
            $result['item_total'] = Mage::helper('checkout')->formatPrice($quoteItem->getRowTotalInclTax());
            $result['cart_qty'] = Mage::getSingleton('checkout/cart')->getSummaryQty();

            // Clear redirect and collect messages.
            Mage::helper('omnicheckout/ajax')->collectMessages($result['message']);
        } catch (Exception $e) {
            $result['message']['error'][] = $e->getMessage();
        }

        // Correct response headers.
        Mage::helper('omnicheckout/ajax')->correctResponseHeaders($this);

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Zend_Json::encode($result));
    }

    /**
     * Update an item in the shopping cart.
     */
    public function couponAction()
    {
        if ($this->_expireAjax()) {
            return;
        }

        $result = Mage::helper('omnicheckout/ajax')->getActionResultShell();

        try {
            if (!$this->_validateFormKey()) {
                Mage::throwException('Invalid form key');
            }

            // Run parent action.
            parent::couponPostAction();

            // Render and append updated checkout elements to $result.
            $this->_renderUpdatedElements($result);

            // Clear redirect and collect messages.
            Mage::helper('omnicheckout/ajax')->collectMessages($result['message']);
        } catch (Exception $e) {
            $result['message']['error'][] = $e->getMessage();
        }

        // Correct response headers.
        Mage::helper('omnicheckout/ajax')->correctResponseHeaders($this);

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Zend_Json::encode($result));
    }

    /**
     * Render all (relevant) blocks that has been changed.
     *
     * @param array $result
     * @return $this
     */
    public function _renderUpdatedElements(array &$result)
    {
        if (!isset($result['elements']) || !is_array($result['elements'])) {
            $result['elements'] = array();
        }

        $this->loadLayout();

        $elements = $this->_getHelper()->renderCheckoutElements($this->getLayout(), true);

        if (count($elements)) {
            $result['elements'] = $elements;
        }

        return $this;
    }

    /**
     * Retrieve general helper.
     *
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

    /**
     * Get one page checkout singleton.
     *
     * @return Mage_Checkout_Model_Type_Onepage
     */
    public function _getOnepage()
    {
        return $this->_getHelper()->getOnepage();
    }

    /**
     * Validate ajax request and redirect on failure
     *
     * - Copied from app/code/core/Mage/Checkout/controllers/OnepageController.php (CE 1.9.2.4)
     *
     * @return bool
     */
    protected function _expireAjax()
    {
        if (!$this->_getOnepage()->getQuote()->hasItems()
            || $this->_getOnepage()->getQuote()->getHasError()
            || $this->_getOnepage()->getQuote()->getIsMultiShipping()
        ) {
            $this->_ajaxRedirectResponse();
            return true;
        }
        $action = strtolower($this->getRequest()->getActionName());
        if (Mage::getSingleton('checkout/session')->getCartWasUpdated(true)
            && !in_array($action, array('index', 'progress'))
        ) {
            $this->_ajaxRedirectResponse();
            return true;
        }
        return false;
    }

    /**
     * Send Ajax redirect response
     *
     * - Copied from app/code/core/Mage/Checkout/controllers/OnepageController.php (CE 1.9.2.4)
     *
     * @return Mage_Checkout_OnepageController
     */
    protected function _ajaxRedirectResponse()
    {
        $this->getResponse()
            ->setHeader('HTTP/1.1', '403 Session Expired')
            ->setHeader('Login-Required', 'true')
            ->sendResponse();
        return $this;
    }

    /**
     * This function was copied from Magento 1.9.2.4 (app/code/core/Mage/Checkout/controllers/CartController.php :: ajaxUpdateAction).
     *
     * We require this for older Magento versions.
     */
    public function _legacyAjaxUpdateAction()
    {
        if (!$this->_validateFormKey()) {
            Mage::throwException('Invalid form key');
        }
        $id = (int)$this->getRequest()->getParam('id');
        $qty = $this->getRequest()->getParam('qty');
        $result = array();
        if ($id) {
            try {
                $cart = $this->_getCart();
                if (isset($qty)) {
                    $filter = new Zend_Filter_LocalizedToNormalized(
                        array('locale' => Mage::app()->getLocale()->getLocaleCode())
                    );
                    $qty = $filter->filter($qty);
                }

                $quoteItem = $cart->getQuote()->getItemById($id);
                if (!$quoteItem) {
                    Mage::throwException($this->__('Quote item is not found.'));
                }
                if ($qty == 0) {
                    $cart->removeItem($id);
                } else {
                    $quoteItem->setQty($qty)->save();
                }
                $this->_getCart()->save();

                $this->loadLayout();
//                $result['content'] = $this->getLayout()->getBlock('minicart_content')->toHtml();

                $result['qty'] = $this->_getCart()->getSummaryQty();

                if (!$quoteItem->getHasError()) {
                    $result['message'] = $this->__('Item was updated successfully.');
                } else {
                    $result['notice'] = $quoteItem->getMessage();
                }
                $result['success'] = 1;
            } catch (Exception $e) {
                $result['success'] = 0;
                $result['error'] = $this->__('Can not save item.');
            }
        }

        $this->getResponse()->setHeader('Content-type', 'application/json');
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($result));
    }

}
