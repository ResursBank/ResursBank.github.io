<?php

class Resursbank_Omnicheckout_Block_Adminhtml_Sales_Order_View_Info_Omnicheckout extends Mage_Core_Block_Template
{

    /**
     * Payment information.
     *
     * @var array
     */
    private $_paymentInfo;

    protected function _construct()
    {
        parent::_construct();

        $this->setTemplate('resursbank/omnicheckout/sales/order/info/omnicheckout.phtml');
    }

    /**
     * Get payment status.
     *
     * @return string
     */
    public function getStatus()
    {
        $result = $this->getPaymentInformation('status');

        if (is_array($result)) {
            $result = implode(', ', $result);
        }

        return (string) $result;
    }

    /**
     * Retrieve order reference.
     *
     * @return string
     */
    public function getPaymentId()
    {
        return $this->getPaymentInformation('id');
    }

    /**
     * Retrieve payment total.
     *
     * @return float
     */
    public function getPaymentTotal()
    {
        return (float) $this->getPaymentInformation('totalAmount');
    }

    /**
     * Retrieve payment limit.
     *
     * @return float
     */
    public function getPaymentLimit()
    {
        return (float) $this->getPaymentInformation('limit');
    }

    /**
     * Check if payment is frozen.
     *
     * @return bool
     */
    public function isFrozen()
    {
        return ($this->getPaymentInformation('frozen') === true);
    }

    /**
     * Check if payment is fraud marked.
     *
     * @return bool
     */
    public function isFraud()
    {
        return ($this->getPaymentInformation('fraud') === true);
    }

    /**
     * Retrieve full customer name attached to payment.
     *
     * @return mixed
     */
    public function getCustomerName()
    {
        return $this->getCustomerInformation('fullName', true);
    }

    /**
     * Retrieve full customer address attached to payment.
     *
     * @return mixed
     */
    public function getCustomerAddress()
    {
        $street = $this->getCustomerInformation('addressRow1', true);
        $street2 = $this->getCustomerInformation('addressRow2', true);
        $postal = $this->getCustomerInformation('postalCode', true);
        $city = $this->getCustomerInformation('postalArea', true);
        $country = $this->getCustomerInformation('country', true);

        $result = "{$street}<br />";

        if ($street2) {
            $result.= "{$street2}<br />";
        }

        $result.= "{$city}<br />";
        $result.= "{$country} - {$postal}";

        return $result;
    }

    /**
     * Retrieve customer telephone number attached to payment.
     *
     * @return mixed
     */
    public function getCustomerTelephone()
    {
        return $this->getCustomerInformation('telephone');
    }

    /**
     * Retrieve customer email attached to payment.
     *
     * @return mixed
     */
    public function getCustomerEmail()
    {
        return $this->getCustomerInformation('email');
    }

    /**
     * Retrieve customer information from Resursbank payment.
     *
     * @param string $key
     * @param bool $address
     * @return mixed
     */
    public function getCustomerInformation($key = '', $address = false)
    {
        $result = (array) $this->getPaymentInformation('customer');

        if ($address) {
            $result = (is_array($result) && isset($result['address'])) ? (array) $result['address'] : null;
        }

        if (!empty($key)) {
            $result = isset($result[$key]) ? $result[$key] : null;
        }

        return $result;
    }

    /**
     * Retrieve payment information from Resursbank.
     *
     * @param string $key
     * @return mixed|null|stdClass
     */
    public function getPaymentInformation($key = '')
    {
        $result = null;

        $key = (string) $key;

        if (is_null($this->_paymentInfo)) {
            $this->_paymentInfo = (array) $this->_getHelper()->getPayment($this->getOrder());
        }

        if (empty($key)) {
            $result = $this->_paymentInfo;
        } else if (is_array($this->_paymentInfo) && isset($this->_paymentInfo[$key])) {
            $result = $this->_paymentInfo[$key];
        }

        return $result;
    }

    /**
     * Retrieve order object.
     *
     * @return Mage_Sales_Model_Order
     */
    public function setOrder(Mage_Sales_Model_Order $order)
    {
        return $this->setData('order', $order);
    }

    public function getOrder()
    {
        return $this->_getData('order');
    }

    /**
     * Retrieve general helper.
     *
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

}
