<?php

/**
 * Main block of checkout page.
 *
 * Class Resursbank_Omnicheckout_Block_Checkout
 */
class Resursbank_Omnicheckout_Block_Checkout extends Mage_Checkout_Block_Onepage
{

}
