<?php

/**
 * Rewrite of Mage_Adminhtml_Block_Sales_Order_View_Info. This class allows us to include custom HTML on the order view
 * in the admin panel.
 *
 * Class Resursbank_Omnicheckout_Block_Adminhtml_Sales_Order_View_Info
 */
class Resursbank_Omnicheckout_Block_Adminhtml_Sales_Order_View_Info extends Mage_Adminhtml_Block_Sales_Order_View_Info
{

    /**
     * Render block HTML.
     *
     * @return string
     */
    protected function _toHtml()
    {
        $result = '';

        if ($this->_getHelper()->isEnabled()) {
            try {
                if ($this->isOrderView() || $this->isInvoiceView()) {
                    $result = Mage::getBlockSingleton('omnicheckout/adminhtml_sales_order_view_info_omnicheckout')
                        ->setOrder($this->getParentBlock()->getOrder())
                        ->toHtml();
                }
            } catch (Exception $e) {
                // Do nothing.
            }
        }

        $result .= parent::_toHtml();

        return $result;
    }

    /**
     * Check if we are on order view in the administration panel.
     *
     * @return bool
     */
    public function isOrderView()
    {
        return (
            Mage::app()->getRequest()->getModuleName() === 'admin' &&
            Mage::app()->getRequest()->getControllerName() === 'sales_order' &&
            Mage::app()->getRequest()->getActionName() === 'view'
        );
    }

    /**
     * Check if we are on invoice view in the administration panel.
     *
     * @return bool
     */
    public function isInvoiceView()
    {
        return (
            Mage::app()->getRequest()->getModuleName() === 'admin' &&
            Mage::app()->getRequest()->getControllerName() === 'sales_order_invoice' &&
            Mage::app()->getRequest()->getActionName() === 'view'
        );
    }

    /**
     * Retrieve general helper.
     *
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

}
