<?php

/**
 * This class injects jQuery on legacy installations. jQuery is required by the iframe resizer script bundled with the
 * iframe.
 *
 * Class Resursbank_Omnicheckout_Block_Jquery
 */
class Resursbank_Omnicheckout_Block_Jquery extends Mage_Core_Block_Text
{

    /**
     * @return string
     */
    public function getText()
    {
        $result = '';

        if ($this->_getHelper()->legacySetup()) {
            $result = '<script type="text/javascript" href="' . Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_JS) . 'resursbank/omnicheckout/jquery/jquery-1.10.2.min.js"></script>' . PHP_EOL .
                      '<script type="text/javascript" href="' . Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_JS) . 'noconflict.js"></script>' . PHP_EOL;
        }

        return $result;
    }

    /**
     * Retrieve general helper.
     *
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

}
