<?php

/**
 * Observes cart events.
 *
 * Class Resursbank_Omnicheckout_Model_Observer_Cart
 */
class Resursbank_Omnicheckout_Model_Observer_Cart
{

    /**
     * Update the payment session at Resursbank when the quote is updated, or delete the payment session and clear the
     * checkout/session information in Magento if the cart is empty.
     *
     * @param Varien_Event_Observer $observer
     */
    public function updatePaymentSession(Varien_Event_Observer $observer)
    {
        if ($this->_getHelper()->isEnabled()) {
            if ($this->_getHelper()->cartIsEmpty()) {
                $this->_getHelper()->deletePaymentSession();
            } else {
                $this->_getHelper()->updatePaymentSession();
            }
        }
    }

    /**
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

}
