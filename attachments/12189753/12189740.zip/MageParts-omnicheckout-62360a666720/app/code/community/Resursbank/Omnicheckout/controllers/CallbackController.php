<?php

class Resursbank_Omnicheckout_CallbackController extends Mage_Core_Controller_Front_Action
{

    /**
     * Actions taken before any function within this controller can be executed.
     *
     * @return Mage_Core_Controller_Front_Action
     * @throws Exception
     */
    public function preDispatch()
    {
        // OmniCheckout must be enabled.
        if (!$this->_getHelper()->isEnabled()) {
            throw new Exception('Callbacks cannot be made while the OmniCheckout module is disabled.');
        }

        return parent::preDispatch();
    }

    /**
     * Test callback, basically used to verify that the communication from Resursbank servers function correctly.
     *
     * @todo I'm not sure if we actually need to implement this, for now it will just be a placeholder.
     */
    public function testAction()
    {
        // I've done nothing.
    }

    /**
     * A payment is unfrozen, which means it can be captured.
     *
     * Parameters:
     *
     *  paymentId (string) // This is the order reference passed by various actions before placing the order (init,
     *                        update, delete etc.). This is available on the order (and quote) objects as
     *                        resursbank_token.
     */
    public function unfreezeAction()
    {
        $this->_getHelper()->beforeOrderCallback('unfreeze');

        /** @var Mage_Sales_Model_Order $order */
        $order = $this->_getHelper()->getOrderFromRequest();

        // Create invoice.
//        $this->_getHelper()->createOrderInvoice($order);

        // Add order history comment.
        $this->_getHelper()->addOrderComment($order, $this->_getHelper()->__('Resursbank: payment was unfrozen.'));

        $this->_getHelper()->afterOrderCallback('unfreeze');
    }

    /**
     * A payment has been booked by Resursbank. This means the payment has been unfrozen and is preparing to be
     * finalized.
     *
     * Parameters:
     *
     *  paymentId (string) // This is the order reference passed by various actions before placing the order (init,
     *                        update, delete etc.). This is available on the order (and quote) objects as
     *                        resursbank_token.
     */
    public function bookedAction()
    {
        $this->_getHelper()->beforeOrderCallback('booked');

        /** @var Mage_Sales_Model_Order $order */
        $order = $this->_getHelper()->getOrderFromRequest();

        // Add order history comment.
        $this->_getHelper()->addOrderComment($order, $this->_getHelper()->__('Resursbank: payment was booked.'));

        $this->_getHelper()->afterOrderCallback('booked');
    }

    /**
     * A payment has been finalized by Resursbank. This means the client has been debited by Resursbank.
     *
     * Parameters:
     *
     *  paymentId (string) // This is the order reference passed by various actions before placing the order (init,
     *                        update, delete etc.). This is available on the order (and quote) objects as
     *                        resursbank_token.
     *
     * @todo We need more information from Resursbank regarding what this is.
     */
    public function finalizationAction()
    {
        $this->_getHelper()->beforeOrderCallback('finalization');

        /** @var Mage_Sales_Model_Order $order */
        $order = $this->_getHelper()->getOrderFromRequest();

        // Add order history comment.
        $this->_getHelper()->addOrderComment($order, $this->_getHelper()->__('Resursbank: payment was finalized.'));

        $this->_getHelper()->afterOrderCallback('finalization');
    }

    /**
     * A payment passed automatic fraud screening from Reusrsbank.
     *
     * Parameters:
     *
     *  paymentId (string) // This is the order reference passed by various actions before placing the order (init,
     *                        update, delete etc.). This is available on the order (and quote) objects as
     *                        resursbank_token.
     */
    public function automatic_fraud_controlAction()
    {
        $this->_getHelper()->beforeOrderCallback('automatic_fraud_control');

        /** @var Mage_Sales_Model_Order $order */
        $order = $this->_getHelper()->getOrderFromRequest();

        // Get screening result.
        $result = (strtolower($this->getRequest()->getParam('result')) === 'thawed');

        // Add order history comment.
        $this->_getHelper()->addOrderComment($order, $this->_getHelper()->__(($result ? 'Resursbank: payment passed automatic fraud screening.' : 'Resursbank: payment failed automatic fraud screening.')));

        $this->_getHelper()->afterOrderCallback('automatic_fraud_control');
    }

    /**
     * A payment has been fully annulled by Resursbank. This can for example occur if a fraud screening fails.
     *
     * Parameters:
     *
     *  paymentId (string) // This is the order reference passed by various actions before placing the order (init,
     *                        update, delete etc.). This is available on the order (and quote) objects as
     *                        resursbank_token.
     */
    public function annulmentAction()
    {
        $this->_getHelper()->beforeOrderCallback('annulment');

        /** @var Mage_Sales_Model_Order $order */
        $order = $this->_getHelper()->getOrderFromRequest();

        // Annul order.
        $this->_getHelper()->annulOrder($order);

        // Add order history comment.
        $this->_getHelper()->addOrderComment($order, $this->_getHelper()->__('Resursbank: payment was annulled.'));

        $this->_getHelper()->afterOrderCallback('annulment');
    }

    /**
     * A payment has been updated at Resursbank.
     *
     * Parameters:
     *
     *  paymentId (string) // This is the order reference passed by various actions before placing the order (init,
     *                        update, delete etc.). This is available on the order (and quote) objects as
     *                        resursbank_token.
     */
    public function updateAction()
    {
        $this->_getHelper()->beforeOrderCallback('update');

        /** @var Mage_Sales_Model_Order $order */
        $order = $this->_getHelper()->getOrderFromRequest();

        // Add order history comment.
        $this->_getHelper()->addOrderComment($order, $this->_getHelper()->__('Resursbank: payment was updated.'));

        $this->_getHelper()->afterOrderCallback('update');
    }

    /**
     * Retrieve general helper.
     *
     * @return Resursbank_Omnicheckout_Helper_Callback
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout/callback');
    }

}
