<?php

/**
 * Functionality specifically made for callback handling.
 *
 * Class Resursbank_Omnicheckout_Helper_Callback
 */
class Resursbank_Omnicheckout_Helper_Callback extends Resursbank_Omnicheckout_Helper_Data
{

    /**
     * Callback log file.
     */
    const LOG = 'resurs_callback.log';

    /**
     * These are actions taken before an order based callback is executed.
     *
     * @param $callback
     * @return $this
     */
    public function beforeOrderCallback($callback)
    {
        // Log incoming call.
        $this->debugLog("Executing callback {$callback}");
        $this->debugLog("Params:\n\r" . $this->requestParamsToString());

        // Allows observers to modify the data submitted to the API.
        Mage::dispatchEvent(
            'omnicheckout_callback_' . strtolower((string) $callback) . '_before',
            array(
                'order' => $this->getOrderFromRequest(),
                'parameters' => Mage::app()->getRequest()->getParams()
            )
        );

        return $this;
    }

    /**
     * Format request params as string (useful for logging).
     *
     * @return string
     */
    public function requestParamsToString()
    {
        $result = '';

        $params = Mage::app()->getRequest()->getParams();

        if (is_array($params) && count($params)) {
            $result = '';

            foreach ($params as $key => $val) {
                $result.= "{$key} = {$val}\n\r";
            }
        }

        return $result;
    }

    /**
     * These are actions taken after an order based callback is executed.
     *
     * @param $callback
     * @return $this
     */
    public function afterOrderCallback($callback)
    {
        // Allows observers to perform actions based on API response.
        Mage::dispatchEvent(
            'omnicheckout_callback_' . strtolower((string) $callback) . '_after',
            array(
                'order' => $this->getOrderFromRequest(),
                'parameters' => Mage::app()->getRequest()->getParams()
            )
        );

        return $this;
    }

    /**
     * Retrieve order object from callback parameter paymentId.
     *
     * @return Mage_Sales_Model_Order
     * @throws Exception
     */
    public function getOrderFromRequest()
    {
        $token = Mage::app()->getRequest()->getParam('paymentId');

        if (empty($token)) {
            throw new Exception('No order token supplied.');
        }

        /** @var Mage_Sales_Model_Order $order */
        $order = Mage::getModel('sales/order')->loadByAttribute('resursbank_token', $token);

        if (is_null($order) || !$order->getId()) {
            throw new Exception('Failed to locate referenced order.');
        }

        return $order;
    }

    /**
     * Log debug message.
     *
     * @param string|array $message
     * @return $this
     * @throws Exception
     */
    public function debugLog($message)
    {
        if ($this->getCallbackSetting('debug_enabled')) {
            Mage::log((string) $message, null, self::LOG, true);
        }

        return $this;
    }

    /**
     * Get a setting from the callback configuration.
     *
     * @param string $key
     * @param bool $flag
     * @return mixed
     */
    public function getCallbackSetting($key, $flag = false)
    {
        $key = (string) $key;

        return !$flag ? Mage::getStoreConfig("omnicheckout/callback/{$key}", $this->getStoreId()) : Mage::getStoreConfigFlag("omnicheckout/callback/{$key}", $this->getStoreId());
    }

    /**
     * Register all callbacks.
     *
     * @return $this
     */
    public function register()
    {
        return $this->getApiModel()->registerCallbacks();
    }

    /**
     * Create order invoice.
     *
     * @param Mage_Sales_Model_Order $order
     * @return $this
     * @throws Exception
     */
    public function createOrderInvoice(Mage_Sales_Model_Order $order)
    {
        /** @var Varien_Db_Adapter_Interface $write */
        $write = Mage::getSingleton('core/resource')
            ->getConnection('core_write');

        // Start transaction.
        $write->beginTransaction();

        try {
            /** @var Mage_Sales_Model_Order_Invoice $invoice */
            $invoice = Mage::getModel('sales/service_order', $order)->prepareInvoice();

            if (!$invoice->getTotalQty()) {
                throw new Exception('Cannot create an invoice without products.');
            }

            // Capture payment.
            $invoice->setRequestedCaptureCase(Mage_Sales_Model_Order_Invoice::CAPTURE_OFFLINE);
            $invoice->register();

            // Set order state and status to processing.
            $order->setState(Mage_Sales_Model_Order::STATE_PROCESSING)
                ->setStatus(Mage_Sales_Model_Order::STATE_PROCESSING);

            // Save invoice and order.
            $invoice->save();
            $order->save();

            // @todo Check if we can get transactions working.
            /** @var Mage_Sales_Model_Order_Payment_Transaction $transaction */
//            $transaction = Mage::getModel('sales/order_payment_transaction');
//
//            $transaction->setData(array(
//                'order_id' => $order->getId(),
//                'payment_id' => $order->getPayment()->getId(),
//                'tnx_type' => Mage_Sales_Model_Order_Payment_Transaction::TYPE_CAPTURE
//            ));
//
//            $transaction->setOrderPaymentObject($order->getPayment());
//
//            $transaction->save();

            // Ensure grid records in admin panel are accurately reflected.
            $order->getResource()->updateGridRecords(array($order->getId()));
            $invoice->getResource()->updateGridRecords(array($invoice->getId()));

            // Commit transaction.
            $write->commit();
        } catch (Exception $e) {
            // Log error.
            $this->debugLog('Order ' . $order->getId() . ', invoice creation error: ' . $e->getMessage());

            // Rollback transaction.
            $write->rollback();

            // Pass it forward.
            throw $e;
        }

        return $this;
    }

    /**
     * Cancel order.
     *
     * @param Mage_Sales_Model_Order $order
     * @return $this
     * @throws Exception
     * @todo There should be a more accurate way of doing this, follow Magentos native way.
     */
    public function annulOrder(Mage_Sales_Model_Order $order)
    {
        try {
            // Set state and status to canceled.
            $order->setState(Mage_Sales_Model_Order::STATE_CANCELED)
                ->setStatus(Mage_Sales_Model_Order::STATE_CANCELED)
                ->save();
        } catch (Exception $e) {
            // Log error.
            $this->debugLog('Order ' . $order->getId() . ', annulment error: ' . $e->getMessage());

            // Pass it forward.
            throw $e;
        }

        return $this;
    }

    /**
     * Add order comment.
     *
     * @param Mage_Sales_Model_Order $order
     * @param string $comment
     * @throws Exception
     */
    public function addOrderComment(Mage_Sales_Model_Order $order, $comment)
    {
        if (!is_string($comment)) {
            throw new Exception('Comment must be strings.');
        }

        $order->addStatusHistoryComment($comment, false);
        $order->save();
    }

    /**
     * Retrieve list of all registered callbacks.
     *
     * @return array
     */
    public function getCallbacks()
    {
        return $this->getApiModel()->getCallbacks();
    }

}
