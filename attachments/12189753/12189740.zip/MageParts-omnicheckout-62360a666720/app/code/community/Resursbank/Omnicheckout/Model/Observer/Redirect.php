<?php

/**
 * Handles redirect to Omnicheckout.
 *
 * Class Resursbank_Omnicheckout_Model_Observer_Redirect
 */
class Resursbank_Omnicheckout_Model_Observer_Redirect
{

    /**
     * Redirect incoming calls to omnicheckout (if necessary).
     *
     * @param Varien_Event_Observer $observer
     */
    public function redirect(Varien_Event_Observer $observer)
    {
        if ($this->_getHelper()->isEnabled()) {
            // URL to redirect to, if any.
            $redirect = $this->requestShouldRedirect($observer->getControllerAction());

            if ($redirect) {
                $this->_getHelper()->redirect($redirect);
            }
        }
    }

    /**
     * Check if an incoming request should be redirected to omnicheckout.
     *
     * @param Mage_Core_Controller_Varien_Action $controller
     * @return bool
     */
    public function requestShouldRedirect(Mage_Core_Controller_Varien_Action $controller)
    {
        $result = false;

        if ($controller->getRequest()->getModuleName() === 'checkout') {
            $result = ($this->isRedirectAbleCheckoutAction($controller) || $this->isRedirectAbleCartAction($controller)) ? 'omnicheckout' : '';
        } else if ($controller->getRequest()->getModuleName() === 'omnicheckout') {
            if ($controller->getRequest()->getControllerName() !== 'callback') {
                $result = $this->_getHelper()->quoteIsUnusable() ? 'checkout/cart' : '';
            }
        }

        return $result;
    }

    /**
     * Check if give action is a redirect-able call to the vanilla cart controller.
     *
     * @param Mage_Core_Controller_Varien_Action $controller
     * @return bool
     */
    public function isRedirectAbleCartAction(Mage_Core_Controller_Varien_Action $controller)
    {
        return ($controller->getRequest()->getControllerName() === 'cart' && $controller->getRequest()->getActionName() === 'index' && $this->_getHelper()->quoteHasItems());
    }

    /**
     * Check if give action is a redirect-able call to the vanilla checkout/onepage controllers.
     *
     * @param Mage_Core_Controller_Varien_Action $controller
     * @return bool
     */
    public function isRedirectAbleCheckoutAction(Mage_Core_Controller_Varien_Action $controller)
    {
        return ($controller->getRequest()->getControllerName() === 'checkout' || ($controller->getRequest()->getControllerName() === 'onepage' && !in_array($controller->getRequest()->getActionName(), array('success', 'failure'))));
    }

    /**
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

}
