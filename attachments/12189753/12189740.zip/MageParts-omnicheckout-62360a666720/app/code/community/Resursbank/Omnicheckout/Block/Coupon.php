<?php

class Resursbank_Omnicheckout_Block_Coupon extends Mage_Core_Block_Template
{

    protected function _construct()
    {
        $this->setTemplate('resursbank/omnicheckout/coupon.phtml');

        parent::_construct();
    }

    /**
     * Retrieve applied coupon code.
     *
     * @return string
     */
    public function getCode()
    {
        return (string) $this->_getHelper()->getQuote()->getCouponCode();
    }

    /**
     * Retreive currency formatted discount amount.
     *
     * @return string
     */
    public function getDiscountAmount()
    {
        $amount = (float) ($this->_getHelper()->getQuote()->getSubtotal() - $this->_getHelper()->getQuote()->getSubtotalWithDiscount());

        return Mage::helper('core')->formatCurrency(-$amount);
    }

    /**
     * Check if coupon code has been applied.
     *
     * @return bool
     */
    public function couponIsApplied()
    {
        return $this->getCode() !== '';
    }

    /**
     * Retrieve general helper.
     *
     * @return Resursbank_Omnicheckout_Helper_Data
     */
    public function _getHelper()
    {
        return Mage::helper('omnicheckout');
    }

}
