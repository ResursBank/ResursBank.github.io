<?php

/**
 * General functionality used here and there.
 *
 * Class Resursbank_Omnicheckout_Helper_Data
 */
class Resursbank_Omnicheckout_Helper_Data extends Mage_Core_Helper_Abstract
{

    /**
     * Working store id.
     *
     * @var int
     */
    protected $_storeId;

    /**
     * Check whether or not we are in the admin panel.
     *
     * @return boolean
     */
    public function isAdmin()
    {
        return (Mage::app()->getStore()->isAdmin() || Mage::getDesign()->getArea() == 'adminhtml');
    }

    /**
     * Get working store id, works for frontend and backend.
     *
     * @return int
     */
    public function getStoreId()
    {
        if (is_null($this->_storeId)) {
            if ($this->isAdmin()) {
                $store = Mage::app()->getRequest()->getParam('store');

                if (!is_numeric($store)) {
                    $storeModel = Mage::getModel('core/store')->load($store);

                    if ($storeModel && $storeModel->getId()) {
                        $this->_storeId = (int) $storeModel->getId();
                    }
                } else {
                    $this->_storeId = (int) $store;
                }
            } else {
                $this->_storeId = (int) Mage::app()->getStore()->getId();
            }
        }

        return (int) $this->_storeId;
    }

    /**
     * Check if extension is enabled.
     *
     * @param int $storeId
     * @return boolean
     */
    public function isEnabled($storeId = null)
    {
        return ((bool) Mage::getStoreConfig('omnicheckout/general/enabled', (is_null($storeId) ? $this->getStoreId() : $storeId)) && $this->getApiModel()->hasCredentials());
    }

    /**
     * Redirect to specified url.
     *
     * @param string $url
     * @param boolean $hard
     * @return $this
     */
    public function redirect($url, $hard = false)
    {
        if (is_string($url) && !empty($url)) {
            if ($hard) {
                $this->hardRedirect($url);

            } else {
                $this->softRedirect($url);
            }
        }

        return $this;
    }

    /**
     * Redirect back to previous URL.
     */
    public function redirectBack()
    {
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    }

    /**
     * Perform a hard redirect to $url
     *
     * @param $url
     * @throws Exception
     */
    public function hardRedirect($url)
    {
        $url = (string) $url;

        if (empty($url)) {
            throw new Exception("Cannot redirect to empty URL.");
        }

        header('Location: ' . (string) $url) ;

        exit;
    }

    /**
     * Perform a soft redirect to $url
     *
     * @param $url
     */
    public function softRedirect($url)
    {
        Mage::app()
            ->getResponse()
            ->setRedirect(Mage::getModel('core/url')->getUrl($url))
            ->sendResponse();

        exit;
    }

    /**
     * Retrieve completely random string.
     *
     * @param int $length
     * @param string $charset
     * @return string
     */
    public function strRand($length, $charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')
    {
        $result = '';

        $length = (int) $length;

        if ($length > 0) {
            $max = strlen($charset)-1;

            for ($i = 0; $i < $length; $i++) {
                $result.= $charset[mt_rand(0, $max)];
            }
        }

        return $result;
    }

    /**
     * Check if quote object have any items.
     *
     * @return bool
     */
    public function quoteHasItems()
    {
        return $this->getQuote()->hasItems();
    }

    /**
     * Retrieve quote object.
     *
     * @return Mage_Sales_Model_Quote
     */
    public function getQuote()
    {
        return Mage::getSingleton('checkout/cart')
            ->getQuote();
    }

    /**
     * Check if the quote object is unusable (ie. cannot be checked out).
     *
     * @return bool
     */
    public function quoteIsUnusable()
    {
        return (!$this->getQuote()->hasItems() || $this->getQuote()->getHasError());
    }

    /**
     * Assign default address information to quote object (in order to collect available shipping methods).
     *
     * @param bool $shipping
     * @param bool $billing
     * @return $this
     * @todo This might function differently if users are logged in.
     */
    public function quoteAssignDefaultAddress($shipping = true, $billing = true)
    {
        if ($shipping) {
            $this->quoteAssignAddress(array(
                'country_id' => Mage::helper('core')->getDefaultCountry(),
                'collect_shipping_rates' => true
            ), 'shipping');
        }

        if ($billing) {
            $this->quoteAssignAddress(array(
                'country_id' => Mage::helper('core')->getDefaultCountry(),
                'collect_shipping_rates' => true
            ), 'billing');
        }

        return $this;
    }

    /**
     * Assign address information to quote object.
     *
     * @param array $data
     * @param string $type
     * @return $this
     * @throws Exception
     */
    public function quoteAssignAddress(array $data, $type)
    {
        $this->quoteValidateAddressType($type);

        // Create empty address objects if they are missing.
        $this->quoteCreateMissingAddressObject($type);

        if ($type === 'billing') {
            $this->getQuote()->getBillingAddress()->addData($data);
        } else {
            $this->getQuote()->getShippingAddress()->addData($data);
        }

        return $this;
    }

    /**
     * Assign an empty Mage_Sales_Model_Quote_Address instance to quote billing/shipping address if needed.
     *
     * @param string $type (billing|shipping)
     * @return $this
     * @throws Exception
     */
    public function quoteCreateMissingAddressObject($type)
    {
        $this->quoteValidateAddressType($type);

        if ($type === 'billing') {
            if (!$this->getQuote()->getBillingAddress()) {
                $this->getQuote()->setBillingAddress(Mage::getModel('sales/quote_address'));
            }
        } else {
            if (!$this->getQuote()->getShippingAddress()) {
                $this->getQuote()->setShippingAddress(Mage::getModel('sales/quote_address'));
            }
        }

        return $this;
    }

    /**
     * Validate address type, should be either billing or shipping.
     *
     * @param string $type
     * @return bool
     * @throws Exception
     */
    public function quoteValidateAddressType(&$type)
    {
        $type = (string) $type;

        if ($type !== 'billing' && $type !== 'shipping') {
            throw new Exception("Invalid address type provided.");
        }

        return true;
    }

    /**
     * Check if any address information is missing on the quote object.
     *
     * @return bool
     * @todo Check if this is the proper way of checking this, can probably be improved.
     */
    public function quoteIsMissingAddress()
    {
        return (!$this->getQuote()->getShippingAddress()->getData('country_id') || !$this->getQuote()->getBillingAddress()->getData('country_id'));
    }

    /**
     * Retrieve checkout session.
     *
     * @return Mage_Checkout_Model_Session
     */
    public function getCheckoutSession()
    {
        return Mage::getSingleton('checkout/session');
    }

    /**
     * Check if some value has changed based on a hash stored in the checkout session (useful when checking if certain
     * blocks have been updated as values are changed in checkout, otherwise we do not need to transport the HTML back
     * to the client and ultimately we conserve resources that way).
     *
     * @param string $value
     * @param string $key
     * @return bool
     */
    public function blockHasChanged($value, $key)
    {
        $result = false;

        $value = (string) $value;
        $key = preg_replace('/[^a-z0-9]/', '', strtolower((string) $key));

        $key = 'omnicheckout_hash_' . $key;

        $current = $this->getCheckoutSession()->getData($key);
        $new = md5($value);

        if ($current !== $new) {
            $this->getCheckoutSession()->setData($key, $new);
            $result = true;
        }

        return $result;
    }

    /**
     * Reset checkout elements.
     *
     * @return $this
     */
    public function resetCheckoutElements()
    {
        if (!$this->legacySetup()) {
            $this->getCheckoutSession()->setData('omnicheckout_hash_header-cart', null);
        }

        $this->getCheckoutSession()->setData('omnicheckout_hash_omnicheckout-shipping-methods-list', null);
        $this->getCheckoutSession()->setData('omnicheckout_hash_current-coupon-code', null);

        return $this;
    }

    /**
     * Retrieve API singleton.
     *
     * @return Resursbank_Omnicheckout_Model_Api
     */
    public function getApiModel()
    {
        return Mage::getSingleton('omnicheckout/api');
    }

    /**
     * Initialize payment session, if one isn't already available.
     *
     * @return mixed|Zend_Http_Response
     */
    public function initPaymentSession()
    {
        if (!$this->getApiModel()->paymentSessionInitialized()) {
            $this->getApiModel()->initPaymentSession();
        }

        return $this;
    }

    /**
     * Update active payment session if any.
     *
     * @return $this
     */
    public function updatePaymentSession()
    {
        if ($this->getApiModel()->paymentSessionInitialized()) {
            try {
                $this->getApiModel()->updatePaymentSession();
            } catch (Exception $e) {
                // Do nothing.
            }
        }

        return $this;
    }

    /**
     * Delete active payment session.
     *
     * @return mixed|Zend_Http_Response
     */
    public function deletePaymentSession()
    {
        if ($this->getApiModel()->paymentSessionInitialized()) {
            try {
                // Delete session through API.
                $this->getApiModel()->deletePaymentSession();
            } catch (Exception $e) {
                // Do nothing.
            }
        }

        // Unset session data.
        $this->clearPaymentSession();

        return $this;
    }

    /**
     * Clear payment session information from checkout session.
     *
     * @return $this
     */
    public function clearPaymentSession()
    {
        // Unset session data.
        $this->getCheckoutSession()
            ->unsetData(Resursbank_Omnicheckout_Model_Api::PAYMENT_SESSION_ID_KEY)
            ->unsetData(Resursbank_Omnicheckout_Model_Api::PAYMENT_SESSION_IFRAME_KEY);

        // Reset rendered checkout blcoks.
        $this->resetCheckoutElements();

        return $this;
    }

    /**
     * Register API callbacks.
     *
     * @return $this
     */
    public function registerApiCallbacks()
    {
        $this->getApiModel()->registerCallbacks();

        return $this;
    }

    /**
     * Retrieve/generate unique token used to identify quote/order object when communicating with Resursbank servers.
     * The token is a completely unique string to ensure that callbacks made from Resursbank will identify the correct
     * quote/order.
     *
     * @param Mage_Sales_Model_Quote $quote
     * @param bool $refresh
     * @return string
     * @throws Exception
     */
    public function getQuoteToken(Mage_Sales_Model_Quote $quote, $refresh = false)
    {
        if (!$quote->getId()) {
            throw new Exception('Uninitialized quote object.');
        }

        // Retrieve existing token form quote, if any.
        $result = $quote->getData('resursbank_token');

        if ($refresh || !is_string($result)) {
            // Generate unique token.
            $result = sha1($this->strRand(64) . $quote->getId() . time());

            // Store token on quote for later usage.
            $quote->setData('resursbank_token', $result)->save();
        }

        return (string) $result;
    }

    /**
     * URL encode array recursively.
     *
     * @param array $data
     * @return array
     */
    public function urlencodeArray(array $data)
    {
        if (count($data)) {
            foreach ($data as $key => $val) {
                $data[$key] = is_array($val) ? $this->urlencodeArray($val) : urlencode($val);
            }
        }

        return $data;
    }

    /**
     * Get a completed payment from Resursbank.
     *
     * @param Mage_Sales_Model_Order $order
     * @return null|stdClass
     */
    public function getPayment(Mage_Sales_Model_Order $order)
    {
        return $this->getApiModel()->getPayment($order->getData('resursbank_token'));
    }

    /**
     * Render checkout elements (useful for return values from AJAX calls).
     *
     * @param Mage_Core_Model_Layout $layout
     * @param bool $onlyUpdated
     * @return array
     */
    public function renderCheckoutElements(Mage_Core_Model_Layout $layout, $onlyUpdated = true)
    {
        $result = array();

        if (!$this->legacySetup()) {
            $result['header-cart'] = $this->renderCheckoutElementMiniCart($layout, $onlyUpdated);
        }
        
        $result['omnicheckout-shipping-methods-list'] = $this->renderCheckoutElementShippingMethods($layout, $onlyUpdated);
        $result['current-coupon-code'] = $this->renderCheckoutElementCurrentCoupon($layout, $onlyUpdated);

        foreach ($result as $id => $el) {
            if (is_null($el)) {
                unset($result[$id]);
            }
        }

        return $result;
    }

    /**
     * Render mini-cart element.
     *
     * @param Mage_Core_Model_Layout $layout
     * @param bool $onlyUpdated
     * @return null|string
     */
    public function renderCheckoutElementMiniCart(Mage_Core_Model_Layout $layout, $onlyUpdated = true)
    {
        // Render mini-cart element.
        $result = $layout->getBlock('minicart_content')->toHtml();

        if ($onlyUpdated && !$this->blockHasChanged($result, 'header-cart')) {
            $result = null;
        }

        return $result;
    }

    /**
     * Render element displaying currently applied coupon code.
     *
     * @param Mage_Core_Model_Layout $layout
     * @param bool $onlyUpdated
     * @return null|string
     * @todo This should be able to function more like renderCheckoutElementMiniCart() but it does not right now. Figure out why when there is time.
     */
    public function renderCheckoutElementCurrentCoupon(Mage_Core_Model_Layout $layout, $onlyUpdated = true)
    {
        $result = null;

        /** @var Resursbank_Omnicheckout_Block_Coupon $block */
        $block = Mage::getBlockSingleton('omnicheckout/coupon');

        if ($block) {
            // Render element.
            $result = $block->toHtml();

            if ($onlyUpdated && !$this->blockHasChanged($result, 'current-coupon-code')) {
                $result = null;
            }
        }

        return $result;
    }

    /**
     * Render shipping methods block displayed at checkout.
     *
     * @param Mage_Core_Model_Layout $layout
     * @param bool $onlyUpdated
     * @return null|string
     * @throws Mage_Core_Exception
     * @todo This should be able to function more like renderCheckoutElementMiniCart() but it does not right now. Figure out why when there is time.
     */
    public function renderCheckoutElementShippingMethods(Mage_Core_Model_Layout $layout, $onlyUpdated = true)
    {
        $result = null;

        /** @var Mage_Checkout_Block_Onepage_Shipping_Method_Available $block */
        $block = Mage::getBlockSingleton('checkout/onepage_shipping_method_available');

        if ($block) {
            // Set template.
            $block->setTemplate('checkout/onepage/shipping_method/available.phtml');

            // Render element.
            $result = $block->toHtml();

            if ($onlyUpdated && !$this->blockHasChanged($result, 'omnicheckout-shipping-methods-list')) {
                $result = null;
            }
        }

        return $result;
    }

    /**
     * Get one page checkout model.
     *
     * - Copied from app/code/core/Mage/Checkout/controllers/OnepageController.php (CE 1.9.2.4)
     *
     * @return Mage_Checkout_Model_Type_Onepage
     */
    public function getOnepage()
    {
        return Mage::getSingleton('checkout/type_onepage');
    }

    /**
     * Basically this will return true if you are running a version of MAgento below 1.9 (hence missing the RWD theme
     * and a bunch of other stuff).
     *
     * @todo Find a better name for this
     * @return bool
     */
    public function legacySetup()
    {
        return (bool) (version_compare(Mage::getVersion(), '1.9', '<'));
    }

    /**
     * Check if shopping cart is empty.
     *
     * @return bool
     */
    public function cartIsEmpty()
    {
        return ((float) Mage::helper('checkout/cart')->getItemsCount() < 1);
    }

}
