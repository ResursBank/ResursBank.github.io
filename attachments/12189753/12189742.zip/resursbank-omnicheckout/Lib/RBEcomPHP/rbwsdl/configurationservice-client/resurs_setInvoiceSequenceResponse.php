<?php

if (!class_exists("resurs_setInvoiceSequenceResponse", false)) 
{
class resurs_setInvoiceSequenceResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
