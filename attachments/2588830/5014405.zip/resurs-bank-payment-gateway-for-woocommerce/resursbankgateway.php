<?php
/**
 * Plugin Name: WooCommerce Resurs Bank Gateway
 * Plugin URI: https://wordpress.org/plugins/resurs-bank-payment-gateway-for-woocommerce/
 * Description: Extends WooCommerce with an Resurs Bank gateway.
 * Version: 1.0.0
 * Author: Resurs Bank AB
 * Author URI: https://test.resurs.com/docs/display/ecom/WooCommerce
 */

define('RB_API_PATH', dirname(__FILE__) .  "/rbwsdl");
require_once('classes/rbapiloader.php');

add_action('plugins_loaded', 'woocommerce_gateway_resurs_bank_init');

/**
 * Initialize Resurs Bank Plugin
 */
function woocommerce_gateway_resurs_bank_init() {

    if ( !class_exists( 'WC_Payment_Gateway' ) ) return;
    if ( class_exists('WC_Resurs_Bank')) return;

    /**
     * Localisation
     */
    load_plugin_textdomain('WC_Payment_Gateway', false, dirname( plugin_basename( __FILE__ ) ) . '/languages');

    /**
     * Resurs Bank Gateway class
     */
    class WC_Resurs_Bank extends WC_Payment_Gateway {

        private $flow = null;

        /**
         * Constructor method for Resurs Bank plugin
         *
         * This method initializes various properties and fetches payment methods, either from the tranient API or from Resurs Bank API.
         * It is also responsible for calling generate_payment_gateways, if these need to be refreshed.
         */
        public function __construct()
        {
            global $current_user, $wpdb, $woocommerce;
            get_currentuserinfo();

            $rates = $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}woocommerce_tax_rates
				ORDER BY tax_rate_order
				LIMIT %d
				" ,
                1000
            ) );

            $this->id           = "resurs-bank";
            $this->method_title = "Resurs Bank Administration";
            $this->has_fields   = false;
            $this->callback_types = array(
                'UNFREEZE' => array(
                    'uri_components' => array(
                        'paymentId' => 'paymentId',
                    ),
                    'digest_parameters' => array(
                        'paymentId' => 'paymentId',
                    ),
                ),
                'AUTOMATIC_FRAUD_CONTROL' => array(
                    'uri_components' => array(
                        'paymentId' => 'paymentId',
                        'result' => 'result',
                    ),
                    'digest_parameters' => array(
                        'paymentId' => 'paymentId',
                    ),
                ),
                'PASSWORD_EXPIRATION' => array(
                    'uri_components' => array(
                        'identifier' => 'identifier',
                    ),
                    'digest_parameters' => array(
                        'identifier' => 'identifier',
                    ),
                ),
                //'TEST',
                'ANNULMENT' => array(
                    'uri_components' => array(
                        'paymentId' => 'paymentId',
                    ),
                    'digest_parameters' => array(
                        'paymentId' => 'paymentId',
                    ),
                ),
                'FINALIZATION' => array(
                    'uri_components' => array(
                        'paymentId' => 'paymentId',
                    ),
                    'digest_parameters' => array(
                        'paymentId' => 'paymentId',
                    ),
                ),
            );

            $this->init_form_fields();
            $this->init_settings();

            $this->title       = $this->get_option( 'title' );
            $this->description = $this->get_option( 'description' );
            $this->login       = $this->get_option( 'login' );
            $this->password    = $this->get_option( 'password' );
            $this->baseLiveURL = $this->get_option( 'baseLiveURL' );
            $this->baseTestURL = $this->get_option( 'baseTestURL' );
            $this->serverEnv   = $this->get_option( 'serverEnv' );

            /**
             * Load the workflow client
             */
            if (class_exists('ResursBank')) {
                if (!empty($this->login) && !empty($this->password)) {
                    $this->flow = initializeResursFlow();
                }
            }

            //var_dump(get_transient('resurs_bank_digest_salt'));

            if ( !empty( $this->login ) && !empty( $this->password ) ) {
                $this->paymentMethods = $this->get_payment_methods( );
                if ( empty( $this->paymentMethods['error'] ) ) {
                    if ( true === $this->paymentMethods['generate_new_files'] ) {
                        $this->generate_payment_gateways( $this->paymentMethods['methods'] );
                    }
                }
            }

            //delete_transient('resurs_bank_payment_methods');
            add_action( 'woocommerce_api_wc_resurs_bank', array( $this, 'check_callback_response' ) );

            if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
                add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
            } else {
                add_action( 'woocommerce_update_options_payment_gateways', array( $this, 'process_admin_options' ) );
            }

            if ( ! $this->is_valid_for_use() ) {
                $this->enabled = false;
            }
        }

        /**
         * Initialize the form fields for the plugin
         */
        function init_form_fields()
        {
            global $wpdb, $woocommerce;

            $rates = $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}woocommerce_tax_rates
				ORDER BY tax_rate_order
				LIMIT %d
				" ,
                1000
            ) );

            $rate_select = array();

            foreach ($rates as $rate) {
                $rate_name = $rate->tax_rate_class;
                if ( '' === $rate_name ) {
                    $rate_name = 'standard';
                }

                $rate_name = str_replace('-', ' ', $rate_name);
                $rate_name = ucwords($rate_name);

                $rate_select[$rate->tax_rate_class] = $rate_name;
            }

            $this->form_fields = array(
                'enabled' => array(
                    'title' => __( 'Enable/Disable', 'woocommerce' ),
                    'type'  => 'checkbox',
                    'label' => 'Aktivera Resurs Bank',
                ),
                'title' => array(
                    'title'       => __( 'Title', 'woocommerce' ),
                    'type'        => 'text',
                    'default'     => 'Resurs Bank',
                    'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce' ),
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => __( 'Description', 'woocommerce' ),
                    'type'        => 'textarea',
                    'default'     => 'Betala med Resurs Bank',
                    'description' => __( 'This controls the description which the user sees during checkout.', 'woocommerce' ),
                    'desc_tip'    => true,
                ),
                'login' => array(
                    'title'       => 'Användarnamn',
                    'type'        => 'text',
                    'description' => 'Användarnamnet för Resurs Bank API',
                    'default'     => '',
                    'desc_tip'    => true,
                ),
                'password' => array(
                    'title'       => 'Lösenord',
                    'type'        => 'text',
                    'default'     => '',
                    'description' => 'Lösenordet för Resurs Bank API',
                    'desc_tip'    => true,
                ),
                'country' => array(
                    'title'       => 'Land',
                    'type'        => 'select',
                    'options'     => array(
                        'SE' => __( 'Sweden', 'woocommerce' ),
                        'DK' => __( 'Denmark', 'woocommerce' ),
                        'FI' => __( 'Finland', 'woocommerce' ),
                        'NO' => __( 'Norway', 'woocommerce' ),
                    ),
                    'default'     => 'SE',
                    'description' => 'Det land där kontot till Resurs Bank API är registrerat',
                    'desc_tip'    => true,
                ),
                'priceTaxClass' => array(
                    'title'       => 'Moms',
                    'type'        => 'select',
                    'options'     => $rate_select,
                    'description' => 'Momssatsen som kommer läggas på avgiften för de olika betalningsalternativen',
                    'desc_tip'    => true,
                ),
                'registerCallbacksButton' => array(
                    'title' => 'Registrera Callbacks',
                    'type'  => 'submit',
                    'value' => 'Registrera Callbacks',
                ),
                'refreshPaymentMethods' => array(
                    'title' => 'Uppdatera tillgängliga betalmetoder',
                    'type'  => 'submit',
                    'value' => 'Uppdatera tillgängliga betalmetoder',
                ),
                'serverEnv' => array(
                    'title'   => 'Servermiljö',
                    'type'    => 'select',
                    'options' => array(
                        'live' => 'Live',
                        'test' => 'Test',
                    ),
                    'default' => 'test',
                ),
                'extendedAfterShopFlow' => array(
                    'title'       => 'Utökat stöd för AfterShopFlow',
                    'type'        => 'select',
                    'options'     => array(
                        'true'  => 'true',
                        'false' => 'false',
                    ),
                    'default'     => 'false',
                    'description' => 'Utökar stödet för AftershopFlow (Tillåter bland annat delkrediteringar och delannulleringar)',
                    'desc_tip'    => true,
                ),
                'waitForFraudControl' => array(
                    'title'       => 'waitForFraudControl',
                    'type'        => 'select',
                    'options'     => array(
                        'true'  => 'true',
                        'false' => 'false',
                    ),
                    'default'     => 'false',
                    'description' => 'Bestämmer ifall pluginet ska vänta på att bedrägerikontrollen körs vid bookPayment eller inte',
                    'desc_tip'    => true,
                ),
                'annulIfFrozen' => array(
                    'title'       => 'annulIfFrozen',
                    'type'        => 'select',
                    'options'     => array(
                        'true'  => 'true',
                        'false' => 'false',
                    ),
                    'default'     => 'false',
                    'description' => 'Bestämmer ifall en betalning ska annulleras ifall Resurs Bank API returnerar FROZEN',
                    'desc_tip'    => true,
                ),
                'baseLiveURL' => array(
                    'title'   => 'BaseURL Webservices Live-Environment',
                    'type'    => 'text',
                    'default' => 'https://ecommerce.resurs.com/ws/V4/',
                ),
                'baseTestURL' => array(
                    'title'   => 'BaseURL Webservices Test-Environment',
                    'type'    => 'text',
                    'default' => 'https://test.resurs.com/ecommerce-test/ws/V4/'
                ),
            );
        }

        /**
         * Check the callback event received and perform the appropriate action
         */
        public function check_callback_response()
        {
            global $woocommerce, $wpdb;

            $url_arr = parse_url($_SERVER["REQUEST_URI"]);
            $url_arr['query'] = str_replace('amp;', '', $url_arr['query']);
            parse_str($url_arr['query'], $request);

            $event_type = $request['event-type'];

            if ($event_type === 'check_signing_response') {
                $this->check_signing_response();
                return;
            }

            if ( $event_type === 'PASSWORD_EXPIRATION' ) {
                $check_digest = ( isset( $request['identifier'] ) ? $request['identifier'] : '' ) . get_transient( 'resurs_bank_digest_salt' );
                $check_digest = sha1( $check_digest );
                $check_digest = strtoupper( $check_digest );
            } else {
                $check_digest = $request['paymentId'] . get_transient( 'resurs_bank_digest_salt' );
                $check_digest = sha1( $check_digest );
                $check_digest = strtoupper( $check_digest );
            }

            if ( $request['digest'] !== $check_digest ) {
                header('HTTP/1.1 401 Unauthorized', true, 401);
                exit;
            }

            $args = array(
                'post_type' => 'shop_order',
                'meta_key' => 'paymentId',
                'meta_value' => $request['paymentId'],
            );

            $my_query = new WP_Query( $args );
            $order = new WC_Order( $my_query->posts[0]->ID );

            switch ( $event_type ) {
                case 'UNFREEZE':
                    $order->update_status( 'processing' );
                    break;
                case 'AUTOMATIC_FRAUD_CONTROL':
                    switch ( $request['result'] ) {
                        case 'THAWED':
                            $order->update_status( 'processing', 'AUTOMATIC_FRAUD_CONTROL event returnerade THAWED från Resurs Bank.' );
                            break;
                        case 'FROZEN':
                            $order->update_status( 'on-hold', 'AUTOMATIC_FRAUD_CONTROL event returnerade FROZEN från Resurs Bank.' );
                            break;
                        default:
                            break;
                    }
                    break;
                case 'PASSWORD_EXPIRATION':
                    $new_password = wp_generate_password(16);

                    $password_update_result = $this->update_password( $new_password, $request['identifier'] );
                    $return_class_type = get_class($password_update_result);

                    if ( is_soap_fault($password_update_result) ) {
                        if ( '502' == $password_update_result->detail->ECommerceError->errorTypeId ) {

                        }
                    } else {
                        $settings = get_option('woocommerce_resurs-bank_settings');
                        $settings['password'] = $new_password;
                        update_option('woocommerce_resurs-bank_settings', $settings);
                    }
                    break;
                case 'TEST':
                    break;
                case 'ANNULMENT':
                    $order->update_status( 'cancelled' );
                    $order->cancel_order( 'ANNULMENT event mottaget från Resurs Bank.' );
                    break;
                case 'FINALIZATION':
                    $order->update_status( 'completed', 'FINALIZATION event mottaget från Resurs Bank.' );
                    $order->payment_complete();
                    break;
                default:
                    break;
            }

            $path = plugin_dir_path( __FILE__ ) . '/dump/WC_Resurs_Bank_callback_response_' . $event_type . '_.html';
            $path = str_replace('//', '/', $path);
            //file_put_contents( $path , '<pre>' . var_export($request, true) . '</pre>' );

            //header('HTTP/1.1 204', true, 204);
            header( 'HTTP/1.0 204 No Response' );
        }

        /**
         * Update the password when the PASSWORD_EXPIRATION event was received
         * @param  string $new_password The new password that has been generated and to be passed to Resurs Bank API
         * @param  string $identifier   The password identifier to pass to Resurs Bank API
         * @return stdClass|Exception 	Returns the result from Resurs Bank API on success, Exception object on failure
         */
        public function update_password( $new_password, $identifier = '' )
        {
            if ( false === is_object( $this->configurationService ) ) {
                $this->init_webservice();
            }

            try {
                $params = array(
                    'identifier' => $identifier,
                    'newPassword' => $new_password,
                );

                $result = $this->configurationService->changePassword( $params );

                return $result;
            } catch (Exception $e) {
                return $e;
            }
        }

        /**
         * Register a callback event
         *
         * @param  string $type    The callback type to be registered
         * @param  array  $options The parameters for the SOAP request
         * @throws Exception
         */
        public function register_callback( $type, $options )
        {
            if ( false === is_object( $this->configurationService ) ) {
                $this->init_webservice();
            }
            try {

                $uriTemplate = str_replace( 'https:', 'http:', home_url( '/' ) );
                $uriTemplate = add_query_arg( 'wc-api', 'WC_Resurs_Bank', $uriTemplate );
                $uriTemplate .= '&amp;event-type=' . $type;

                foreach ($options['uri_components'] as $key => $value) {
                    $uriTemplate .= '&amp;' . $key . '=' . '{' . $value . '}';
                }

                $uriTemplate .= '&amp;digest={digest}';

                $uriTemplate = str_replace('/&/', '&amp;', $uriTemplate);

                $params = array(
                    'eventType' => $type,
                    'uriTemplate' => $uriTemplate,
                    'digestConfiguration' => array(
                        'digestAlgorithm' => 'SHA1',
                        'digestParameters' => $this->get_digest_parameters( $options['digest_parameters'] ),
                        'digestSalt' => get_transient( 'resurs_bank_digest_salt' ),
                    ),
                );
                /*var_dump($params);
                echo '<br/>';
                var_dump($params['uriTemplate']);
                echo '<br/>';
                var_dump($params['digestConfiguration']['digestSalt']);
                echo '<br/>';*/

                $unregister = $this->unregister_callback( $type );

                if ( null == $unregister || 8 == $unregister ) {
                    $this->configurationService->registerEventCallback( $params );
                    //var_dump($this->configurationService->__getLastRequest());
                }

            } catch (Exception $e) {
                throw $e;
            }
        }

        /**
         * Get digest parameters for register callback
         *
         * @param  array $params The parameters
         * @return array         The parameters reordered
         */
        public function get_digest_parameters( $params )
        {
            $arr = array();

            foreach ($params as $key => $value) {
                $arr[] = $value;
            }

            return $arr;
        }

        /**
         * Unregister a callback
         *
         * @param  string $type The callback type to be unregistered
         * @return null|int     Returns null on success, else the errorTypeId
         */
        public function unregister_callback( $type )
        {
            if ( false === is_object( $this->configurationService ) ) {
                $this->init_webservice();
            }

            $params = array(
                'eventType' => $type,
            );

            try {
                /*var_dump($this->configurationService, get_class_methods($this->configurationService), $this->configurationService->__getFunctions());
                die();*/
                $this->configurationService->unregisterEventCallback( $params );
                return;
            } catch (Exception $e) {
                return $e->detail->ECommerceError->errorTypeId;
            }
        }

        /**
         * Initialize the web services
         *
         * @param  string $username The username for the API, is fetched from options if not specified
         * @param  string $password The password for the API, is fetched from options if not specified
         * @return boolean          Return whether or not the action succeeded
         */
        public function init_webservice( $username = '', $password = '' )
        {

            if ( empty( $username ) ) {
                $username = get_option( 'woocommerce_resurs-bank_settings' )['login'];
            }

            if ( empty( $password ) ) {
                $password = get_option( 'woocommerce_resurs-bank_settings' )['password'];
            }

            $liveurl = $this->baseLiveURL;
            $testurl = $this->baseTestURL;

            if ( empty( $liveurl ) ) {
                $liveurl = get_option( 'woocommerce_resurs-bank_settings' )['baseLiveURL'];
            }

            if ( empty( $testurl ) ) {
                $testurl = get_option( 'woocommerce_resurs-bank_settings' )['baseTestURL'];
            }

            $serverEnv = $this->serverEnv;

            if ( empty( $serverEnv ) ) {
                $serverEnv = get_option( 'woocommerce_resurs-bank_settings' )['serverEnv'];
            }

            //$url = 'https://' . urlencode($username) . ':' . urlencode($password) . '@' . ( $serverEnv == 'test' ? $testurl : $liveurl );

            $url = ( $serverEnv == 'test' ? $testurl : $liveurl );

            $login_params = array(
                'login'              => $username,
                'password'           => $password,
                'exceptions'         => true,
                'connection_timeout' => 60,
                'trace'              => true,
            );

            try {

                $this->shopFlowService      = new SoapClient( $url . 'ShopFlowService?wsdl', $login_params );

                $this->afterShopFlowService = new SoapClient( $url . 'AfterShopFlowService?wsdl', $login_params );

                $this->configurationService = new SoapClient( $url . 'ConfigurationService?wsdl', $login_params );

                $this->developerWebService  = new SoapClient( $url . 'DeveloperWebService?wsdl', $login_params );

            } catch ( Exception $e ) {
                file_put_contents( plugin_dir_path( __FILE__ ) . 'dump/init_webservice_error.xml', var_export($e, true) );
                return false;
            }

            return true;
        }

        /**
         * Get paymentSpec for startPaymentSession
         *
         * @param  array $cart WooCommerce Cart containing order items
         * @return arrat       The paymentSpec for startPaymentSession
         */
        protected static function get_payment_spec( $cart )
        {
            global $woocommerce, $theorder;

            $spec_lines = self::get_spec_lines( $cart->get_cart() );

            $shipping = (float)$cart->shipping_total;
            $shipping_tax = (float)$cart->shipping_tax_total;
            $shipping_total = (float)( $shipping + $shipping_tax );
            $shipping_tax_pct = @round( $shipping_tax / $shipping, 2 ) * 100;

            if ( false === empty($shipping) ) {

            }

            $spec_lines[] = array(
                'id' => 'frakt',
                'artNo' => '00_frakt',
                'description' => 'Frakt',
                'quantity' => '1',
                'unitMeasure' => 'st',
                'unitAmountWithoutVat' => $shipping,
                'vatPct' => $shipping_tax_pct,
                'totalVatAmount' => $shipping_tax,
                'totalAmount' => $shipping_total,
            );

            $payment_method = $woocommerce->session->chosen_payment_method;
            $payment_options = get_option( 'woocommerce_' . $payment_method . '_settings' );
            $payment_fee = get_option( 'woocommerce_' . $payment_method . '_settings' )['price'];
            $payment_fee = (float)( isset( $payment_fee ) ? $payment_fee : '0' );
            $payment_fee_total = (float)$payment_fee * ( ( $payment_fee_tax_pct / 100 ) + 1 );

            $payment_fee_tax_class = get_option( 'woocommerce_resurs-bank_settings' )['priceTaxClass'];

            $payment_fee_tax_class_rates = $cart->tax->get_rates( $payment_fee_tax_class );

            $payment_fee_tax = $cart->tax->calc_tax($payment_fee, $payment_fee_tax_class_rates, false, true);

            $payment_fee_total_tax = 0;

            foreach ($payment_fee_tax as $value) {
                $payment_fee_total_tax = $payment_fee_total_tax + $value;
            }

            $tax_rates_pct_total = 0;

            foreach ($payment_fee_tax_class_rates as $key => $rate) {
                $tax_rates_pct_total = $tax_rates_pct_total + (float)$rate['rate'];
            }

            /**
             * Payment method fee is added with a row containing the payment method's title. The solution is accepted
             * but the article number and description should actually be named differently. As a start, we are putting
             * this into a specline only if the fee exists. Otherwise it should not be included, since it may look a bit
             * confusing on the invoice.
             */
            if (floatval($payment_fee) > 0) {
                $spec_lines[] = array(
                    'id' => $payment_options['title'],
                    'artNo' => '00_' . str_replace(' ', '_', $payment_options['title']) . "_fee",
                    'description' => $payment_options['priceDescription'],
                    'quantity' => '1',
                    'unitMeasure' => 'st',
                    'unitAmountWithoutVat' => $payment_fee,
                    'vatPct' => $tax_rates_pct_total,
                    'totalVatAmount' => $payment_fee_total_tax,
                    'totalAmount' => $payment_fee_total_tax + $payment_fee,
                );
            }

            if ( $cart->coupons_enabled() ) {
                $coupons = $cart->get_coupons();

                if ( count( $coupons ) > 0 ) {
                    $coupon_values = $cart->coupon_discount_amounts;
                    foreach ($coupons as $code => $coupon) {

                        $post = get_post( $coupon->id );
                        $spec_lines[] = array(
                            'id' => $coupon->id,
                            'artNo' => $coupon->code . '_' . 'kupong',
                            'description' => $post->post_excerpt,
                            'quantity' => 1,
                            'unitMeasure' => 'st',
                            'unitAmountWithoutVat' => (0 - (float)$coupon_values[$code]),
                            'vatPct' => 0,
                            'totalVatAmount' => 0,
                            'totalAmount' => (0 - (float)$coupon_values[$code]),
                        );
                    }
                }
            }
            //$cart->calculate_totals();

            /*$payment_spec = array(
                'specLines' => $spec_lines,
                'totalAmount' => $cart->total,
                'totalVatAmount' => $cart->tax_total,
            );*/
            $ourPaymentSpecCalc = self::calculateSpecLineAmount($spec_lines);
            $payment_spec = array(
                'specLines' => $spec_lines,
                'totalAmount' => $ourPaymentSpecCalc['totalAmount'],
                'totalVatAmount' => $ourPaymentSpecCalc['totalVatAmount'],
            );


            //var_dump($payment_spec, $cart->total, $woocommerce->cart->fees);
            //var_dump($payment_spec);

            return $payment_spec;
        }

        /**
         *
         */
        protected static function calculateSpecLineAmount($specLine = array()) {
            $setPaymentSpec = array();
            if (is_array($specLine) && count($specLine)) {
                foreach ($specLine as $row) {
                    $setPaymentSpec['totalAmount'] += $row['totalAmount'];
                    $setPaymentSpec['totalVatAmount'] += $row['totalVatAmount'];
                }
            }
            return $setPaymentSpec;
        }

        /**
         * Not in use (legacy)
         * @param $coupons
         * @param $products
         */
        protected static function get_coupons_spec($coupons, $products)
        {
            //var_dump(array_values($coupons)[0], get_class_methods(array_values($coupons)[0]));
            return;

        }

        /**
         * Get specLines for startPaymentSession
         *
         * @param  array $cart WooCommerce cart containing order items
         * @return array       The specLines for startPaymentSession
         */
        protected static function get_spec_lines( $cart )
        {
            $spec_lines = array();
            foreach ( $cart as $item ) {
                $data = $item['data'];

                $_tax = new WC_Tax();//looking for appropriate vat for specific product
                $rates = array_shift($_tax->get_rates( $data->get_tax_class() ));
                $vatPct = (double)$rates['rate'];
                $totalVatAmount = ( $data->get_price_excluding_tax() * ( $vatPct / 100 ) );

                $spec_lines[] = array(
                    'id' => $data->id,
                    'artNo' => $data->id,
                    'description' => ( empty($data->post->post_title) ? 'Beskrivning' : $data->post->post_title ),
                    'quantity' => $item['quantity'],
                    'unitMeasure' => 'st',
                    'unitAmountWithoutVat' => $data->get_price_excluding_tax(),
                    'vatPct' => $vatPct,
                    'totalVatAmount' => ( $data->get_price_excluding_tax() * ( $vatPct / 100 ) ),
                    'totalAmount' => ( ( $data->get_price_excluding_tax() * $item['quantity'] ) + ( $totalVatAmount * $item['quantity'] ) ),
                );
            }

            return $spec_lines;
        }

        /**
         * Start a payment session
         *
         * @param  int $payment_id The chosen payment method
         * @return stdClass	The result from Resurs Bank API
         */
        public function start_payment_session( $payment_id )
        {
            global $woocommerce;
            $cart = $woocommerce->cart;
            $preferred_id = uniqid(rand(), true);
            $preferred_id = preg_replace('/\D/i', '', $preferred_id);
            $preferred_id = substr($preferred_id, 0, 25);

            $start_payment_session = array(
                'preferredId' => $preferred_id,
                'paymentMethodId' => $payment_id,
                'customerIpAddress' => self::get_ip_address(),
                'paymentSpec' => $this->get_payment_spec( $cart ),
            );

            if ($this->init_webservice()) {
                file_put_contents( plugin_dir_path( __FILE__ ) . 'dump/shopFlowService.xml', var_export($this->shopFlowService, true) );

                try {
                    $result = $this->shopFlowService->startPaymentSession($start_payment_session);
                    //var_dump($this->shopFlowService->__getLastRequest());
                    //file_put_contents( plugin_dir_path( __FILE__ ) . 'dump/__getLastRequest_startPaymentSession.xml', $this->shopFlowService->__getLastRequest() );
                    return $result;
                } catch (Exception $e) {
                    //var_dump($e, $this->shopFlowService->__getLastRequest());
                    file_put_contents( plugin_dir_path( __FILE__ ) . 'dump/__getLastRequest_startPaymentSession.xml', $this->shopFlowService->__getLastRequest() );
                    file_put_contents( plugin_dir_path( __FILE__ ) . 'dump/__getLastRequest_startPaymentSession_error.xml', var_export($e, true) );
                    wc_add_notice( $e->detail->ECommerceError->userErrorMessage, $notice_type = 'error' );
                    return;
                }
            } else {
                return;
            }
        }

        /**
         * Submit a limit application
         *
         * @param  WC_Order $order The order
         * @return stdClass|null   Returns the result from submitLimitApplication method on success, else null
         */
        public static function submit_limit_application( $order )
        {
            global $woocommerce;
            $order_id = $order->id;

            if ( false === ( $elements = get_transient( $_REQUEST['resurs-bank-payment-session-id'] ) ) ) {
                // Form elements are missing from cache
                wc_add_notice( 'Ett okänt fel uppstod, försök senare', 'error' );
                return;
            }

            if ( '' === $_REQUEST['amount'] ) {
                $order_total = $order->get_total();
            } else {
                $order_total = $_REQUEST['amount'];
            }

            $username = get_option( 'woocommerce_resurs-bank_settings' )['login'];
            $password = get_option( 'woocommerce_resurs-bank_settings' )['password'];

            $liveurl = get_option( 'woocommerce_resurs-bank_settings' )['baseLiveURL'];
            $testurl = get_option( 'woocommerce_resurs-bank_settings' )['baseTestURL'];

            $serverEnv = get_option( 'woocommerce_resurs-bank_settings' )['serverEnv'];

            $url = ( $serverEnv == 'test' ? $testurl : $liveurl );

            try {

                $shopFlowService = new SoapClient( $url . 'ShopFlowService?wsdl', array(
                    'login'              => $username,
                    'password'           => $password,
                    'exceptions'         => true,
                    'connection_timeout' => 60,
                    'trace'              => true,
                ) );
            } catch ( Exception $e ) {
                wc_add_notice( 'Ett okänt fel uppstod, försök senare', 'error' );
                return;
            }

            $form_data_response = '<![CDATA[
										<resurs-response>
										    <amount>' . $order_total . '</amount>
										';

            foreach ($elements as $key => $value) {
                if ( $key !== 'amount' ) {
                    $form_data_response .= '<' . $key . '>';
                    $form_data_response .= $_REQUEST[$key];
                    $form_data_response .= '</' . $key . '>';
                }
            }

            $form_data_response .= '</resurs-response>
								         ]]>';
            $params = array(
                'paymentSessionId' => $_REQUEST['resurs-bank-payment-session-id'],
                'yourCustomerId' => '?',
                'formDataResponse' => new SoapVar('<formDataResponse>' . $form_data_response . '</formDataResponse>', XSD_ANYXML),
                'billingAddress' => array(
                    'fullName' => $_REQUEST['billing_last_name'] . ' ' . $_REQUEST['billing_first_name'],
                    'firstName' => $_REQUEST['billing_first_name'],
                    'lastName' => $_REQUEST['billing_last_name'],
                    'addressRow1' => $_REQUEST['billing_address_1'],
                    'addressRow2' => ( empty($_REQUEST['billing_address_2']) ? '?' : $_REQUEST['billing_address_2'] ),
                    'postalArea' => $_REQUEST['billing_city'],
                    'postalCode' => $_REQUEST['billing_postcode'],
                    'country' => $_REQUEST['billing_country'],
                ),
            );

            try {
                $submit_limit_application_result = $shopFlowService->submitLimitApplication($params);
            } catch (Exception $e) {
                wc_add_notice( 'Ett okänt fel uppstod, försök senare', 'error' );
                return;
            }

            $customer_address = $submit_limit_application_result->return->customer->address;

            update_post_meta( $order_id, '_billing_first_name', $customer_address->firstName );
            update_post_meta( $order_id, '_billing_last_name', $customer_address->lastName );
            update_post_meta( $order_id, '_billing_address_1', $customer_address->addressRow1 );
            if ( isset( $customer_address->addressRow2 ) ) {
                update_post_meta( $order_id, '_billing_address_2', $customer_address->addressRow2 );
            }
            update_post_meta( $order_id, '_billing_city', $customer_address->postalArea );
            update_post_meta( $order_id, '_billing_postcode', $customer_address->postalCode );
            update_post_meta( $order_id, '_billing_country', $customer_address->country );

            if ( false === isset($_REQUEST['ship_to_different_address']) ) {
                update_post_meta( $order_id, '_shipping_first_name', $customer_address->firstName );
                update_post_meta( $order_id, '_shipping_last_name', $customer_address->lastName );
                update_post_meta( $order_id, '_shipping_address_1', $customer_address->addressRow1 );
                if ( isset( $customer_address->addressRow2 ) ) {
                    update_post_meta( $order_id, '_shipping_address_2', $customer_address->addressRow2 );
                }
                update_post_meta( $order_id, '_shipping_city', $customer_address->postalArea );
                update_post_meta( $order_id, '_shipping_postcode', $customer_address->postalCode );
                update_post_meta( $order_id, '_shipping_country', $customer_address->country );
            }

            return $submit_limit_application_result;

            //var_dump('Result from submitLimitApplication', $submit_limit_application_result);
            /*file_put_contents( plugin_dir_path( __FILE__ ) . '../dump/' . $className . '__getLastRequest_submit_limit.xml', $this->shopFlowService->__getLastRequest() );
            file_put_contents( plugin_dir_path( __FILE__ ) . '../dump/' . $className . '_SOAP_submit_limit.html', '<pre>' . var_export( $this->shopFlowService, true ) . '</pre>' );*/
        }

        /**
         * Proccess the payment
         *
         * @param  int $order_id WooCommerce order ID
         * @return null|array    Null on failure, array on success
         */
        public function process_payment( $order_id )
        {
            global $woocommerce;
            $order = new WC_Order( $order_id );
            $customer = $woocommerce->customer;
            $className = $_REQUEST['payment_method'];

            $payment_settings = get_option( 'woocommerce_' . $className . '_settings' );

            if ( false === is_object( $this->shopFlowService ) ) {
                $this->init_webservice();
            }

            /* submitLimitApplication */

            $submit_limit_application_result = self::submit_limit_application( $order );

            if ( false === is_object($submit_limit_application_result) ) {
                wc_add_notice( 'Ett okänt fel uppstod, försök senare', 'error' );
                return;
            }

            switch ($submit_limit_application_result->return->decision) {
                case 'GRANTED':
                    break;
                case 'DENIED' || 'TRIAL':
                    setcookie($className . '_denied', 'denied', strtotime('+20 minutes'), '/' );
                    wc_add_notice( 'Denna betalningsmetod är inte tillgänglig för dig, vänligen välj en annan,', 'error' );
                    $order->update_status( 'failed' );
                    unset(WC()->session->order_awaiting_payment);
                    return;
                    break;
                default:
                    wc_add_notice( 'Ett okänt fel uppstod, försök senare', 'error' );
                    return;
                    break;
            }

            /* END submitLimitApplication */

            // SET DELIVERY ADDRESS

            if ( isset( $_REQUEST['ship_to_different_address'] ) ) {
                $delivery_params = array(
                    'paymentSessionId' => $_REQUEST['resurs-bank-payment-session-id'],
                    'address' => array(
                        'fullName' => $_REQUEST['shipping_last_name'] . ' ' . $_REQUEST['shipping_first_name'],
                        'firstName' => $_REQUEST['shipping_first_name'],
                        'lastName' => $_REQUEST['shipping_last_name'],
                        'addressRow1' => $_REQUEST['shipping_address_1'],
                        'addressRow2' => ( empty($_REQUEST['shipping_address_2']) ? '' : $_REQUEST['shipping_address_2'] ),
                        'postalArea' => $_REQUEST['shipping_city'],
                        'postalCode' => $_REQUEST['shipping_postcode'],
                        'country' => $_REQUEST['shipping_country'],
                    )
                );

                if ( empty( $_REQUEST['shipping_address_2'] ) ) {
                    unset( $delivery_params['address']['addressRow2'] );
                }

                try {
                    $set_delivery_result = $this->shopFlowService->setDeliveryAddress($delivery_params);
                } catch (Exception $e) {
                    wc_add_notice( 'Ett okänt fel uppstod, försök senare', 'error' );
                    return;
                }
            }

            // PREPARE SIGNING
            $success_url = str_replace( 'https:', 'http:', home_url( '/' ) );
            $success_url = add_query_arg( 'wc-api', 'WC_Resurs_Bank', $success_url );
            $success_url = add_query_arg( 'order_id', $order_id, $success_url );
            $success_url = add_query_arg( 'payment_session_id', $_REQUEST['resurs-bank-payment-session-id'], $success_url );
            $success_url = add_query_arg( 'utm_nooverride', '1', $success_url );
            $success_url = add_query_arg( 'event-type', 'check_signing_response', $success_url );

            $prepare_signing_params = array(
                'paymentSessionId' => $_REQUEST['resurs-bank-payment-session-id'],
                'successUrl' => $success_url,
                'failUrl' => html_entity_decode($order->get_cancel_order_url()),
            );

            //var_dump($prepare_signing_params);

            try {
                $prepare_signing_result = $this->shopFlowService->prepareSigning($prepare_signing_params);
                //var_dump($this->shopFlowService->__getLastRequest());
                //die();
            } catch (Exception $e) {
                wc_add_notice( 'ett fel inträffade vid prepareSigning', 'error' );
                //wc_add_notice( $e->detail->ECommerceError->userErrorMessage, 'error' );
                return;
            }

            //var_dump('Result from prepareSigning', $prepare_signing_result);
            if ( true === isset($prepare_signing_result->return) ) {
                return array(
                    'result' => 'success',
                    'redirect' => $prepare_signing_result->return,
                );
            }

            /*file_put_contents( plugin_dir_path( __FILE__ ) . '../dump/' . $className . '__getLastRequest_prepeare_signing.xml', $this->shopFlowService->__getLastRequest() );
            file_put_contents( plugin_dir_path( __FILE__ ) . '../dump/' . $className . '_SOAP_prepeare_signing.html', '<pre>' . var_export( $this->shopFlowService, true ) . '</pre>' );*/

            // BOOK PAYMENT
            $book_payment_params = array(
                'paymentSessionId' => $_REQUEST['resurs-bank-payment-session-id'],
                'waitForFraudControl' => ( get_option( 'woocommerce_resurs-bank_settings' )['waitForFraudControl'] === 'false' ? false : true ),
                'annulIfFrozen' => ( get_option( 'woocommerce_resurs-bank_settings' )['annulIfFrozen'] === 'false' ? false : true ),
                'priority' => '1',
            );

            try {
                $book_payment_result = $this->shopFlowService->bookPayment($book_payment_params);
            } catch (Exception $e) {
                wc_add_notice( 'ett fel inträffade vid bookPayment', 'error' );
                //wc_add_notice( $e->detail->ECommerceError->userErrorMessage, 'error' );
                return;
            }

            /*file_put_contents( plugin_dir_path( __FILE__ ) . '../dump/' . $className . '__getLastRequest_book_payment.xml', $this->shopFlowService->__getLastRequest() );
            file_put_contents( plugin_dir_path( __FILE__ ) . '../dump/' . $className . '_SOAP__book_payment.html', '<pre>' . var_export( $this->shopFlowService, true ) . '</pre>' );

            file_put_contents( plugin_dir_path( __FILE__ ) . '../dump/' . $className . '_SOAP_this.html', '<pre>' . var_export( $this, true ) . '</pre>' );
            file_put_contents( plugin_dir_path( __FILE__ ) . '../dump/' . $className . '_SOAP_this_methods.html', '<pre>' . var_export( get_class_methods( $this ),
             ) . '</pre>' );*/

            update_post_meta( $order_id, 'paymentId', $book_payment_result->return->paymentId );

            switch ($book_payment_result->return->fraudControlStatus) {
                case 'NOT_FROZEN':
                    //$order->payment_complete();
                    $order->update_status( 'processing' );
                    return array(
                        'result'   => 'success',
                        'redirect' => $this->get_return_url( $order ),
                    );
                    break;

                case 'CONTROL_IN_PROGRESS':
                    /*wc_add_notice( 'The fraud control is still in progress, please, wait for it to complete', 'error' );
                    return;*/
                    $order->update_status( 'on-hold' );
                    return array(
                        'result'   => 'success',
                        'redirect' => $this->get_return_url( $order ),
                    );
                    break;

                case 'SIGNING_REQUIRED':
                    return array(
                        'result' => 'success',
                        'redirect' => $prepare_signing_result->return,
                    );
                    break;

                case 'FROZEN':
                    /*wc_add_notice( 'Payment is frozen for further investigation', 'error' );
                    return;*/
                    $order->update_status( 'on-hold' );
                    return array(
                        'result'   => 'success',
                        'redirect' => $this->get_return_url( $order ),
                    );
                    break;

                default:
                    wc_add_notice( 'Ett okänt fel uppstod, försök senare', 'error' );
                    return;
                    break;
            }
        }

        /**
         * Check result of signing, book the payment and complete the order
         */
        public function check_signing_response()
        {
            global $woocommerce;
            $order_id = $_REQUEST['order_id'];
            $payment_session_id = $_REQUEST['payment_session_id'];
            $order = new WC_Order( $order_id );

            $book_payment_params = array(
                'paymentSessionId' => $payment_session_id,
                'waitForFraudControl' => ( get_option( 'woocommerce_resurs-bank_settings' )['waitForFraudControl'] === 'false' ? false : true ),
                'annulIfFrozen' => ( get_option( 'woocommerce_resurs-bank_settings' )['annulIfFrozen'] === 'false' ? false : true ),
                'priority' => '1',
            );

            if ( false === is_object( $this->shopFlowService ) ) {
                $this->init_webservice();
            }

            try {
                $book_payment_result = $this->shopFlowService->bookPayment($book_payment_params);
            } catch (Exception $e) {
                throw $e;
            }

            update_post_meta( $order_id, 'paymentId', $book_payment_result->return->paymentId );

            switch ($book_payment_result->return->fraudControlStatus) {
                case 'NOT_FROZEN':
                    //$order->payment_complete();
                    $order->update_status( 'processing' );
                    wp_safe_redirect( $this->get_return_url( $order ) );
                    return;
                    break;

                case 'CONTROL_IN_PROGRESS':
                    //$order->payment_complete();
                    //$order->update_status( 'on-hold', 'Väntar på automatisk bedrägerikontroll' );
                    $order->update_status( 'on-hold' );
                    wp_safe_redirect( $this->get_return_url( $order ) );
                    return;
                    break;

                case 'FROZEN':
                    $order->update_status( 'on-hold', 'Betalningen är frusen i väntan på manuell kontroll' );
                    //wc_add_notice( 'Payment is frozen for further investigation', 'error' );
                    wp_safe_redirect( $this->get_return_url( $order ) );
                    return;
                    break;

                default:
                    wc_add_notice( 'Ett okänt fel uppstod, försök senare', 'error' );
                    return;
                    break;
            }
        }

        /**
         * Generate the payment methods that were returned from Resurs Bank API
         *
         * @param  array $payment_methods The payment methods
         */
        public function generate_payment_gateways( $payment_methods )
        {
            $methods     = array();
            $class_files = array();

            foreach ($payment_methods as $payment_method) {
                $methods[]     = 'resurs-bank-id-' . $payment_method->id;
                $class_files[] = 'resurs_bank_nr_' . $payment_method->id . '.php';
                $class         = $this->write_class_to_file( $payment_method );
            }

            set_transient( 'resurs_bank_class_files', $class_files );
        }

        /**
         * Generates and writes a class for a specified payment methods to file
         *
         * @param  stdClass $payment_method A payment method return from Resurs Bank API
         */
        public function write_class_to_file( $payment_method )
        {
            $class_name = 'resurs_bank_nr_' . $payment_method->id;
            if ( !file_exists( plugin_dir_path( __FILE__ ) . '/includes/' . $class_name ) ) {

            } else {
                if ( !in_array( plugin_dir_path( __FILE__ ) . '/includes/' . $class_name, get_included_files() ) ) {
                    include( plugin_dir_path( __FILE__ ) . '/includes/' . $class_name );
                }
            }

            $initName = 'woocommerce_gateway_resurs_bank_nr_' . $payment_method->id . '_init';
            $class_name = 'resurs_bank_nr_' . $payment_method->id;
            $methodId  = 'resurs-bank-method-nr-' . $payment_method->id;
            $method_name = $payment_method->description;
            $type = strtolower( $payment_method->type );
            $customerType = $payment_method->customerType;

            $icon_name = strtolower($method_name);
            $icon_name = str_replace(array('å', 'ä', 'ö', ' '), array('a', 'a', 'o', '_'), $icon_name);
            $path_to_icon = $this->icon = apply_filters( 'woocommerce_resurs_bank_' . $type . '_checkout_icon',  $this->plugin_url() . '/img/' . $icon_name . '.png');

            $temp_icon = plugin_dir_path( __FILE__ ) . 'img/' . $icon_name . '.png';
            $has_icon = (string)file_exists($temp_icon);

            // Legal links
            $legal_info_links = 'array(';

            if (property_exists($payment_method, 'legalInfoLinks')) {
                foreach ($payment_method->legalInfoLinks as $link) {
                    $legal_info_links .= "array(
										'appendPriceLast' => '$link->appendPriceLast',
										'endUserDescription' => '$link->endUserDescription',
										'url' => '$link->url',
									),";
                }
            }

            $legal_info_links .= ')';
            $test_class = '<?php class ' . $class_name . '{function test(){echo "hello";}}';
            $class = <<<EOT
<?php
	class {$class_name} extends WC_Resurs_Bank {
		public function __construct()
		{
			\$this->id           = '{$class_name}';
			\$this->has_icon();
			//\$this->icon         = '{$path_to_icon}';
			\$this->method_title = '{$method_name}';
			\$this->has_fields   = true;

			\$this->legal_info_links = {$legal_info_links};

			\$this->init_form_fields();
			\$this->init_settings();

			\$this->title       = \$this->get_option( 'title' );
			\$this->description = \$this->get_option( 'description' );

			if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
				add_action( 'woocommerce_update_options_payment_gateways_' . \$this->id, array( \$this, 'process_admin_options' ) );
			} else {
				add_action( 'woocommerce_update_options_payment_gateways', array( \$this, 'process_admin_options' ) );
			}
			//add_action( 'woocommerce_calculate_totals', array( \$this, 'calculate_totals' ), 10, 1 );
			// Payment listener/API hook

			add_action( 'woocommerce_api_{$class_name}', array( \$this, 'check_signing_response' ) );
		}

		function init_form_fields() {
			\$this->form_fields = array(
				'enabled' => array(
						'title' => __('Enable/Disable', 'woocommerce'),
						'type'  => 'checkbox',
						'label' => 'Aktivera Resurs Bank {$method_name}',
					),
				'title' => array(
						'title'       => 'Title',
						'type'        => 'text',
						'default'     => 'Resurs Bank {$method_name}',
						'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce' ),
						'desc_tip'    => true,
					),
				'description' => array(
						'title'       => 'Description',
						'type'        => 'textarea',
						'default'     => 'Betala med Resurs Bank {$method_name}',
						'description' => __( 'This controls the description which the user sees during checkout.', 'woocommerce' ),
						'desc_tip'    => true,
					),
				'price' => array(
						'title'       => 'Avgift',
						'type'        => 'number',
						'default'     => 0,
						'description' => 'Avgift för att använda betalningsalternativet (exkl. moms)',
						'desc_tip'    => false,
					),
				'priceDescription' => array(
						'title'   => 'Beskrivning för betalningsalternativets avgift',
						'type'    => 'textarea',
						'default' => '',
					),
			);
		}

		public function calculate_totals( \$totals )
		{
			global \$woocommerce;
		    \$available_gateways = \$woocommerce->payment_gateways->get_available_payment_gateways();
		    \$current_gateway = '';
		    if ( ! empty( \$available_gateways ) ) {
		        // Chosen Method
		        if ( isset( \$woocommerce->session->chosen_payment_method ) && isset( \$available_gateways[ \$woocommerce->session->chosen_payment_method ] ) ) {
		            \$current_gateway = \$available_gateways[ \$woocommerce->session->chosen_payment_method ];
		        } elseif ( isset( \$available_gateways[ get_option( 'woocommerce_default_gateway' ) ] ) ) {
		            \$current_gateway = \$available_gateways[ get_option( 'woocommerce_default_gateway' ) ];
		        } else {
		            \$current_gateway =  current( \$available_gateways );

		        }
		    }
		    if(\$current_gateway!=''){
		        \$current_gateway_id = \$current_gateway->id;
		        \$extra_charges_id = 'woocommerce_' . \$current_gateway_id . '_settings';
		        \$extra_charges = (float)get_option( \$extra_charges_id)['price'];
		        //var_dump(\$extra_charges, \$extra_charges_id);
		        if(\$extra_charges){
		            \$totals->cart_contents_total = \$totals->cart_contents_total + \$extra_charges;
		            \$this->current_gateway_title = \$current_gateway -> title;
		            \$this->current_gateway_extra_charges = \$extra_charges;
		            add_action( 'woocommerce_review_order_before_order_total',  array( \$this, 'add_payment_gateway_extra_charges_row'));
		        }

		    }
		    return \$totals;
		}

		public function add_payment_gateway_extra_charges_row()
		{
			?>
		    <tr class="payment-extra-charge">
		        <th><?php echo \$this->current_gateway_title?> Extra Charges</th>
		        <td><?php echo woocommerce_price(\$this->current_gateway_extra_charges); ?></td>
			 </tr>
			 <?php
		}

		public function get_current_gateway()
		{
			global \$woocommerce;
			\$available_gateways = \$woocommerce->payment_gateways->get_available_payment_gateways();
			\$current_gateway = null;
			\$default_gateway = get_option( 'woocommerce_default_gateway' );
			if ( ! empty( \$available_gateways ) ) {
				
			   // Chosen Method
				if ( isset( \$woocommerce->session->chosen_payment_method ) && isset( \$available_gateways[ \$woocommerce->session->chosen_payment_method ] ) ) {
					\$current_gateway = \$available_gateways[ \$woocommerce->session->chosen_payment_method ];
				} elseif ( isset( \$available_gateways[ \$default_gateway ] ) ) {
					\$current_gateway = \$available_gateways[ \$default_gateway ];
				} else {
					\$current_gateway = current( \$available_gateways );
				}
			}
			if ( ! is_null( \$current_gateway ) )
				return \$current_gateway;
			else 
				return false;
		}

		public function has_icon()
		{
			if ( file_exists( '{$temp_icon}' ) ) {
				\$this->icon = '{$path_to_icon}';
			}
			if ( '1' == '{$has_icon}' ) {
			}
		}

		public function payment_fields()
		{
			global \$woocommerce;
			\$cart = \$woocommerce->cart;
			//var_dump(\$woocommerce->session->chosen_payment_method, \$_REQUEST);
			if ( isset( \$_COOKIE['{$class_name}_denied'] ) ) {
				echo '<p>Denna betalningsmetod är inte tillgänglig för dig, vänligen välj en annan</p>';
				return;
			}

			//\$woocommerce->session->chosen_payment_method, {$class_name}
			if (isset(\$_REQUEST) && isset(\$_REQUEST['payment_method'])) {
				if (\$_REQUEST['payment_method'] === '{$class_name}') {
					\$payment_session = \$this->start_payment_session( '{$payment_method->id}' );

					\$cache_element = array();

					if ( false === is_array( \$payment_session->return->limitApplicationFormAsObjectGraph->formElement ) ) {
						echo 'Ett okänt fel uppstod, försök senare';
					} else {
						foreach (\$payment_session->return->limitApplicationFormAsObjectGraph->formElement as \$key => \$value) {
						    /* The streamliner - Defines visible fields, not inherited from any WooFormField (required by user input) */
							\$streamLine = array('applicant-government-id', 'card-number', 'applicant-full-name', 'contact-government-id');
							\$doDisplay = "none";
							if (in_array(\$value->name, \$streamLine)) {
								\$doDisplay = "block";
							}
							switch (\$value->type) {
								case 'heading':
									//echo '<h5>' . \$value->label . '</h5>';
									echo '<div>';
									echo \$this->description;
									echo '</div>';
									break;
								case 'text':
									echo '<div style="display:'.\$doDisplay.';width:100%;" class="resurs_bank_payment_field_container">';
									\$cache_element[\$value->name] = \$value;
									\$temp_label = '<label for="' . \$value->name . '" style="width:100%;display:block;">';
									\$temp_label .= \$value->label;
									\$temp_label .= ( \$value->mandatory ? ' *' : '' );
									\$temp_label .= '</label>';
									echo \$temp_label;
									echo '<input id="' . \$value->name . '" type="' . \$value->type . '" name="' . \$value->name . '">';
									echo '</div>';
									break;
								case 'list':
									echo '<div style="display:' . \$doDisplay . ';width:100%;" class="resurs_bank_payment_field_container">';
									\$cache_element[\$value->name] = \$value;
									\$temp_label = '<label for="' . \$value->name . '" style="width:100%;display:block;">';
									\$temp_label .= \$value->label;
									\$temp_label .= '</label>';
									echo \$temp_label;
									echo '<select id="' . \$value->name . '" name="' . \$value->name . '">';
									foreach ( \$value->option as \$valueTwo ) {
										echo '<option value="' . \$valueTwo->value . '">';
										echo \$valueTwo->label;
										echo '</option>';
									}
									echo '</select>';
									echo '</div>';
									break;
								case 'hidden':
									echo '<div>';
									echo '<input type="' . \$value->type . '" name="' . \$value->name . '" value="' . '' . '">';
									echo '</div>';
									break;
								default:
									break;
							}
						}
						echo '<div>* obligatorisk</div>';

						if ( strtoupper('{$type}') === 'INVOICE' ) {
							echo 'Om du väljer faktura från Resurs Bank så kommer din folkbokföringsadress att sättas till orders faktureringsadress.';
							echo '<br/>';
						}

						foreach (\$this->legal_info_links as \$link) {
							echo '<a class="resursBankLegalLink" href="#" onClick="window.open(\'' . \$link['url'] . ( \$link['appendPriceLast'] ? \$cart->total : '' ) . '\', \'mywindow\',\'width=950,height=400,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,copyhistory=no,resizable=yes\')">' . \$link['endUserDescription'] . '</a>';
							echo '<br/>';
						}

						/*\$legal_link_script = '<script type="text/javascript">';
						\$legal_link_script .= 'jQuery.noConflict();';
						\$legal_link_script .= '\$( document ).ready( function( \$ ) {
								var links = \$(".resursBankLegalLink");
								console.log(links);
							} );';
						\$legal_link_script .= '</script>';
						echo \$legal_link_script;*/

						echo '<input type="hidden" name="resurs-bank-payment-session-id" value="' . \$payment_session->return->id . '">';
						set_transient(\$payment_session->return->id, \$cache_element, 2 * HOUR_IN_SECONDS);
						echo '<input type="hidden" value="{$payment_method->id}" class="resurs-bank-payment-method">';
					}
				}
			}
		}

		public function admin_options()
		{
			?>
			<h3><?php echo \$this->method_title; ?></h3>
			<p>På denna sida kan du ändra inställningar för Resurs Bank {$method_name}</p>

				<table class="form-table">

					<?php \$this->generate_settings_html(); ?>

				</table>

			<?php
		}

		public static function interfere_checkout()
		{
		}

		public static function interfere_checkout_review( \$value )
		{
		}

		public static function interfere_update_order_review( \$posted )
		{
			global \$woocommerce;
			if (isset(\$_REQUEST)) {
				if (\$_REQUEST['payment_method'] === '{$class_name}') {
					\$payment_method = \$_REQUEST['payment_method'];
					\$payment_fee = get_option( 'woocommerce_' . \$payment_method . '_settings' )['price'];
					\$payment_fee = (float)( isset( \$payment_fee ) ? \$payment_fee : '0' );
					//\$payment_fee_tax_pct = (float)get_option( 'woocommerce_resurs-bank_settings' )['pricePct'];
					//\$payment_fee_total = (float)\$payment_fee * ( ( \$payment_fee_tax_pct / 100 ) + 1 );

					\$payment_fee_tax_class = get_option( 'woocommerce_resurs-bank_settings' )['priceTaxClass'];

					\$payment_fee_tax_class_rates = \$woocommerce->cart->tax->get_rates( \$payment_fee_tax_class );

					\$payment_fee_tax = \$woocommerce->cart->tax->calc_tax(\$payment_fee, \$payment_fee_tax_class_rates);

		        	if ( false === empty( get_option( 'woocommerce_{$class_name}_settings' )['priceDescription'] ) ) {
						\$fee_title = get_option( 'woocommerce_{$class_name}_settings' )['priceDescription'];
					} else {
						\$fee_title = get_option( 'woocommerce_{$class_name}_settings' )['title'];
					}
					\$woocommerce->cart->add_fee( \$fee_title, \$payment_fee, true, \$payment_fee_tax_class );
				}
			}
		}

		public static function interfere_checkout_process( \$posted )
		{
			global \$woocommerce;
			if (isset(\$_REQUEST)) {
				if (\$_REQUEST['payment_method'] === '{$class_name}') {
					\$payment_method = \$_REQUEST['payment_method'];
					\$payment_fee = get_option( 'woocommerce_' . \$payment_method . '_settings' )['price'];
					\$payment_fee = (float)( isset( \$payment_fee ) ? \$payment_fee : '0' );
					//\$payment_fee_tax_pct = (float)get_option( 'woocommerce_resurs-bank_settings' )['pricePct'];
					\$payment_fee_total = (float)\$payment_fee * ( ( \$payment_fee_tax_pct / 100 ) + 1 );
					\$payment_fee_tax = (float)\$payment_fee * ( \$payment_fee_tax_pct / 100 );

					\$payment_fee_tax_class = get_option( 'woocommerce_resurs-bank_settings' )['priceTaxClass'];

					if ( false === empty( get_option( 'woocommerce_{$class_name}_settings' )['priceDescription'] ) ) {
						\$fee_title = get_option( 'woocommerce_{$class_name}_settings' )['priceDescription'];
					} else {
						\$fee_title = get_option( 'woocommerce_{$class_name}_settings' )['title'];
					}

					\$woocommerce->cart->add_fee( \$fee_title, \$payment_fee, true, \$payment_fee_tax_class );
				}
			}
		}
	}

	function woocommerce_add_resurs_bank_gateway_{$class_name}( \$methods ) {
		if ( 'no' == get_option( 'woocommerce_resurs-bank_settings' )['enabled']) {
			return \$methods;
		}

		if ( isset( \$_COOKIE['{$class_name}_denied'] ) ) {
			return \$methods;
		}
		\$methods[] = '{$class_name}';
		return \$methods;
	}

	add_filter( 'woocommerce_payment_gateways', 'woocommerce_add_resurs_bank_gateway_{$class_name}' );
	add_action( 'woocommerce_checkout_process', '{$class_name}::interfere_checkout',0 );
	add_action( 'woocommerce_checkout_order_review', '{$class_name}::interfere_checkout_review', 1 );
	add_action( 'woocommerce_checkout_update_order_review', '{$class_name}::interfere_update_order_review', 1 );
	add_action( 'woocommerce_checkout_process', '{$class_name}::interfere_checkout_process', 1 );

	/* For WooCommerce updated after 1.5.x */
	add_action( 'woocommerce_cart_calculate_fees', '{$class_name}::interfere_update_order_review', 1 );
EOT;

            $path = plugin_dir_path( __FILE__ ) . '/includes/' . $class_name . '.php';
            $path = str_replace('//', '/', $path);

            file_put_contents( $path , $class );
        }

        /**
         * Output the payment fields on the checkout page
         * THIS FUNCTION IS NOT USED
         */
        public function payment_fields()
        {
            ?>

            <p>
                <?php echo $this->description; ?>
            </p>

            <?php
        }

        /**
         * Validate the payment fields
         *
         * Never called from within this class, only by those that extends from this class and that are created in write_class_to_file
         *
         * @return boolean Whether or not the validation passed
         */
        public function validate_fields()
        {
            global $woocommerce;
            $className = $_REQUEST['payment_method'];

            if ( false === ( $elements = get_transient( $_REQUEST['resurs-bank-payment-session-id'] ) ) ) {
                // Form elements are missing from cache
                wc_add_notice( 'Ett okänt fel uppstod, försök senare', 'error' );
                return;
            }

            $has_errors = false;

            foreach ($elements as $key => $value) {
                if ( preg_match( '/email/', $key) ) {
                    //var_dump( filter_var( $_REQUEST[ $key ], FILTER_VALIDATE_EMAIL ) );
                    if ( filter_var( $_REQUEST[ $key ], FILTER_VALIDATE_EMAIL ) ) {
                        //var_dump('MATCH');
                    } else {
                        //var_dump('NO MATCH');
                        wc_add_notice( '<strong>' . $value->label . '</strong>' . ' är inte giltigt.', 'error' );
                        $has_errors = true;
                    }

                } else {
                    //var_dump($key, $_REQUEST[ $key ], $value);
                    /*if ( preg_match( '/government-id/', $key) ) {
                        $regex = '^(18\d{2}|19\d{2}|20\d{2}|\d{2})(0[1-9]|1[0-2])([0][1-9]|[1-2][0-9]|3[0-1])(\-|\+)?([\d]{4})$';
                    } elseif ( preg_match( '/full-name/', $key ) ) {
                        $regex = '^[A-ZÅÄÖÜ\- a-zåäöü]{1,100}$';
                    } elseif ( preg_match( '/number/', $key ) ) {
                        $regex = '^((0|\+46)[ |-]?(200|20|70|73|76|74|[1-9][0-9]{0,2})([ |-]?[0-9]){5,8})?$';
                    } else {

                    }*/

                    $regex = $value->format;

                    $regex = str_replace('\\\\', '\\', $regex);
                    //var_dump($regex);
                    //var_dump( preg_match( '/' . $value->format . '/', $_REQUEST[ $key ] ) );
                    if ( preg_match( '/' . $regex . '/', $_REQUEST[ $key ] ) ) {
                        //var_dump('MATCH');
                    } else {
                        //var_dump('NO MATCH');
                        wc_add_notice( '<strong>' . $value->label . '</strong>' . ' är inte giltigt.', 'error' );
                        $has_errors = true;
                    }
                }
            }

            if ( $has_errors ) {
                return false;
            }

            return true;
        }

        /**
         * Check if plugin is valid for use
         *
         * NOT IMPLEMENTED
         *
         * @return boolean Whether or nut the plugin is valid
         */
        function is_valid_for_use()
        {
            return true;
        }

        /**
         * http://stackoverflow.com/questions/1634782/what-is-the-most-accurate-way-to-retrieve-a-users-correct-ip-address-in-php?rq=1
         * Retrieves the best guess of the client's actual IP address.
         * Takes into account numerous HTTP proxy headers due to variations
         * in how different ISPs handle IP addresses in headers between hops.
         */
        public static function get_ip_address() {
            // check for shared internet/ISP IP
            if ( !empty( $_SERVER['HTTP_CLIENT_IP'] ) && self::validate_ip( $_SERVER['HTTP_CLIENT_IP'] ) ) {
                return $_SERVER['HTTP_CLIENT_IP'];
            }

            // check for IPs passing through proxies
            if ( !empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
                // check if multiple ips exist in var
                $iplist = explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] );
                foreach ( $iplist as $ip ) {
                    if ( self::validate_ip( $ip ) ) {
                        return $ip;
                    }
                }
            }

            if (!empty($_SERVER['HTTP_X_FORWARDED']) && self::validate_ip($_SERVER['HTTP_X_FORWARDED'])) {
                return $_SERVER['HTTP_X_FORWARDED'];
            }
            if (!empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']) && self::validate_ip($_SERVER['HTTP_X_CLUSTER_CLIENT_IP'])) {
                return $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
            }
            if (!empty($_SERVER['HTTP_FORWARDED_FOR']) && self::validate_ip($_SERVER['HTTP_FORWARDED_FOR'])) {
                return $_SERVER['HTTP_FORWARDED_FOR'];
            }
            if (!empty($_SERVER['HTTP_FORWARDED']) && self::validate_ip($_SERVER['HTTP_FORWARDED'])) {
                return $_SERVER['HTTP_FORWARDED'];
            }

            // return unreliable ip since all else failed
            return $_SERVER['REMOTE_ADDR'];
        }

        /**
         * Ensures an ip address is both a valid IP and does not fall within
         * a private network range.
         *
         * @access public
         * @param  string $ip
         */
        public static function validate_ip($ip) {
            if (filter_var($ip, FILTER_VALIDATE_IP,
                    FILTER_FLAG_IPV4 |
                    FILTER_FLAG_IPV6 |
                    FILTER_FLAG_NO_PRIV_RANGE |
                    FILTER_FLAG_NO_RES_RANGE) === false) {
                return false;
            }

            self::$ip = $ip;
            return true;
        }

        /**
         * Output the admin options for the plugin. Also used for checking for various buttonclicks, for example registering callbacks
         */
        public function admin_options()
        {
            $url = admin_url('admin.php');
            $url = add_query_arg( 'page', $_REQUEST['page'], $url );
            $url = add_query_arg( 'tab', $_REQUEST['tab'], $url );
            $url = add_query_arg( 'section', $_REQUEST['section'], $url );

            if ( isset( $_REQUEST['woocommerce_resurs-bank_registerCallbacksButton'] ) ) {
                $salt = uniqid(mt_rand(), true);
                set_transient( 'resurs_bank_digest_salt', $salt );
                foreach ($this->callback_types as $callback => $options) {
                    $this->register_callback( $callback, $options );
                }
            }

            if ( isset( $_REQUEST['woocommerce_resurs-bank_refreshPaymentMethods'] ) ) {
                $this->paymentMethods = $this->get_payment_methods( true );
                if ( empty( $this->paymentMethods['error'] ) ) {
                    if ( true === $this->paymentMethods['generate_new_files'] ) {
                        $this->generate_payment_gateways( $this->paymentMethods['methods'] );
                        wp_safe_redirect( $url );
                    }
                }
            }

            if ( isset( $_REQUEST['save'] ) ) {
                wp_safe_redirect( $url );
            }

            /*if ( isset( $_REQUEST['woocommerce_resurs-bank_changeTestValue'] ) ) {
                $new_test = wp_generate_password();
                $old_test = get_option( 'woocommerce_resurs-bank_settings' )['test'];
                var_dump('changeTestValueclicked', $new_test, $old_test);
                var_dump('changed test');
                update_option( 'woocommerce_resurs-bank_settings_test', $new_test );
                $this->settings['test'] = $new_test;
            }*/

            ?>
            <h3><?php echo $this->method_title; ?></h3>
            <p>På denna sida kan du ställa in loginuppgifter till Resurs Bank API</p>

            <table class="form-table">

                <?php $this->generate_settings_html(); ?>

            </table>

            <?php
            //echo '<input type="submit" name="registerCallbacksButton" value="Register Callbacks" />';
            ?>

            <?php
        }

        /**
         * Get available payment methods. Either from Resurs Bank API or transient cache
         * @param  boolean $force_file_refresh If new files should be forced or not
         * @return array                       Array containing an error message, if any errors occurred, and the payment methods, if any available and no errors occurred.
         */
        public function get_payment_methods( $force_file_refresh = false )
        {
            $returnArr = array();
            if ( false === ( $paymentMethods = get_transient( 'resurs_bank_payment_methods' ) ) || $force_file_refresh ) {

                $temp_class_files = get_transient( 'resurs_bank_class_files' );
                if ( is_array( $temp_class_files ) ) {
                    foreach ($temp_class_files as $class_name) {
                        $path = plugin_dir_path( __FILE__ ) . '/includes/' . $class_name;
                        $path = str_replace('//', '/', $path);

                        if ( file_exists( $path ) ) {
                            unlink( $path );
                        }
                    }

                    delete_transient( 'resurs_bank_class_files' );
                }

                try {
                    $this->init_webservice( $this->login, $this->password );

                    if ( is_object( $this->shopFlowService ) ) {
                        try {
                            $paymentMethods = $this->shopFlowService->getPaymentMethods()->return;
                            set_transient( 'resurs_bank_payment_methods', $paymentMethods, 24 * HOUR_IN_SECONDS );

                            $returnArr[ 'error' ]   = '';
                            $returnArr[ 'methods' ] = $paymentMethods;
                            $returnArr[ 'generate_new_files' ] = true;
                        } catch ( Exception $e ) {
                            $returnArr[ 'error' ]   = $e->getMessage();
                            $returnArr[ 'methods' ] = '';
                            $returnArr[ 'generate_new_files' ] = false;
                        }
                    }
                } catch ( Exception $e ) {
                    throw $e;
                }
            } else {
                $returnArr[ 'error' ]   = '';
                $returnArr[ 'methods' ] = $paymentMethods;
                $returnArr[ 'generate_new_files' ] = false;
            }

            return $returnArr;
        }

        /**
         * Get address for a specific government ID
         *
         * @return  JSON Prints the address data as JSON
         */
        public static function get_address_ajax()
        {
            if ( isset($_REQUEST) && 'SE' == get_option( 'woocommerce_resurs-bank_settings' )['country'] ) {
                $username = get_option( 'woocommerce_resurs-bank_settings' )['login'];
                $password = get_option( 'woocommerce_resurs-bank_settings' )['password'];

                $liveurl = get_option( 'woocommerce_resurs-bank_settings' )['baseLiveURL'];
                $testurl = get_option( 'woocommerce_resurs-bank_settings' )['baseTestURL'];

                $serverEnv = get_option( 'woocommerce_resurs-bank_settings' )['serverEnv'];

                $url = ( $serverEnv == 'test' ? $testurl : $liveurl );

                try {

                    $shopFlowService = new SoapClient( $url . 'ShopFlowService?wsdl', array(
                        'login'              => $username,
                        'password'           => $password,
                        'exceptions'         => true,
                        'connection_timeout' => 60,
                        'trace'              => true,
                    ) );

                    $params = array(
                        'governmentId'     => $_REQUEST['ssn'],
                        'customerType'     => (isset($_REQUEST['customerType']) ? ($_REQUEST['customerType'] == 'NATURAL' || $_REQUEST['customerType'] == 'LEGAL' ? $_REQUEST['customerType'] : 'NATURAL') : 'NATURAL'),
                        'customerIpAddress' => self::get_ip_address(),
                    );

                    $results = $shopFlowService->getAddress( $params );
                    print( json_encode( $results ) );
                } catch ( Exception $e ) {
                    print ( json_encode( $e->detail->ECommerceError ) );
                }
            }

            die();
        }
        public static function get_address_customertype()
        {
            $paymentMethods = get_transient( 'resurs_bank_payment_methods' );
            $requestedCustomerType = $_REQUEST['customerType'];
            $responseArray = array(
                'natural' => array(),
                'legal' => array()
            );
            if (is_array($paymentMethods)) {
                foreach ($paymentMethods as $objId) {
                    if (isset($objId->id) && isset($objId->customerType)) {
                        $nr = "resurs_bank_nr_" . $objId->id;
                        //if (strtolower($_REQUEST['paymentMethod']) == strtolower($nr)) { $customerType = $objId->customerType; }
                        $responseArray[strtolower($objId->customerType)][] = $nr;
                    }
                }
            }
            header('Content-Type: application/json');
            print(json_encode($responseArray));
            die();
        }

        /**
         * Function for starting a payment session via AJAX
         *
         * @deprecated This method was intended for another aproach, and is no longer used
         * @return JSON Prints the payment session data as JSON
         * @throws Exception
         */
        public static function start_payment_session_ajax()
        {
            global $woocommerce;
            if ( isset($_REQUEST) ) {

                $username = get_option( 'woocommerce_resurs-bank_settings' )['login'];
                $password = get_option( 'woocommerce_resurs-bank_settings' )['password'];

                $liveurl = get_option( 'woocommerce_resurs-bank_settings' )['baseLiveURL'];
                $testurl = get_option( 'woocommerce_resurs-bank_settings' )['baseTestURL'];

                $serverEnv = get_option( 'woocommerce_resurs-bank_settings' )['serverEnv'];

                $url = ( $serverEnv == 'test' ? $testurl : $liveurl );

                try {
                    $cart = $woocommerce->cart;
                    $preferred_id = (microtime(true)*10000);
                    $method_id = $_REQUEST['methodId'];

                    $shopFlowService = new SoapClient( $url . 'ShopFlowService?wsdl', array(
                        'login'              => $username,
                        'password'           => $password,
                        'exceptions'         => true,
                        'connection_timeout' => 60,
                        'trace'              => true,
                    ) );

                    $params = array(
                        'preferredId' => $preferred_id,
                        'paymentMethodId' => $method_id,
                        'customerIpAddress' => self::get_ip_address(),
                        'paymentSpec' => self::get_payment_spec( $cart ),
                    );
                    $results = $shopFlowService->startPaymentSession( $params );
                    print( json_encode( $results->return ) );
                } catch ( Exception $e ) {
                    throw $e;
                }
            }

            die();
        }

        /**
         * Get the plugin url
         *
         * @return string
         */
        public function plugin_url() {
            return untrailingslashit( plugins_url( '/', __FILE__ ) );
        }

        /**
         * Get a payment from Resurs Bank API
         *
         * @param  string $payment_id The paymentId for the payment to be fetched
         * @return stdClass|string    Returns the result from Resurs Bank API on success, Exception string on failure
         */
        public static function get_payment( $payment_id )
        {
            $username = get_option( 'woocommerce_resurs-bank_settings' )['login'];
            $password = get_option( 'woocommerce_resurs-bank_settings' )['password'];

            $liveurl = get_option( 'woocommerce_resurs-bank_settings' )['baseLiveURL'];
            $testurl = get_option( 'woocommerce_resurs-bank_settings' )['baseTestURL'];

            $serverEnv = get_option( 'woocommerce_resurs-bank_settings' )['serverEnv'];

            $url = ( $serverEnv == 'test' ? $testurl : $liveurl );

            try {
                $afterShopFlowService = new SoapClient( $url . 'AfterShopFlowService?wsdl', array(
                    'login'              => $username,
                    'password'           => $password,
                    'exceptions'         => true,
                    'connection_timeout' => 60,
                    'trace'              => true,
                ) );

                $params = array(
                    'paymentId' => $payment_id,
                );

                $result = $afterShopFlowService->getPayment($params);
            } catch (Exception $e) {
                $result = $e->detail->ECommerceError;
            }

            return $result;
        }

        public static function get_finalize_payment_spec( $order )
        {
            global $woocommerce, $theorder, $wpdb;

            $spec_lines = self::get_finalize_spec_lines( $order );

            //var_dump($order->order_shipping, $order->get_shipping_tax(), $order->get_shipping_methods());

            $shipping = (float)$order->order_shipping;
            $shipping_tax = (float)$order->get_shipping_tax();
            $shipping_total = (float)( $shipping + $shipping_tax );
            $shipping_tax_pct = @round( $shipping_tax / $shipping, 2 ) * 100;

            if ( false === empty($shipping) ) {

            }

            $spec_lines[] = array(
                'id' => 'frakt',
                'artNo' => '00_frakt',
                'description' => 'Frakt', //array_values($order->get_shipping_methods())[0]['name'],
                'quantity' => '1',
                'unitMeasure' => 'st',
                'unitAmountWithoutVat' => $shipping,
                'vatPct' => $shipping_tax_pct,
                'totalVatAmount' => $shipping_tax,
                'totalAmount' => $shipping_total,
            );

            /*$payment_method = $woocommerce->session->chosen_payment_method;
            $payment_options = get_option( 'woocommerce_' . $payment_method . '_settings' );
            $payment_fee = get_option( 'woocommerce_' . $payment_method . '_settings' )['price'];
            $payment_fee = (float)( isset( $payment_fee ) ? $payment_fee : '0' );
            $payment_fee_total = (float)$payment_fee * ( ( $payment_fee_tax_pct / 100 ) + 1 );

            $payment_fee_tax_class = get_option( 'woocommerce_resurs-bank_settings' )['priceTaxClass'];

            $payment_fee_tax_class_rates = $cart->tax->get_rates( $payment_fee_tax_class );

            $payment_fee_tax = $cart->tax->calc_tax($payment_fee, $payment_fee_tax_class_rates, false, true);

            $payment_fee_total_tax = 0;

            foreach ($payment_fee_tax as $value) {
                $payment_fee_total_tax = $payment_fee_total_tax + $value;
            }

            $tax_rates_pct_total = 0;

            foreach ($payment_fee_tax_class_rates as $key => $rate) {
                $tax_rates_pct_total = $tax_rates_pct_total + (float)$rate['rate'];
            }*/

            $payment_fee = array_values($order->get_items('fee'))[0];

            if (floatval($payment_fee['line_subtotal']) > 0) {
                $spec_lines[] = array(
                    'id' => $payment_fee['name'],
                    'artNo' => '00_' . str_replace(' ', '_', $payment_fee['title']) . "_fee",
                    'description' => ' ',//$payment_options['priceDescription'],
                    'quantity' => '1',
                    'unitMeasure' => 'st',
                    'unitAmountWithoutVat' => $payment_fee['line_subtotal'],
                    'vatPct' => ($payment_fee['line_subtotal_tax'] / $payment_fee['line_subtotal']) * 100,
                    'totalVatAmount' => (float)$payment_fee['line_subtotal_tax'],
                    'totalAmount' => (float)$payment_fee['line_subtotal'] + $payment_fee['line_subtotal_tax'],
                );
            }

            $coupons = $order->get_items(array('coupon'));

            if ( count( $coupons ) > 0 ) {
                foreach ($coupons as $coupon) {
                    $temp_coupon = new WC_Coupon( $coupon['name'] );
                    $post = get_post( $temp_coupon->id );
                    //var_dump($temp_coupon, $post);
                    $spec_lines[] = array(
                        'id' => $post->ID,
                        'artNo' => $temp_coupon->code . '_kupong',
                        'description' => $post->post_excerpt,
                        'quantity' => 1,
                        'unitMeasure' => 'st',
                        'unitAmountWithoutVat' => (0 - (float)$coupon['discount_amount']),
                        'vatPct' => 0,
                        'totalVatAmount' => 0,
                        'totalAmount' => (0 - (float)$coupon['discount_amount']),
                    );
                }
            }
            //$cart->calculate_totals();
            $payment_spec = array(
                'specLines' => $spec_lines,
                'totalAmount' => $order->get_total(),
                'totalVatAmount' => $order->get_total_tax(),
            );

            //var_dump($payment_spec, $cart->total, $woocommerce->cart->fees);
            //var_dump($payment_spec);

            return $payment_spec;
        }

        public static function get_finalize_spec_lines( $order )
        {
            $spec_lines = array();
            $items = $order->get_items();
            foreach ( $items as $item ) {
                $data = get_post($item['product_id']);
                //var_dump($data, $item);
                $vatPct = (double)( $item['line_subtotal_tax'] / $item['line_subtotal'] ) * 100;

                $spec_lines[] = array(
                    'id' => $data->ID,
                    'artNo' => $data->ID,
                    'description' => ( empty($data->post_title) ? 'Beskrivning' : $data->post_title ),
                    'quantity' => $item['qty'],
                    'unitMeasure' => 'st',
                    'unitAmountWithoutVat' => (double)$item['line_subtotal'] / (int)$item['qty'],
                    'vatPct' => ( $item['line_subtotal_tax'] / $item['line_subtotal'] ) * 100,
                    'totalVatAmount' => $item['line_subtotal_tax'],
                    'totalAmount' => $item['line_subtotal_tax'] + $item['line_subtotal'],
                );
            }

            return $spec_lines;
        }

        /**
         * Finalize an order by calling the finalizePayment method from Resurs Bank API
         *
         * @param  WC_Order $order     The order
         * @param  float    $order_total The order total amount, including fess
         * @return stdClass|Exception  Returns the result from Resurs Bank API on success, Exception object on failure
         */
        public static function finalize_order_payment( $order, $order_total, $payment_method_type )
        {
            global $woocommerce, $current_user;
            get_currentuserinfo();

            $username = get_option( 'woocommerce_resurs-bank_settings' )['login'];
            $password = get_option( 'woocommerce_resurs-bank_settings' )['password'];

            $liveurl = get_option( 'woocommerce_resurs-bank_settings' )['baseLiveURL'];
            $testurl = get_option( 'woocommerce_resurs-bank_settings' )['baseTestURL'];

            $serverEnv = get_option( 'woocommerce_resurs-bank_settings' )['serverEnv'];

            $url = ( $serverEnv == 'test' ? $testurl : $liveurl );

            $temp_coupon = new WC_Coupon($order->get_used_coupons()[0]);
            $coupons = $order->get_items(array('coupon'));
            $order_items = $order->get_items();

            //var_dump($order, $order_items, $order->get_tax_totals(), $order->get_total_tax(), $order->get_taxes());

            /*var_dump($order_items);
            var_dump(get_post($order_items[1512]['product_id']));
            var_dump($temp_coupon, $temp_coupon->post_excerpt, $order->get_items('fee'));

            var_dump($coupons, $order->order_shipping);*/
            //var_dump($order, $order->get_cart_discount(), $order->get_order_discount(), $order->get_total_discount(), $order->get_cart_discount_to_display, $order->get_fees(), $order->get_used_coupons(), $temp_coupon);

            //die();

            try {

                //$cart = $woocommerce->cart;
                $preferred_transaction_id = uniqid(rand(), true);
                $preferred_transaction_id = preg_replace('/\D/i', '', $preferred_transaction_id);
                $preferred_transaction_id = substr($preferred_transaction_id, 0, 25);

                $afterShopFlowService = new SoapClient( $url . 'AfterShopFlowService?wsdl', array(
                    'login'              => $username,
                    'password'           => $password,
                    'exceptions'         => true,
                    'connection_timeout' => 60,
                    'trace'              => true,
                ) );

                $payment_id = get_post_meta( $order->id, 'paymentId', true );

                //var_dump($order, $order->get_taxes(), $order->get_tax_totals(), $order->get_total_tax(), $order->get_total());
                //var_dump($order, $order->get_fees());

                if ( 'INVOICE' === $payment_method_type ) {
                    $params = array(
                        'paymentId' => $payment_id,
                        'preferredTransactionId' => $preferred_transaction_id,
                        'partPaymentSpec' => self::get_finalize_payment_spec($order),
                        'createdBy' => $current_user->display_name,
                        'orderId' => $order->id
                    );
                } else {
                    $params = array(
                        'paymentId' => $payment_id,
                        'preferredTransactionId' => $preferred_transaction_id,
                        'partPaymentSpec' => array(
                            'totalAmount' => $order_total,
                        ),
                        'createdBy' => $current_user->display_name,
                        'orderId' => $order->id
                    );
                }

                /*var_dump($params);
                die();*/
                $finalize_result = $afterShopFlowService->finalizePayment( $params );
                update_post_meta( $order->id, 'finalizeTransactionId', $preferred_transaction_id );
                return $finalize_result;
            } catch ( Exception $e ) {
                /*var_dump($e, get_class($e), $afterShopFlowService->__getLastRequest());
                die();*/

                //var_dump($e);
                //var_dump($afterShopFlowService->__getLastRequest());
                //$order->add_order_note( 'Fel inträffade vid finalizePayment' );
                return $e;
            }
        }

        /**
         * Credit an order by calling the creditPayment method from Resurs Bank API
         *
         * @param  WC_Order $order       The order
         * @param  stdClass $payment     The payment
         * @param  float    $order_total The order total amount, including fess
         * @return stdClass|Exception    Returns the result from Resurs Bank API on success, Exception object on failure
         */
        public static function credit_order_payment( $order, $payment, $order_total )
        {
            global $woocommerce, $current_user;
            get_currentuserinfo();

            $resursFlow = initializeResursFlow();
            if (null !== $resursFlow) {
                $payment_id = get_post_meta($order->id, 'paymentId', true);
                try {
                    $resursFlow->cancelPayment($payment_id);
                } catch (Exception $e) {
                    return $e->getMessage();
                }
            } else {

                $username = get_option('woocommerce_resurs-bank_settings')['login'];
                $password = get_option('woocommerce_resurs-bank_settings')['password'];

                $liveurl = get_option('woocommerce_resurs-bank_settings')['baseLiveURL'];
                $testurl = get_option('woocommerce_resurs-bank_settings')['baseTestURL'];

                $serverEnv = get_option('woocommerce_resurs-bank_settings')['serverEnv'];

                $url = ($serverEnv == 'test' ? $testurl : $liveurl);

                try {
                    $preferred_transaction_id = uniqid(rand(), true);
                    $preferred_transaction_id = preg_replace('/\D/i', '', $preferred_transaction_id);
                    $preferred_transaction_id = substr($preferred_transaction_id, 0, 25);

                    $afterShopFlowService = new SoapClient($url . 'AfterShopFlowService?wsdl', array(
                        'login' => $username,
                        'password' => $password,
                        'exceptions' => true,
                        'connection_timeout' => 60,
                        'trace' => true,
                    ));

                    $payment_id = get_post_meta($order->id, 'paymentId', true);

                    $params = array(
                        'paymentId' => $payment_id,
                        'preferredTransactionId' => $preferred_transaction_id,
                        'partPaymentSpec' => array(
                            'totalAmount' => $order_total,
                        ),
                        'createdBy' => $current_user->display_name,
                    );

                    if ('INVOICE' === $payment->paymentMethodType) {
                        $preferred_credit_note_id = uniqid(rand(), true);
                        $preferred_credit_note_id = preg_replace('/\D/i', '', $preferred_credit_note_id);
                        $preferred_credit_note_id = substr($preferred_credit_note_id, 0, 25);

                        $params['creditNoteId'] = $preferred_credit_note_id;
                    }

                    $credit_result = $afterShopFlowService->creditPayment($params);
                    update_post_meta($order->id, 'creditTransactionId', $preferred_transaction_id);

                    return $credit_result;
                } catch (Exception $e) {
                    //$order->add_order_note( 'Fel inträffade vid creditPayment: ' . $e->detail->ECommerceError->faultstring);
                    //$order->add_order_note( 'Fel inträffade vid creditPayment: ' . $e->faultstring);
                    return $e;
                }
            }
        }

        /**
         * Annul an order by calling the annulPayment method from Resurs Bank API
         * @param  WC_Order $order     The order
         * @param  float    $order_total The order total amount, including fess
         * @return stdClass|Exception  Returns the result from Resurs Bank API on success, Exception object on failure
         */
        public static function annul_payment( $order, $order_total )
        {
            global $woocommerce, $current_user;
            get_currentuserinfo();

            if (hasExtendedAfterShop()) {
                $resursFlow = initializeResursFlow();
                if (null !== $resursFlow) {
                    $payment_id = get_post_meta($order->id, 'paymentId', true);
                    try {
                        $resursFlow->cancelPayment($payment_id);
                    } catch (Exception $e) {
                        return $e->getMessage();
                    }
                }
            } else {
                /* NonExtended AfterShop means "act like before" */

                $username = get_option( 'woocommerce_resurs-bank_settings' )['login'];
                $password = get_option( 'woocommerce_resurs-bank_settings' )['password'];

                $liveurl = get_option( 'woocommerce_resurs-bank_settings' )['baseLiveURL'];
                $testurl = get_option( 'woocommerce_resurs-bank_settings' )['baseTestURL'];

                $serverEnv = get_option( 'woocommerce_resurs-bank_settings' )['serverEnv'];

                $url = ( $serverEnv == 'test' ? $testurl : $liveurl );


                try {

                    $afterShopFlowService = new SoapClient( $url . 'AfterShopFlowService?wsdl', array(
                        'login'              => $username,
                        'password'           => $password,
                        'exceptions'         => true,
                        'connection_timeout' => 60,
                        'trace'              => true,
                    ) );

                    $payment_id = get_post_meta( $order->id, 'paymentId', true );

                    $params = array(
                        'paymentId' => $payment_id,
                        'partPaymentSpec' => array(
                            'totalAmount' => $order_total,
                        ),
                        'createdBy' => $current_user->display_name,
                    );

                    $annul_result = $afterShopFlowService->annulPayment( $params );
                    //update_post_meta( $order->id, 'creditTransactionId', $preferred_transaction_id );

                    return $annul_result;
                } catch ( Exception $e ) {
                    //$order->add_order_note( 'Fel inträffade vid annulPayment: ' . $e->detail->ECommerceError->faultstring);
                    //$order->add_order_note( 'Fel inträffade vid annulPayment: ' . $e->faultstring);
                    return $e;
                }
            }
        }

        /**
         * Called when the status of an order is changed
         *
         * @param  int    $order_id        The order id
         * @param  string $old_status_slug The old status
         * @param  string $new_status_slug The new stauts
         * @return null                    Returns null on success, redirects and exits on failure
         */
        public static function order_status_changed( $order_id, $old_status_slug, $new_status_slug ) {
            global $woocommerce;
            $order = new WC_Order( $order_id );
            $payment_method = $order->payment_method;

            if ( false === (boolean)preg_match('/resurs_bank/', $payment_method) ) {
                return;
            }

            if ( isset( $_REQUEST['wc-api'] ) || isset( $_REQUEST['cancel_order'] ) ) {
                return;
            }

            $url = admin_url('post.php');
            $url = add_query_arg( 'post', $order_id, $url );
            $url = add_query_arg( 'action', 'edit', $url );

            $old_status = get_term_by( 'slug', sanitize_title( $old_status_slug ), 'shop_order_status' );
            $new_status = get_term_by( 'slug', sanitize_title( $new_status_slug ), 'shop_order_status' );

            $order_total = $order->get_total();
            $order_fees = $order->get_fees();

            $payment_id = get_post_meta( $order->id, 'paymentId', true );
            $resursFlow = initializeResursFlow();
            $flowErrorMessage = null;
            $payment = self::get_payment( $payment_id )->return;

            /*var_dump($payment);
            die();*/

            if ( false === is_array( $payment->status ) ) {
                $status = array( $payment->status );
            } else {
                $status = $payment->status;
            }

            switch ($old_status_slug) {
                case 'pending':
                    break;
                case 'failed':
                    break;
                case 'processing':
                    break;
                case 'completed':
                    /*if ( in_array( 'IS_DEBITED', $status ) || false === in_array( 'DEBITABLE', $status ) ) {
                        $_SESSION['resurs_bank_admin_notice'] = array(
                            'type' => 'error',
                            'message' => 'Denna order är debiterad och går därmed ej att ändra status på',
                        );

                        wp_set_object_terms( $order_id, array( $old_status->slug ), 'shop_order_status', false );
                        wp_safe_redirect( $url );
                        exit;
                    }*/
                    break;
                case 'on-hold':
                    break;
                case 'cancelled':
                    if ( in_array( 'IS_ANNULLED', $status) ) {
                        $_SESSION['resurs_bank_admin_notice'] = array(
                            'type' => 'error',
                            'message' => 'Denna order är annulerad och går därmed ej att ändra status på',
                        );

                        wp_set_object_terms( $order_id, array( $old_status->slug ), 'shop_order_status', false );
                        wp_safe_redirect( $url );
                        exit;
                    }
                    break;
                case 'refunded':
                    if ( in_array( 'IS_CREDITED', $status) ) {
                        $_SESSION['resurs_bank_admin_notice'] = array(
                            'type' => 'error',
                            'message' => 'Denna order är krediterad och går därmed ej att ändra status på',
                        );

                        wp_set_object_terms( $order_id, array( $old_status->slug ), 'shop_order_status', false );
                        wp_safe_redirect( $url );
                        exit;
                    }
                    break;
                default:
                    break;
            }


            switch ( $new_status_slug ) {
                case 'pending':
                    break;
                case 'failed':
                    break;
                case 'processing':
                    break;
                case 'completed':
                    if ( in_array( 'DEBITABLE', $status ) ) {

                        if (hasExtendedAfterShop()) {
                            try {
                                $resursFlow->finalizePayment($payment_id);
                            }
                            catch (Exception $e) {
                                $flowErrorMessage = $e->getMessage();
                            }
                            if (null !== $flowErrorMessage) {
                                $_SESSION['resurs_bank_admin_notice'] = array(
                                    'type' => 'error',
                                    'message' => $flowErrorMessage
                                );
                                wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                                wp_safe_redirect( $url );
                            }
                        } else {
                            $finalize_result = self::finalize_order_payment($order, $order_total, $payment->paymentMethodType);
                            if ('SoapFault' === get_class($finalize_result)) {
                                preg_match_all('/[0-9\.]+/', $finalize_result->faultstring, $message);
                                if (count($message[0]) === 2) {
                                    $_SESSION['resurs_bank_admin_notice'] = array(
                                        'type' => 'error',
                                        'message' => 'Summan för debitering, ' . $message[0][0] . ', är större än den kvarvarande summan på betalningen, ' . $message[0][1],
                                    );

                                    wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                                    wp_safe_redirect($url);
                                } else {
                                    $_SESSION['resurs_bank_admin_notice'] = array(
                                        'type' => 'error',
                                        'message' => $finalize_result->detail->ECommerceError->userErrorMessage,
                                    );

                                    wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                                    wp_safe_redirect($url);
                                }
                                exit;
                            }
                        }
                    } else {
                        $_SESSION['resurs_bank_admin_notice'] = array(
                            'type' => 'error',
                            'message' => 'Denna order går ej att debitera.'
                        );

                        wp_set_object_terms( $order_id, array( $old_status->slug ), 'shop_order_status', false );
                        wp_safe_redirect( $url );
                        exit;
                    }
                    break;
                case 'on-hold':
                    break;
                case 'cancelled':

                    if (hasExtendedAfterShop()) {
                        try {
                            $resursFlow->cancelPayment($payment_id);
                        } catch (Exception $e) {
                            $flowErrorMessage = $e->getMessage();
                        }
                        if (null !== $flowErrorMessage) {
                            $_SESSION['resurs_bank_admin_notice'] = array(
                                'type' => 'error',
                                'message' => $flowErrorMessage
                            );
                            wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                            wp_safe_redirect( $url );
                        }
                    } else {
                        if (in_array('CREDITABLE', $status)) {
                            $_SESSION['resurs_bank_admin_notice'] = array(
                                'type' => 'error',
                                'message' => 'Denna order går ej att annulera, endast kreditera.'
                            );

                            wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                            wp_safe_redirect($url);
                            exit;
                        } else if (in_array('DEBITABLE', $status)) {
                            $annul_result = self::annul_payment($order, $order_total);
                            if ('SoapFault' === $annul_result) {
                                preg_match_all('/[0-9\.]+/', $annul_result->faultstring, $message);
                                if (count($message[0]) === 2) {
                                    $_SESSION['resurs_bank_admin_notice'] = array(
                                        'type' => 'error',
                                        'message' => 'Summan för annullering, ' . $message[0][0] . ', är större än den kvarvarande summan på betalningen, ' . $message[0][1],
                                    );

                                    wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                                    wp_safe_redirect($url);
                                } else {
                                    $_SESSION['resurs_bank_admin_notice'] = array(
                                        'type' => 'error',
                                        'message' => $annul_result->detail->ECommerceError->userErrorMessage,
                                    );

                                    wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                                    wp_safe_redirect($url);
                                }

                                exit;
                            }
                        } else {
                            $_SESSION['resurs_bank_admin_notice'] = array(
                                'type' => 'error',
                                'message' => 'Denna order går ej att annulera.'
                            );
                            wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                            wp_safe_redirect($url);
                            exit;
                        }
                    }
                    break;
                case 'refunded':

                    if (hasExtendedAfterShop()) {
                        try {
                            $resursFlow->cancelPayment($payment_id);
                        } catch (Exception $e) {
                            $flowErrorMessage = $e->getMessage();
                        }
                        if (null !== $flowErrorMessage) {
                            $_SESSION['resurs_bank_admin_notice'] = array(
                                'type' => 'error',
                                'message' => $flowErrorMessage
                            );
                            wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                            wp_safe_redirect( $url );
                        }
                    } else {
                        if (in_array('CREDITABLE', $status)) {
                            $credit_result = self::credit_order_payment($order, $payment, $order_total);
                            if ('SoapFault' === get_class($credit_result)) {
                                preg_match_all('/[0-9\.]+/', $credit_result->faultstring, $message);
                                if (count($message[0]) === 2) {
                                    $_SESSION['resurs_bank_admin_notice'] = array(
                                        'type' => 'error',
                                        'message' => 'Summan för kreditering, ' . $message[0][0] . ', är större än den kvarvarande summan på betalningen, ' . $message[0][1],
                                    );

                                    wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                                    wp_safe_redirect($url);
                                } else {
                                    $_SESSION['resurs_bank_admin_notice'] = array(
                                        'type' => 'error',
                                        'message' => $credit_result->detail->ECommerceError->userErrorMessage,
                                    );

                                    wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                                    wp_safe_redirect($url);
                                }
                                exit;
                            }
                        } else {
                            $_SESSION['resurs_bank_admin_notice'] = array(
                                'type' => 'error',
                                'message' => 'Denna order går ej att kreditera.'
                            );

                            wp_set_object_terms($order_id, array($old_status->slug), 'shop_order_status', false);
                            wp_safe_redirect($url);
                            exit;
                        }
                    }
                    break;
                default:
                    break;
            }
            return;
        }
    }

    /**
     * Add the Gateway to WooCommerce
     *
     * @param  array $methods The available payment methods
     * @return array          The available payment methods
     */
    function woocommerce_add_resurs_bank_gateway( $methods ) {
        $methods[] = 'WC_Resurs_Bank';
        return $methods;
    }

    /**
     * Remove the gateway from the available payment options at checkout
     *
     * @param  array $gateways The array of payment gateways
     * @return array           The array of payment gateways
     */
    function woocommerce_remove_resurs_bank_from_available_payment_gateways($gateways)
    {
        unset($gateways['resurs-bank']);
        return $gateways;
    }

    /**
     * Adds the SSN field to the checkout form for fetching a address
     *
     * @param  WC_Checkout $checkout The WooCommerce checkout object
     * @return WC_Checkout           The WooCommerce checkout object
     */
    function add_ssn_checkout_field( $checkout )
    {
        if ( 'no' == get_option( 'woocommerce_resurs-bank_settings' )['enabled'] ) {
            return $checkout;
        }

        echo '<input type="radio" id="ssnCustomerType" onclick="getMethodType(\'natural\')" checked="checked" name="ssnCustomerType" value="NATURAL"> ' . __('Privat') . " ";
        echo '<input type="radio" id="ssnCustomerType" onclick="getMethodType(\'legal\')" name="ssnCustomerType" value="LEGAL"> ' . __('Företag');
        echo '<input type="hidden" id="resursSelectedCountry" value="' . get_option( 'woocommerce_resurs-bank_settings' )['country'] . '">';

        if ( 'SE' == get_option( 'woocommerce_resurs-bank_settings' )['country'] ) {
            woocommerce_form_field( 'ssn_field', array(
                'type'          => 'text',
                'class'         => array('ssn form-row-wide'),
                'label'         => __('Personnummer'),
                'placeholder'       => __('Ange personnummer'),
            ), $checkout->get_value( 'ssn_field' ));

            echo '<a href="#" class="button" id="fetch_address">Hämta adress</a><br>';
        }
        return $checkout;
    }

    /**
     * Adds Resurs Bank javascript file
     *
     * @return null Returns null if Resurs Bank plugin is not enabled
     */
    function enqueue_script()
    {
        if ( 'no' == get_option( 'woocommerce_resurs-bank_settings' )['enabled'] ) {
            return;
        }

        wp_enqueue_script( 'resursjslanguage', plugin_dir_url( __FILE__ ) . '/js/resursjslanguage.js' );
        wp_enqueue_script( 'resursBankScript', plugin_dir_url( __FILE__ ) . '/js/resursBankScript.js' );
        wp_localize_script( 'resursBankScript', 'ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
        wp_enqueue_style('resurs_internal', plugin_dir_url(__FILE__) . 'css/resurs_internal.css');
    }

    /**
     * Adds Javascaript too the Resurs Bank Payment Gateway settings panel
     *
     * @param string $hook The current page
     * @return null        Returns null current page is not correct
     */
    function admin_enqueue_script( $hook )
    {
        if ( 'woocommerce_page_wc-settings' !== $hook ) {
            return;
        }

        if (version_compare(PHP_VERSION, '5.4.0', '<')) {
            $_SESSION['resurs_bank_admin_notice']['message'] = __('The Resurs Bank Addon for WooCommerce may not work properly in PHP 5.3 or older. You should consider upgrade to 5.4 or higher.');
            $_SESSION['resurs_bank_admin_notice']['type'] = 'resurswoo_phpversion_deprecated';
        }

        if ( 'wc_resurs_bank' !== $_REQUEST['section'] ) {
            return;
        }

        /*wp_enqueue_script( 'resursBankAdminScript', plugin_dir_url( __FILE__ ) . '/js/resursBankAdminScript.js' );
        wp_localize_script( 'resursBankAdminScript', 'ajax_object', array( 'resurs_bank_settings' => get_option( 'woocommerce_resurs-bank_settings' ) ) );*/
    }

    /**
     * Start session on Wordpress init
     */
    function start_session()
    {
        if(!session_id()) {
            session_start();
        }
    }

    /**
     * End session on Wordpress login and logout
     */
    function end_session()
    {
        session_destroy ();
    }

    /**
     * Used to enable wp_safe_redirect in ceratin situations
     */
    function app_output_buffer()
    {
        if ( isset( $_REQUEST['woocommerce_resurs-bank_refreshPaymentMethods'] ) || isset( $_REQUEST['second_update_status'] ) || isset( $_REQUEST['save'] ) || isset( $_SESSION ) ) {
            ob_start();
        }
    }

    /**
     * Used to output a notice to the admin interface
     */
    function resurs_bank_admin_notice()
    {
        if ( isset( $_SESSION['resurs_bank_admin_notice'] ) ) {
            $notice = '<div class=' . $_SESSION['resurs_bank_admin_notice']['type'] . '>';
            $notice .= '<p>' . $_SESSION['resurs_bank_admin_notice']['message'] . '</p>';
            $notice .= '</div>';
            echo $notice;
            unset( $_SESSION['resurs_bank_admin_notice'] );
        }
    }

    function test_before_shipping()
    {
        //var_dump($_REQUEST);
    }

    foreach ( glob( plugin_dir_path( __FILE__ ) . '/includes/*.php') as $filename )
    {
        if ( !in_array( $filename, get_included_files() ) ) {
            include $filename;
        }
    }
    add_filter( 'woocommerce_payment_gateways', 'woocommerce_add_resurs_bank_gateway' );
    add_filter( 'woocommerce_available_payment_gateways', 'woocommerce_remove_resurs_bank_from_available_payment_gateways', 1 );
    add_filter( 'woocommerce_before_checkout_billing_form' , 'add_ssn_checkout_field' );
    add_action( 'woocommerce_order_status_changed', 'WC_Resurs_Bank::order_status_changed', 10, 3 );

    add_action( 'wp_enqueue_scripts', 'enqueue_script' );
    add_action( 'admin_enqueue_scripts', 'admin_enqueue_script' );

    add_action( 'wp_ajax_get_address_ajax', 'WC_Resurs_Bank::get_address_ajax' );
    add_action( 'wp_ajax_nopriv_get_address_ajax', 'WC_Resurs_Bank::get_address_ajax' );

    add_action( 'wp_ajax_get_address_customertype', 'WC_Resurs_Bank::get_address_customertype' );
    add_action( 'wp_ajax_nopriv_get_address_customertype', 'WC_Resurs_Bank::get_address_customertype' );

    add_action( 'wp_ajax_start_payment_session_ajax', 'WC_Resurs_Bank::start_payment_session_ajax' );
    add_action( 'wp_ajax_nopriv_start_payment_session_ajax', 'WC_Resurs_Bank::start_payment_session_ajax' );

    add_action( 'init', 'start_session', 1 );
    add_action( 'wp_logout', 'end_session' );
    add_action( 'wp_login', 'end_session' );

    add_action( 'init', 'app_output_buffer', 2 );

    add_action( 'admin_notices', 'resurs_bank_admin_notice' );

    add_action( 'woocommerce_before_checkout_shipping_form', 'test_before_shipping' );
    add_action('woocommerce_before_delete_order_item', 'resurs_remove_order_item');
}

/**
 * Defined if Resurs AfterShopFlow should be extended (available since version 0.5)
 * @return bool
 */
function hasExtendedAfterShop() {
    return get_option( 'woocommerce_resurs-bank_settings' )['extendedAfterShopFlow'];
}

/**
 * Unconditional OrderRowRemover for Resurs Bank. This function will run before the primary remove_order_item() in the WooCommerce-plugin.
 * This function won't remove any product on the woocommerce-side, it will however update the payment at Resurs Bank.
 * If removal at Resurs fails by any reason, this method will stop the removal from WooAdmin, so we won't destroy any synch.
 *
 * @param $item_id
 * @return bool
 */
function resurs_remove_order_item($item_id)
{
    if (!$item_id) {return false;}
    // Make sure we still keep the former security
    if ( ! current_user_can( 'edit_shop_orders' ) ) {
        die(-1);
    }

    if (hasExtendedAfterShop()) {
        $resursFlow = null;
        if (class_exists('ResursBank')) {
            $resursFlow = initializeResursFlow();
        }
        $clientPaymentSpec = array();
        if (null !== $resursFlow) {
            $productId = wc_get_order_item_meta($item_id, '_product_id');
            $productQty = wc_get_order_item_meta($item_id, '_qty');
            $orderId = wc_get_order_id_by_order_item_id($item_id);

            $resursPaymentId = get_post_meta($orderId, 'paymentId', true);

            if (empty($productId)) {
                $testItemType = wc_get_order_item_type_by_item_id($item_id);
                $testItemName = wc_get_order_item_type_by_item_id($item_id);
                if ($testItemType === "shipping") {
                    $clientPaymentSpec[] = array(
                        'artNo' => "00_frakt",
                        'quantity' => 1
                    );
                } elseif ($testItemType === "coupon") {
                    $clientPaymentSpec[] = array(
                        'artNo' => $testItemName . "_kupong",
                        'quantity' => 1
                    );
                } elseif ($testItemType === "fee") {
                    if (function_exists('wc_get_order')) {
                        $current_order = wc_get_order($orderId);
                        $feeName = '00_' . str_replace(' ', '_', $current_order->payment_method_title) . "_fee";
                        $clientPaymentSpec[] = array(
                            'artNo' => $feeName,
                            'quantity' => 1
                        );
                    } else {
                        $order_failover_test = new WC_Order($orderId);
                        ///$payment_fee = array_values($order->get_items('fee'))[0];
                        $feeName = '00_' . str_replace(' ', '_', $order_failover_test->payment_method_title) . "_fee";
                        $clientPaymentSpec[] = array(
                            'artNo' => $feeName,
                            'quantity' => 1
                        );
                        //die("Can not fetch order information from WooCommerce (Function wc_get_order() not found)");
                    }
                }
            } else {
                $clientPaymentSpec[] = array(
                    'artNo' => $productId,
                    'quantity' => $productQty
                );
            }

            try {
                //$removeResursRow = $resursFlow->annulPayment($resursPaymentId, $clientPaymentSpec);
                $removeResursRow = $resursFlow->cancelPayment($resursPaymentId, $clientPaymentSpec, array(), false, true);
            } catch (Exception $e) {
                $resultArray = array(
                    'success' => false,
                    'fail' => utf8_encode($e->getMessage())
                );
                echo $e->getMessage();
                die();
            }
            if (!$removeResursRow) {
                echo "Cancelling payment failed without a proper reason";
                die();
            }
        }
    }
}

/**
 * Get the order id from where a specific item resides
 * @param $item_id
 * @return null|string
 */
function wc_get_order_id_by_order_item_id($item_id) {
    global $wpdb;
    $item_id = absint( $item_id );
    $order_id = $wpdb->get_var( $wpdb->prepare( "SELECT order_id FROM {$wpdb->prefix}woocommerce_order_items WHERE order_item_id = '%d'", $item_id) );
    return $order_id;
}

/**
 * Get the order item type (or name) by item id
 * @param $item_id
 * @return null|string
 */
function wc_get_order_item_type_by_item_id($item_id, $getItemName = false) {
    global $wpdb;
    $item_id = absint( $item_id );
    if (!$getItemName) {
        $order_item_type = $wpdb->get_var( $wpdb->prepare( "SELECT order_item_type FROM {$wpdb->prefix}woocommerce_order_items WHERE order_item_id = '%d'", $item_id) );
        return $order_item_type;
    } else {
        $order_item_name = $wpdb->get_var( $wpdb->prepare( "SELECT order_item_name FROM {$wpdb->prefix}woocommerce_order_items WHERE order_item_id = '%d'", $item_id) );
        return $order_item_name;
    }
}

function initializeResursFlow() {
    $username = get_option('woocommerce_resurs-bank_settings')['login'];
    $password = get_option('woocommerce_resurs-bank_settings')['password'];
    $serverEnv = get_option( 'woocommerce_resurs-bank_settings' )['serverEnv'];

    /* Default */
    $useEnvironment = ResursEnvironments::ENVIRONMENT_TEST;

    /* Specifically defined */
    if ($serverEnv == 'test') { $useEnvironment = ResursEnvironments::ENVIRONMENT_TEST; }
    if ($serverEnv == 'live') { $useEnvironment = ResursEnvironments::ENVIRONMENT_PRODUCTION; }

    $initFlow = new \ResursBank($username, $password);
    $initFlow->setEnvironment($useEnvironment);

    return $initFlow;
}
