<?php

/**
 * Resurs Bank Passthrough API - A pretty silent shopflow simplifier for Resurs Bank.
 *
 * @package EcomPHP
 * @author Resurs Bank Ecommrece <ecommerce.support@resurs.se>
 * @version 1.0-beta
 * @branch 1.0
 * @link https://test.resurs.com/docs/x/KYM0 Get started - PHP Section
 * @link https://test.resurs.com/docs/x/TYNM EComPHP Usage
 * @license -
 */

/**
 * Set up paths for autoloader.
 */
if (defined('RB_API_PATH') && !defined('RB_CWD')) {
    define('RB_CWD', RB_API_PATH);
}
require_once('rbapi_exceptions.php');
if (!defined('RB_CWD')) {
    /**
     * Tells from where we are working in the "Resurs space". Will use current dir if none is found. For user defined locations, use RB_API_PATH to set this one up properly. If nothing is set up RB_CWD will be current cwd
     */
    define('RB_CWD', (($getcwd = getcwd()) ? $getcwd : '.'));
}

/**
 * Class ResursBank: Primary client class.
 */
class ResursBank
{

    /**
     * Resurs Bank API Client Gateway. Works with dynamic data arrays. By default, the API-gateway will connect to Resurs Bank test environment, so to use production mode this must be configured at runtime.
     *
     * @subpackage EcomPHPClient
     */

    /**
     * Constant variable for using ecommerce production mode
     */
    const ENVIRONMENT_PRODUCTION = 0;
    /**
     * Constant variable for using ecommerce in test mode
     */
    const ENVIRONMENT_TEST = 1;

    /**
     * @var array Standard options for the SOAP-interface.
     */
    var $soapOptions = array(
        'exceptions' => 1,
        'connection_timeout' => 60,
        'login' => 'exshop',
        'password' => 'gO9UaWH38D',
        'trace' => 1
    );

    /** @var bool Set to true if you want to try to use internally cached data. This is disabled by default since it may, in a addition to performance, also be a security issue since the configuration file needs read- and write permissions */
    public $configurationInternal = false;
    /** @var string For internal handling of cache, etc */
    private $configurationSystem = "configuration";
    /** @var string Configuration file */
    private $configurationStorage = "";
    /** @var array Configuration, settings, payment methods etc */
    private $configurationArray = array();
    /** @var int Time in seconds when cache should be considered outdated and needs to get updated with new fresh data */
    public $configurationCacheTimeout = 3600;

    /** @var string This. */
    private $clientName = "RB-EcomBridge";
    /** @var string The version of this gateway */
    private $version = "1.0.0";
    /** @var string Default URL to test environment */
    private $env_test = "https://test.resurs.com/ecommerce-test/ws/V4/";
    /** @var string Default URL to production environment */
    private $env_prod = "https://ecommerce.resurs.com/ws/V4/";
    /** @var bool Internal "handshake" control */
    private $hasinit = false;
    /** @var bool Activation of debug mode */
    public $debug = false;

    /** @var string The current directory of RB Classes */
    private $classPath = "";

    /** @var array Files to look for in class directories, to find RB */
    private $classPathFiles = array('/simplifiedshopflowservice-client/Resurs_SimplifiedShopFlowService.php', '/configurationservice-client/Resurs_ConfigurationService.php', '/aftershopflowservice-client/Resurs_AfterShopFlowService.php', '/shopflowservice-client/Resurs_ShopFlowService.php');

    /** @var null The chosen environment */
    private $environment = null;
    /** @var int Default current environment. Always set to test (security reasons) */
    public $current_environment = self::ENVIRONMENT_TEST;

    /** Web Services section */
    /** @var null Object configurationService */
    public $configurationService = null;
    /** @var null Object developerWebService */
    public $developerWebService = null;
    /** @var null Object simplifiedShowFlowService (this is what is primary used by this gateway) */
    public $simplifiedShopFlowService = null;
    /** @var null Object afterShopFlowService */
    public $afterShopFlowService = null;
    /** @var null Object shopwFlowService (Deprecated "long flow") */
    public $shopFlowService = null;
    /** @var null What the service has returned (debug) */
    public $serviceReturn = null;
    /** @var null Last error received */
    public $lastError = null;

    /**
     * Configuration loader
     *
     * This API is set to primary use Resurs simplified shopflow. By default, this service is loaded automatically, together with the configurationservice which is used for setting up callbacks, etc. If you need other services, like aftershop, you should add it when your API is loading like this for example:<br>
     * $API->Include[] = 'AfterShopFlowService';
     *
     * @var array Simple array with a list of which interfaces that should be automatically loaded on init. Default: ConfigurationService, SimplifiedShopFlowService
     */
    public $Include = array('ConfigurationService', 'SimplifiedShopFlowService', 'AfterShopFlowService');

    /** @var null The username used with the webservices */
    public $username = null;
    /** @var null The password used with the webservices */
    public $password = null;
    /** @var bool Enforcing of SSL/HTTPS */
    public $HTTPS = true;         /* Always require SSL */

    /** Section: BookPayment. Objects automatically used to store data, while preparing the booking object */

    /** @var string Default unit measure. "st" or styck for Sweden. If your plugin is not used for Sweden, use the proper unit for your country. */
    public $defaultUnitMeasure = "st";
    /** @var null Payment data object */
    private $_paymentData = null;
    /** @var null Object for speclines/specrows */
    private $_paymentSpeclines = null;
    /** @var null Counter for a specline */
    private $_specLineID = null;

    /** @var null Order data for the payment */
    private $_paymentOrderData = null;
    /** @var null Address data for the payment */
    private $_paymentAddress = null;
    /** @var null Normally used if billing and delivery differs (Sent to the gateway clientside) */
    private $_paymentDeliveryAddress = null;
    /** @var null Customer data for the payment */
    private $_paymentCustomer = null;
    /** @var null Customer data, extended, for the payment. For example when delivery address is set */
    private $_paymentExtendedCustomer = null;
    /** @var null Card data for the payment */
    private $_paymentCardData = null;

    /** @var null Card data object: Card number */
    private $cardDataCardNumber = null;
    /** @var null Card data object: The amount applied for the customer */
    private $cardDataUseAmount = false;
    /** @var null Card data object: If set, you can set up your own amount to apply for */
    private $cardDataOwnAmount = null;

    /**
     * Autodetecting of SSL capabilities section
     *
     * Default settings: Always disabled, to let the system handle this automatically.
     * If there are problems reaching wsdl or connecting to https://test.resurs.com, set $testssl to true
     *
     */

    /** @var bool PHP 5.6.0 or above only: If defined, try to guess if there is valid certificate bundles when using for example https links (used with openssl). This function tries to detect whether sslVerify should be used or not. The default value of this setting is normally false, since there should be no problems in a correctly installed environment. */
    public $testssl = false;
    /** @var bool Sets "verify SSL certificate in production required" if true (and if true, unverified SSL certificates will throw an error in production) - for auto-testing certificates only */
    public $sslVerifyProduction = true;
    /** @var bool Do not test certificates on older PHP-version (< 5.6.0) if this is false */
    public $testssldeprecated = false;
    /** @var array Default paths to the certificates we are looking for */
    public $sslPemLocations = array('/etc/ssl/certs/cacert.pem', '/etc/ssl/certs/ca-certificates.crt');
    /** @var bool During tests this will be set to true if certificate files is found */
    private $hasCertFile = false;
    /** @var bool During tests this will be set to true if certificate directory is found */
    private $hasCertDir = false;

    /** @var bool SSL Certificate verification setting. Setting this to false, we will ignore certificate errors */
    private $sslVerify = true;

    //private $_paymentCart = null;


    /**
     * Constructor method for Resurs Bank WorkFlows
     *
     * This method prepares initial variables for the workflow. No connections are being made from this point.
     *
     * @param string $login
     * @param string $password
     * @throws ResursException
     */
    function __construct($login = '', $password = '')
    {
        if (defined('RB_CWD')) {
            $this->classPath = RB_CWD;
        }
        /** RB_API_PATH overrides RB_CWD */
        if (defined('RB_API_PATH')) {
            $this->classPath = RB_API_PATH;
        }

        if (!class_exists('ReflectionClass')) {
            throw new \ResursException("ReflectionClass can not be found", 500, __FUNCTION__);
        }
        $this->soapOptions['cache_wsdl'] = (defined('WSDL_CACHE_BOTH') ? WSDL_CACHE_BOTH : true);
        $this->soapOptions['ssl_method'] = (defined('SOAP_SSL_METHOD_TLS') ? SOAP_SSL_METHOD_TLS : false);
        if (!is_null($login)) {
            $this->soapOptions['login'] = $login;
            $this->username = $login; // For use with initwsdl
        }
        if (!is_null($password)) {
            $this->soapOptions['password'] = $password;
            $this->password = $password; // For use with initwsdl
        }
    }

    /**
     * Function to enable/disabled SSL Peer/Host verification, if problems occur with certificates
     * @param bool|true $enabledFlag
     */
    public function setSslVerify($enabledFlag = true)
    {
        $this->sslVerify = $enabledFlag;
    }

    public function setEnvironment($environmentType = ResursEnvironments::ENVIRONMENT_TEST) {
        $this->current_environment = $environmentType;
    }

    /**
     * Find out if we have internal configuration enabled. The config file supports serialized (php) data and json-encoded content, but saves all data serialized.
     * @return bool
     */
    private function hasConfiguration()
    {
        /* Internally stored configuration - has to be activated on use */
        if ($this->configurationInternal) {
            if (defined('RB_API_CONFIG') && file_exists(RB_API_CONFIG . "/" . $this->configurationSystem)) {
                $this->configurationStorage = RB_API_CONFIG . "/" . $this->configurationSystem . "/config.data";
            } elseif (file_exists(__DIR__ . "/" . $this->configurationSystem)) {
                $this->configurationStorage = __DIR__ . "/" . $this->configurationSystem . "/config.data";
            }
            /* Initialize configuration storage if exists */
            if (!empty($this->configurationStorage) && !file_exists($this->configurationStorage)) {
                $defaults = array(
                    'system' => array(
                        'representative' => $this->username
                    )
                );

                @file_put_contents($this->configurationStorage, serialize($defaults), LOCK_EX);
                if (!file_exists($this->configurationStorage)) {
                    /* Disable internal configuration during this call, if no file has been found after initialization */
                    $this->configurationInternal = false;
                    return false;
                }
            }
        }
        if ($this->configurationInternal) {
            $this->config = file_get_contents($this->configurationStorage);
            $getArray = @unserialize($this->config);
            if (!is_array($getArray)) {
                $getArray = @json_decode($this->config, true);
            }
            if (!is_array($getArray)) {
                $this->configurationInternal = false;
                return false;
            } else {
                $this->configurationArray = $getArray;
                return true;
            }
        }
    }

    /**
     * TestCerts - Test if your webclient has certificates available (make sure the $testssldeprecated are enabled if you want to test older PHP-versions - meaning older than 5.6.0)
     * @return bool
     */
    public function TestCerts() {
        return $this->openssl_guess();
    }

    /**
     * Wsdl initializer - Everything communicating with RB Webservices are recommended to pass through here to generate a communication link
     * @return bool
     * @throws Exception
     */
    private function InitializeWsdl()
    {
        /**
         * Looking for certs on request here, instead of constructor level.
         */
        if ($this->testssl) { $this->openssl_guess(); }
        try {
            if (!$this->hasinit) {
                // if initWsdl is not public
                try {
                    $this->hasinit = $this->initWsdl();
                    return $this->hasinit;
                } catch (\Exception $e) {
                    $this->hasinit = false;
                    throw new \ResursException($e, 500, __FUNCTION__);
                }
            }
        } catch (\Exception $initWsdlException) {
            throw new \Exception($initWsdlException);
        }
        return $this->hasinit;
    }

    /**
     * If configuration file exists, this is the place where we're updating the content of it.
     * @param $arrayName The name of the array we're going to save
     * @param array $arrayContent The content of the array
     * @return bool If save is successful, we return true
     */
    private function updateConfig($arrayName, $arrayContent = array())
    {
        /* Make sure that the received array is really an array, since objects from ecom may be trashed during serialziation */
        $arrayContent = $this->objectsIntoArray($arrayContent);
        if ($this->configurationInternal && !empty($arrayName)) {
            $this->configurationArray[$arrayName] = $arrayContent;
            $this->configurationArray['lastUpdate'][$arrayName] = time();
            $serialized = @serialize($this->configurationArray);
            if (file_exists($this->configurationStorage)) {
                @file_put_contents($this->configurationStorage, $serialized, LOCK_EX);
                return true;
            }
        }
        return false;
    }

    /**
     * Returns an array with stored configuration (if stored configuration are enabled)
     * @return array
     */
    public function getConfigurationCache()
    {
        return $this->configurationArray;
    }

    /**
     * Get a timestamp for when the last cache of a call was requested and saved from Ecommerce
     * @param $cachedArrayName
     * @return int
     */
    public function getLastCall($cachedArrayName)
    {
        if (isset($this->configurationArray['lastUpdate']) && isset($this->configurationArray['lastUpdate'][$cachedArrayName])) {
            return time() - intval($this->configurationArray['lastUpdate'][$cachedArrayName]);
        }
    }

    private function classes($path = '')
    {
        foreach ($this->classPathFiles as $file) {
            if (file_exists($path . "/" . $file)) {
                return true;
            }
        }
    }

    protected function getVersionFull()
    {
        return $this->clientName . " v" . $this->version;
    }

    /**
     * Initializer for WSDL before calling services. Decides what username and environment to use. Default is always test.
     *
     * @throws Exception
     */
    private function initWsdl()
    {
        $this->hasConfiguration();
        $this->testWrappers();
        /*
         * Make sure that the correct webservice is loading first. The topmost service has the highest priority and will not be overwritten once loaded.
         * For example, if ShopFlowService is loaded before the SimplifiedShopFlowService, you won't be able to use the SimplifiedShopFlowService at all.
         *
         */
        $apiFileLoads = 0;
        $apiLoads = 0;

        /* Try to autodetect wsdl location and set up new path for where they can be loaded */
        if (!$this->classes($this->classPath)) {
            if ($this->classes($this->classPath . "/classes")) {
                $this->classPath = $this->classPath . "/classes";
            }
            if ($this->classes($this->classPath . "/classes/rbwsdl")) {
                $this->classPath = $this->classPath . "/classes/rbwsdl";
            }
            if ($this->classes($this->classPath . "/rbwsdl")) {
                $this->classPath = $this->classPath . "/rbwsdl";
            }
        }

        if (in_array('simplifiedshopflowservice', array_map("strtolower", $this->Include)) && file_exists($this->classPath . '/simplifiedshopflowservice-client/Resurs_SimplifiedShopFlowService.php')) {
            require $this->classPath . '/simplifiedshopflowservice-client/Resurs_SimplifiedShopFlowService.php';
            $apiFileLoads++;
        }
        if (in_array('configurationservice', array_map("strtolower", $this->Include)) && file_exists($this->classPath . '/configurationservice-client/Resurs_ConfigurationService.php')) {
            require $this->classPath . '/configurationservice-client/Resurs_ConfigurationService.php';
            $apiFileLoads++;
        }
        if (in_array('aftershopflowservice', array_map("strtolower", $this->Include)) && file_exists($this->classPath . '/aftershopflowservice-client/Resurs_AfterShopFlowService.php')) {
            require $this->classPath . '/aftershopflowservice-client/Resurs_AfterShopFlowService.php';
            $apiFileLoads++;
        }
        if (in_array('shopflowservice', array_map("strtolower", $this->Include)) && file_exists($this->classPath . '/shopflowservice-client/Resurs_ShopFlowService.php')) {
            require $this->classPath . '/shopflowservice-client/Resurs_ShopFlowService.php';
            $apiFileLoads++;
        }
        if (!$apiFileLoads) {
            throw new \ResursException("No service classes found", 500, __FUNCTION__);
        }

        // Requiring that SSL is available on the current server, will throw an exception if no HTTPS-wrapper is found.
        if (is_null($this->current_environment)) $this->current_environment = self::ENVIRONMENT_TEST;
        if ($this->username != null) $this->soapOptions['login'] = $this->username;
        if ($this->password != null) $this->soapOptions['password'] = $this->password;
        if ($this->current_environment == self::ENVIRONMENT_TEST) {
            $this->environment = $this->env_test;
        } else {
            $this->environment = $this->env_prod;
        }

        if (!$this->sslVerify) {
            $this->soapOptions['stream_context'] =
                stream_context_create(
                    array('ssl' =>
                        array(
                            'verify_peer' => 0,
                            'verify_peer_name' => 0,
                            'verify_host' => 0,
                            'allow_self_signed' => 1
                        )
                    )
                );
        }

        try {
            if (class_exists('Resurs_SimplifiedShopFlowService')) {
                $this->simplifiedShopFlowService = new Resurs_SimplifiedShopFlowService($this->soapOptions, $this->environment . "SimplifiedShopFlowService?wsdl");
                $apiLoads++;
            }
            if (class_exists('Resurs_ConfigurationService')) {
                $this->configurationService = new Resurs_ConfigurationService($this->soapOptions, $this->environment . "ConfigurationService?wsdl");
                $apiLoads++;
            }
            if (class_exists('Resurs_AfterShopFlowService')) {
                $this->afterShopFlowService = new Resurs_AfterShopFlowService($this->soapOptions, $this->environment . "AfterShopFlowService?wsdl");
                $apiLoads++;
            }
            if (class_exists('Resurs_ShopFlowService')) {
                $this->shopFlowService = new Resurs_ShopFlowService($this->soapOptions, $this->environment . "ShopFlowService?wsdl");
                $apiLoads++;
            }
            //if (class_exists('DeveloperWebService')) {$this->developerWebService = new DeveloperWebService($this->soapOptions, $this->environment . "DeveloperWebService?wsdl");}
        } catch (Exception $e) {
            throw new \ResursException($e->getMessage(), 500, __FUNCTION__);
        }
        if (!$apiFileLoads) {
            throw new \ResursException("No service loaded", 500, __FUNCTION__);
        }

        return true;
    }


    /**
     * Handling of SSL certificates (Untested in Windows server environments) when using OpenSSL
     *
     * Note: The default value of this set up is normally false (do not run), since there should be no problems in a correctly installed environment. If there are known problems
     * in the used environment, however, you can try to set $testssl to true.
     *
     * This section are set up to help web stores (at least in test environments) communicating with Resurs Ecommerce without worrying about failing SSL certficates.
     * At first, the variable $testssl is used to automatically try to find out if there is valid certificate bundles installed on the running system. In PHP 5.6.0 and higher
     * this procedure is simplified with the help of openssl_get_cert_locations(), which gives us a default path to installed certificates. In this case we will first look there
     * for the certificate bundle. If we do fail there, or if your system is running something older, the testing are running in guessing mode.
     *
     * In test environments, this function will skip the verifications so calling web services are not prevented by missing certificates. In production environments, an
     * error will be thrown.
     *
     * All those settings can be disabled. Setting testssl to false, this script will fall back into normal behaviour (meaning, if certificates is missing, the SOAP will throw errors instead).
     * To skip SSL verification in production, set $sslVerifyProduction to false. $teestssldeprecated is by default set to true, which means there will be a few tests for PHP versions
     * that is lower than 5.6.0
     *
     * However, all this can be overridden by setting $testssl and setSslVerify(false). In this mode, we will enter "skip verification" immediately.
     *
     * @return bool
     * @throws ResursException
     * @link https://test.resurs.com/docs/x/KYM0 More information on what this functionality is built on
     */
    private function openssl_guess()
    {
        /* SSL Verify disabled by user? Skip this part. */
        if (!$this->sslVerify) {return false;}
        if ($this->testssl) {
            if (version_compare(PHP_VERSION, "5.6.0", ">=") && function_exists("openssl_get_cert_locations")) {
                $locations = openssl_get_cert_locations();
                if (null !== $locations && is_array($locations)) {
                    if (isset($locations['default_cert_file'])) {
                        if (file_exists($locations['default_cert_file'])) { $this->hasCertFile = true; }
                        if (file_exists($locations['default_cert_dir'])) { $this->hasCertDir = true; }

                        /* Sometimes certificates are located in a default location, which is /etc/ssl/certs - this part scans through such directories for a proper cert-file */
                        if (!$this->hasCertFile && is_array($this->sslPemLocations) && count($this->sslPemLocations)) {
                            /* Loop through suggested locations and set a cafile if found */
                            foreach ($this->sslPemLocations as $pemLocation) {
                                if (file_exists($pemLocation)) {
                                   ini_set('openssl.cafile', $pemLocation);
                                   $this->hasCertFile = true;
                                }
                            }
                        }
                    }
                }
                /* On guess, disable verification if failed */
                if (!$this->hasCertFile) {
                    if ($this->current_environment === self::ENVIRONMENT_PRODUCTION) {
                        if ($this->sslVerifyProduction) {
                            throw new ResursException("Auto detection of valid SSL certificate failed in production environment.", 403, __FUNCTION__);
                        } else {
                            $this->setSslVerify(false);
                        }
                    } else {
                        $this->setSslVerify(false);
                    }
                }
            } else {
                /* If we run on other PHP versions than 5.6.0 or higher, try to fall back into a known directory */
                if ($this->testssldeprecated) {
                    if (!$this->hasCertFile && is_array($this->sslPemLocations) && count($this->sslPemLocations)) {
                        /* Loop through suggested locations and set a cafile if found */
                        foreach ($this->sslPemLocations as $pemLocation) {
                            if (file_exists($pemLocation)) {
                                ini_set('openssl.cafile', $pemLocation);
                                $this->hasCertFile = true;
                            }
                        }
                    }
                    if (!$this->hasCertFile) {
                        if ($this->current_environment === self::ENVIRONMENT_PRODUCTION) {
                            if ($this->sslVerifyProduction) {
                                throw new ResursException("Auto detection of valid SSL certificate failed in production environment.", 403, __FUNCTION__);
                            } else {
                                $this->setSslVerify(false);
                            }
                        } else {
                            $this->setSslVerify(false);
                        }
                    }
                }
            }
        }
        return $this->hasCertFile;
    }

    /** Special set up for internal tests */
    public function setNonMock()
    {
        $this->env_test = "https://test.resurs.com/ecommerce/ws/V4/";
    }

    /**
     * Check HTTPS-requirements, if they pass.
     *
     * Resurs Bank requires secure connection to the webservices, so your PHP-version must support SSL. Normally this is not a problem, but since there are server- and hosting providers that is actually having this disabled, the decision has been made to do this check.
     * @throws Exception
     */
    private function testWrappers()
    {
        if ($this->HTTPS === true) {
            if (!in_array('https', @stream_get_wrappers())) {
                throw new \ResursException("HTTPS wrapper can not be found", 500, __FUNCTION__);
            }
        }
    }

    /**
     * ResponseObjectArrayParser. Translates a return-object to a clean array
     * @param null $returnObject
     * @return array
     */
    public function parseReturn($returnObject = null)
    {
        $hasGet = false;
        if (is_array($returnObject)) {
            $parsedArray = array();
            foreach ($returnObject as $arrayName => $objectArray) {
                $classMethods = get_class_methods($objectArray);
                if (is_array($classMethods)) {
                    foreach ($classMethods as $classMethodId => $classMethod) {
                        if (preg_match("/^get/i", $classMethod)) {
                            $hasGet = true;
                            $field = lcfirst(preg_replace("/^get/i", '', $classMethod));
                            $objectContent = $objectArray->$classMethod();
                            if (is_array($objectContent)) {
                                $parsedArray[$arrayName][$field] = $this->parseReturn($objectContent);
                            } else {
                                $parsedArray[$arrayName][$field] = $objectContent;
                            }
                        }
                    }
                }
            }
            /* Failver test */
            if (!$hasGet && !count($parsedArray)) {
                return $this->objectsIntoArray($returnObject);
            }
            return $parsedArray;
        }
    }

    /**
     * Convert objects to array data
     * @param $arrObjData
     * @param array $arrSkipIndices
     * @return array
     */
    function objectsIntoArray($arrObjData, $arrSkipIndices = array())
    {
        $arrData = array();
        // if input is object, convert into array
        if (is_object($arrObjData)) {
            $arrObjData = get_object_vars($arrObjData);
        }
        if (is_array($arrObjData)) {
            foreach ($arrObjData as $index => $value) {
                if (is_object($value) || is_array($value)) {
                    $value = $this->objectsIntoArray($value, $arrSkipIndices); // recursive call
                }
                if (@in_array($index, $arrSkipIndices)) {
                    continue;
                }
                $arrData[$index] = $value;
            }
        }
        return $arrData;
    }


    /**
     * Unknown methods passthrough
     *
     * Unknown calls passed through __call(), so that we may cover functions unsupported by the gateway.
     * This stub-gateway processing is also checking if the methods really exist in the stubs and passing them over is they do.<br>
     * <br>
     * This method also takes control of responses and returns the object "return" if it exists.<br>
     * The function also supports array, by adding "Array" to the end of the method.<br>
     *
     * @param null $func
     * @param array $args
     * @return array|null
     * @throws Exception
     *
     */
    public function __call($func = null, $args = array())
    {
        /* Initializing wsdl if not done is required here */
        $this->InitializeWsdl();

        $returnObject = null;
        $this->serviceReturn = null;
        $returnAsArray = false;
        $classfunc = null;
        $funcArgs = null;
        $returnContent = null;
        //if (isset($args[0]) && is_array($args[0])) {}
        $classfunc = "resurs_" . $func;
        if (preg_match("/Array$/", $func)) {
            $func = preg_replace("/Array$/", '', $func);
            $classfunc = preg_replace("/Array$/", '', $classfunc);
            $returnAsArray = true;
        }


        try {
            $reflection = new ReflectionClass($classfunc);
            $instance = $reflection->newInstanceArgs($args);
            // Check availability, fetch and stop on first match
            if (!isset($returnObject) && in_array($func, get_class_methods("Resurs_SimplifiedShopFlowService"))) {
                $this->serviceReturn = "SimplifiedShopFlowService";
                $returnObject = $this->simplifiedShopFlowService->$func($instance);
            }
            if (!isset($returnObject) && in_array($func, get_class_methods("Resurs_ConfigurationService"))) {
                $this->serviceReturn = "ConfigurationService";
                $returnObject = $this->configurationService->$func($instance);
            }
            if (!isset($returnObject) && in_array($func, get_class_methods("Resurs_AfterShopFlowService"))) {
                $this->serviceReturn = "AfterShopFlowService";
                $returnObject = $this->afterShopFlowService->$func($instance);
            }
            if (!isset($returnObject) && in_array($func, get_class_methods("Resurs_ShopFlowService"))) {
                $this->serviceReturn = "ShopFlowService";
                $returnObject = $this->shopFlowService->$func($instance);
            }
            //if (!isset($returnObject) && in_array($func, get_class_methods("DeveloperService"))) {$this->serviceReturn = "DeveloperService";$returnObject = $this->developerService->$func($instance);}
        } catch (Exception $e) {
            throw new \ResursException($e, 500, __FUNCTION__);
        }
        try {
            //if (method_exists($returnObject, "getReturn")) {
            if (isset($returnObject) && !empty($returnObject) && isset($returnObject->return) && !empty($returnObject->return)) {
                //$returnContent = $returnObject->getReturn();
                $returnContent = $returnObject->return;
                if ($returnAsArray) {
                    return $this->parseReturn($returnContent);
                }
            } else {
                if (!empty($returnObject) && $returnAsArray) {
                    return array();
                }
            }
            return $returnContent;
        } catch (Exception $returnObjectException) {
        }
        if ($returnAsArray) {
            return $this->parseReturn($returnObject);
        }
        return $returnObject;
    }


    /**
     * Simplifed callback registrator. Also handles re-registering of callbacks in case of already found in system.
     *
     * Register a callback (returning a boolean depending on the registration result):<br>
     * <br>
     * <pre>
     *    $digestArray = array(
     *       'digestSalt' => 'digestSaltString',
     *       'digestParameters' => array('paymentId', 'result')
     *    );
     *   $callbackSetResult = $rbapi->setCallback(ResursCallbackTypes::AUTOMATIC_FRAUD_CONTROL, "http://localhost/callbacks/digest/{digest}/paymentId/{paymentId}", $digestArray);
     * </pre>
     *
     * @param null $callbackType
     * @param null $callbackUriTemplate
     * @param array $callbackDigest
     * @param null $basicAuthUserName
     * @param null $basicAuthPassword
     * @return bool
     * @throws Exception
     */
    public function setCallback($callbackType = null, $callbackUriTemplate = null, $callbackDigest = array(), $basicAuthUserName = null, $basicAuthPassword = null)
    {
        $this->InitializeWsdl();

        if (!is_array($callbackDigest) || empty($callbackDigest)) {
            throw new \ResursException("Insufficient callback digest data for callback registration", 500, __FUNCTION__);
        }
        $renderCallback = array();
        $digestParameters = array();
        if ($callbackType == ResursCallbackTypes::ANNULMENT) {
            $renderCallback['eventType'] = "ANNULMENT";
        }
        if ($callbackType == ResursCallbackTypes::AUTOMATIC_FRAUD_CONTROL) {
            $renderCallback['eventType'] = "AUTOMATIC_FRAUD_CONTROL";
        }
        if ($callbackType == ResursCallbackTypes::UNFREEZE) {
            $renderCallback['eventType'] = "UNFREEZE";
        }
        if ($callbackType == ResursCallbackTypes::FINALIZATION) {
            $renderCallback['eventType'] = "FINALIZATION";
        }
        if ($callbackType == ResursCallbackTypes::TEST) {
            $renderCallback['eventType'] = "TEST";
        }
        if ($callbackType == ResursCallbackTypes::UPDATE) {
            $renderCallback['eventType'] = "UPDATE";
        }
        if (count($renderCallback) && $renderCallback['eventType'] != "" && $callbackUriTemplate != "") {
            $regCallBackResult = false;
            $registerCallbackClass = new resurs_registerEventCallback($renderCallback['eventType'], $callbackUriTemplate);
            $digestAlgorithm = resurs_digestAlgorithm::SHA1;

            /* Look for parameters in the request. Algorithms are set to SHA1 by default. If no digestsalts are set, we will throw you an exception, since empty salts is normally not a good idea */
            if (is_array($callbackDigest)) {
                if (isset($callbackDigest['digestAlgorithm']) && strtolower($callbackDigest['digestAlgorithm']) != "sha1" && strtolower($callbackDigest['digestAlgorithm']) != "md5") {
                    $callbackDigest['digestAlgorithm'] = "sha1";
                } elseif (!isset($callbackDigest['digestAlgorithm'])) {
                    $callbackDigest['digestAlgorithm'] = "sha1";
                }
                /* If requested algorithm is not sha1, use md5 as the other option. */
                if ($callbackDigest['digestAlgorithm'] != "sha1") {
                    $digestAlgorithm = digestAlgorithm::MD5;
                }

                /* Start collect the parameters needed for the callback. */
                $parameterArray = array();
                if (isset($callbackDigest['digestParameters']) && is_array($callbackDigest['digestParameters'])) {
                    foreach ($callbackDigest['digestParameters'] as $parameter) {
                        array_push($parameterArray, $parameter);
                    }
                }

                /* Make sure there is a saltkey. */
                if (isset($callbackDigest['digestSalt']) && !empty($callbackDigest['digestSalt'])) {
                    $digestParameters['digestSalt'] = $callbackDigest['digestSalt'];
                } else {
                    throw new \ResursException("No salt key for digest found", 500, __FUNCTION__);
                }
                $digestParameters['digestParameters'] = (is_array($parameterArray) ? $parameterArray : array());
            }
            /* Generate a digest configuration for the services. */
            $digestConfiguration = new resurs_digestConfiguration($digestAlgorithm, $digestParameters['digestParameters']);
            $digestConfiguration->digestSalt = $digestParameters['digestSalt'];

            /* Old stub call */
            // $digestConfiguration->setDigestSalt($digestParameters['digestSalt']);

            /* Unregister any old callbacks if found. */
            try {
                $this->unregisterEventCallback($renderCallback['eventType']);
            } catch (Exception $e) {
            }   // Unregister old callback first
            if (!empty($basicAuthUserName)) {
                $registerCallbackClass->setBasicAuthUserName($basicAuthUserName);
            }
            if (!empty($basicAuthPassword)) {
                $registerCallbackClass->setBasicAuthPassword($basicAuthPassword);
            }

            /* Prepare for the primary digestive data. */
            /* Old stub call */
            //$registerCallbackClass->setDigestConfiguration($digestConfiguration);
            $registerCallbackClass->digestConfiguration = $digestConfiguration;
            try {
                /* And register the rendered callback at the service. Make sure that configurationService is really there before doing this. */
                $regCallBackResult = $this->configurationService->registerEventCallback($registerCallbackClass);
            } catch (Exception $rbCallbackEx) {
                /* Set up a silent failover, and return false if the callback registration failed. Set the error into the lastError-variable. */
                $regCallBackResult = false;
                $this->lastError = $rbCallbackEx->getMessage();
            }
            return $regCallBackResult;
        } else {
            throw new \ResursException("Insufficient data for callback registration", 500, __FUNCTION__);
        }
    }

    /**
     * List payment methods
     *
     * Retrieves detailed information on the payment methods available to the representative. Parameters (customerType, language and purchaseAmount) are optional.
     * @link https://test.resurs.com/docs/display/ecom/Get+Payment+Methods
     *
     * @param array $parameters
     * @return mixed
     * @throws Exception
     */
    public function getPaymentMethods($parameters = array())
    {
        $this->InitializeWsdl();

        $paymentMethodParameters = new resurs_getPaymentMethods();
        if (isset($parameters['customerType'])) {
            $paymentMethodParameters->customerType = $parameters['customerType'];
        }
        if (isset($parameters['language'])) {
            $paymentMethodParameters->language = $parameters['language'];
        }
        if (isset($parameters['purchaseAmount'])) {
            $paymentMethodParameters->purchaseAmount = $parameters['purchaseAmount'];
        }
        $return = (isset($this->simplifiedShopFlowService->getPaymentMethods($paymentMethodParameters)->return) ? $this->simplifiedShopFlowService->getPaymentMethods($paymentMethodParameters)->return : array());
        $this->updateConfig('getPaymentMethods', $return);
        return $return;
    }

    /**
     * Get the list of Resurs Bank payment methods from cache, instead of live (Cache function needs to be active)
     * @return array
     * @throws Exception
     */
    public function getPaymentMethodsCache()
    {
        if ($this->hasConfiguration()) {
            if (isset($this->configurationArray['getPaymentMethods']) && is_array($this->configurationArray['getPaymentMethods']) && count($this->configurationArray) && !$this->cacheExpired('getPaymentMethods')) {
                return $this->configurationArray['getPaymentMethods'];
            } else {
                return $this->objectsIntoArray($this->getPaymentMethods());
            }
        } else {
            throw new \ResursException("Can not fetch payment methods from cache. You must enable internal caching first.", 500, __FUNCTION__);
        }
    }

    /**
     * Test if a stored configuration (cache) has expired and needs to be renewed.
     * @param $cachedArrayName
     * @return bool
     */
    private function cacheExpired($cachedArrayName)
    {
        if ($this->getLastCall($cachedArrayName) >= $this->configurationCacheTimeout) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Get annuityfactors from payment method through cache, instead of live (Cache function needs to be active)
     * @param $paymentMethod Given payment method
     * @return array
     * @throws Exception
     */
    public function getAnnuityFactorsCache($paymentMethod)
    {
        if ($this->hasConfiguration()) {
            if (isset($this->configurationArray['getAnnuityFactors']) && isset($this->configurationArray['getAnnuityFactors'][$paymentMethod]) && is_array($this->configurationArray['getAnnuityFactors']) && is_array($this->configurationArray['getAnnuityFactors'][$paymentMethod]) && count($this->configurationArray['getAnnuityFactors'][$paymentMethod]) && !$this->cacheExpired('getPaymentMethods')) {
                return $this->configurationArray['getAnnuityFactors'][$paymentMethod];
            } else {
                return $this->objectsIntoArray($this->getAnnuityFactors($paymentMethod));
            }
        } else {
            throw new \ResursException("Can not fetch annuity factors from cache. You must enable internal caching first.", 500, __FUNCTION__);
        }
    }

    /**
     * getAnnuityFactors Displays
     *
     * Retrieves the annuity factors for a given payment method. The duration is given is months. While this makes most sense for payment methods that consist of part payments (i.e. new account), it is possible to use for all types. It returns a list of with one annuity factor per payment plan of the payment method. There are typically between three and six payment plans per payment method. If no payment method are given to this function, the first available method will be used (meaning this function will also make a getPaymentMethods()-request which will delay the primary call a bit).
     * @link https://test.resurs.com/docs/display/ecom/Get+Annuity+Factors Ecommerce Docs for getAnnuityFactors
     *
     * @param string $paymentMethodId
     * @return mixed
     * @throws Exception
     */
    public function getAnnuityFactors($paymentMethodId = '')
    {
        $this->InitializeWsdl();
        $firstMethod = array();
        if (empty($paymentMethodId) || is_null($paymentMethodId)) {
            $methodsAvailable = $this->getPaymentMethods();
            if (is_array($methodsAvailable) && count($methodsAvailable)) {
                $firstMethod = array_pop($methodsAvailable);
                $paymentMethodId = isset($firstMethod->id) ? $firstMethod->id : null;
                if (empty($paymentMethodId)) {
                    throw new \ResursException("getAnnuityFactorsException: No available payment method", 500, __FUNCTION__);
                }
            }
        }
        $annuityParameters = new resurs_getAnnuityFactors($paymentMethodId);
        $return = $this->simplifiedShopFlowService->getAnnuityFactors($annuityParameters)->return;
        if ($this->configurationInternal) {
            $CurrentAnnuityFactors = isset($this->configurationArray['getAnnuityFactors']) ? $this->configurationArray['getAnnuityFactors'] : array();
            $CurrentAnnuityFactors[$paymentMethodId] = $return;
            $this->updateConfig('getAnnuityFactors', $CurrentAnnuityFactors);
        }
        return $return;
    }

    /**
     * Prepare a payment
     *
     * @param $paymentMethodId
     * @param array $paymentDataArray
     * @throws Exception
     */
    public function updatePaymentdata($paymentMethodId, $paymentDataArray = array())
    {
        $this->InitializeWsdl();
        if (!is_object($this->_paymentData)) {
            $this->_paymentData = new resurs_paymentData($paymentMethodId);
        }
        $this->_paymentData->preferredId = isset($paymentDataArray['preferredId']) && !empty($paymentDataArray['preferredId']) ? $paymentDataArray['preferredId'] : null;
        $this->_paymentData->paymentMethodId = $paymentMethodId;
        $this->_paymentData->customerIpAddress = (isset($paymentDataArray['customerIpAddress']) && !empty($paymentDataArray['customerIpAddress']) ? $paymentDataArray['customerIpAddress'] : (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1'));
        $this->_paymentData->waitForFraudControl = isset($paymentDataArray['waitForFraudControl']) && !empty($paymentDataArray['waitForFraudControl']) ? $paymentDataArray['waitForFraudControl'] : false;
        $this->_paymentData->annulIfFrozen = isset($paymentDataArray['annulIfFrozen']) && !empty($paymentDataArray['annulIfFrozen']) ? $paymentDataArray['annulIfFrozen'] : false;
        $this->_paymentData->finalizeIfBooked = isset($paymentDataArray['finalizeIfBooked']) && !empty($paymentDataArray['finalizeIfBooked']) ? $paymentDataArray['finalizeIfBooked'] : false;
    }

    /**
     * Update cart
     *
     * @param array $speclineArray
     * @throws Exception
     */
    public function updateCart($speclineArray = array())
    {
        $this->InitializeWsdl();

        $realSpecArray = array();
        if (isset($speclineArray['artNo'])) {
            // If this require parameter is found first in the array, it's a single specrow.
            // In that case, push it out to be a multiple.
            array_push($realSpecArray, $speclineArray);
        } else {
            $realSpecArray = $speclineArray;
        }

        // Handle the specrows as they were many.
        foreach ($realSpecArray as $specIndex => $speclineArray) {
            $quantity = (isset($speclineArray['quantity']) && !empty($speclineArray['quantity']) ? $speclineArray['quantity'] : 1);
            $unitAmountWithoutVat = (is_numeric(floatval($speclineArray['unitAmountWithoutVat'])) ? $speclineArray['unitAmountWithoutVat'] : 0);
            $vatPct = (isset($speclineArray['vatPct']) && !empty($speclineArray['vatPct']) ? $speclineArray['vatPct'] : 0);
            //$totalVatAmountInternal = round(($unitAmountWithoutVat*$quantity)-($unitAmountWithoutVat/(1+($vatPct/100))*$quantity),2);
            $totalVatAmountInternal = ($unitAmountWithoutVat * ($vatPct / 100)) * $quantity;
            $totalAmountInclTax = round(($unitAmountWithoutVat * $quantity) + $totalVatAmountInternal, 2);

            if (isset($speclineArray['totalVatAmount']) && !empty($speclineArray['totalVatAmount'])) {
                $totalVatAmount = $speclineArray['totalVatAmount'];
                $totalAmountInclTax = $unitAmountWithoutVat + $totalVatAmount;
            } else {
                $totalVatAmount = $totalVatAmountInternal;
            }

            if (!class_exists('resurs_specLine')) {
                throw new \ResursException("Class specLine does not exist", 500, __FUNCTION__);
            }
            $this->_specLineID++;
            $this->_paymentSpeclines[] = new resurs_specLine(
                $this->_specLineID,
                $speclineArray['artNo'],
                $speclineArray['description'],
                $speclineArray['quantity'],
                (isset($speclineArray['unitMeasure']) && !empty($speclineArray['unitMeasure']) ? $speclineArray['unitMeasure'] : $this->defaultUnitMeasure),
                $unitAmountWithoutVat,
                $vatPct,
                $totalVatAmount,
                $totalAmountInclTax
            );
        }
    }

    /**
     * Update payment specs and prepeare specrows
     *
     * @param array $specLineArray
     * @throws Exception
     */
    public function updatePaymentSpec($specLineArray = array())
    {
        $this->InitializeWsdl();
        $totalAmount = 0;
        $totalVatAmount = 0;
        if (is_array($specLineArray) && count($specLineArray)) {
            foreach ($specLineArray as $specRow => $specRowArray) {
                $totalAmount += (isset($specRowArray->totalAmount) ? $specRowArray->totalAmount : 0);
                $totalVatAmount += (isset($specRowArray->totalVatAmount) ? $specRowArray->totalVatAmount : 0);
            }
        }
        $this->_paymentOrderData = new resurs_paymentSpec($specLineArray, $totalAmount, 0);
        $this->_paymentOrderData->totalVatAmount = floatval($totalVatAmount);
    }

    /**
     * Prepare customer address data
     *
     * @param array $addressArray
     * @param array $customerArray
     * @throws Exception
     */
    public function updateAddress($addressArray = array(), $customerArray = array())
    {
        $this->InitializeWsdl();
        $resursDeliveryAddress = null;

        if (isset($addressArray['address'])) {
            $address = new resurs_address($addressArray['address']['fullName'], $addressArray['address']['firstName'], $addressArray['address']['lastName'], (isset($addressArray['address']['addressRow1']) ? $addressArray['address']['addressRow1'] : null), (isset($addressArray['address']['addressRow2']) ? $addressArray['address']['addressRow2'] : null), $addressArray['address']['postalArea'], $addressArray['address']['postalCode'], $addressArray['address']['country']);
            if (isset($addressArray['deliveryAddress'])) {
                $resursDeliveryAddress = new resurs_address($addressArray['deliveryAddress']['fullName'], $addressArray['deliveryAddress']['firstName'], $addressArray['deliveryAddress']['lastName'], (isset($addressArray['deliveryAddress']['addressRow1']) ? $addressArray['deliveryAddress']['addressRow1'] : null), (isset($addressArray['deliveryAddress']['addressRow2']) ? $addressArray['deliveryAddress']['addressRow2'] : null), $addressArray['deliveryAddress']['postalArea'], $addressArray['deliveryAddress']['postalCode'], $addressArray['deliveryAddress']['country']);
            }
        } else {
            $address = new resurs_address($addressArray['fullName'], $addressArray['firstName'], $addressArray['lastName'], (isset($addressArray['addressRow1']) ? $addressArray['addressRow1'] : null), (isset($addressArray['addressRow2']) ? $addressArray['addressRow2'] : null), $addressArray['postalArea'], $addressArray['postalCode'], $addressArray['country']);
        }
        $customer = new resurs_customer($customerArray['governmentId'], $address, $customerArray['phone'], $customerArray['email'], $customerArray['type']);
        $this->_paymentAddress = $address;
        if (!empty($resursDeliveryAddress) || $customerArray['type'] == "LEGAL") {
            if (isset($resursDeliveryAddress) && is_array($resursDeliveryAddress)) {
                $this->_paymentDeliveryAddress = $resursDeliveryAddress;
            }
            $extendedCustomer = new resurs_extendedCustomer($customerArray['governmentId'], $resursDeliveryAddress, $customerArray['phone'], $customerArray['email'], $customerArray['type']);
            $this->_paymentExtendedCustomer = $extendedCustomer;
            /* #59042 => #59046 (Additionaldata should be empty) */
            if (empty($this->_paymentExtendedCustomer->additionalData)) {
                unset($this->_paymentExtendedCustomer->additionalData);
            }
            if ($customerArray['type'] == "LEGAL") {
                $extendedCustomer->contactGovernmentId = $customerArray['contactGovernmentId'];
            }
            if (!empty($customerArray['cellPhone'])) {
                $extendedCustomer->cellPhone = $customerArray['cellPhone'];
            }
        }
        $this->_paymentCustomer = $customer;
        if (isset($extendedCustomer)) {
            $extendedCustomer->address = $address;
            $this->_paymentCustomer = $extendedCustomer;
        }
    }

    /**
     * Internal handler for carddata
     * @throws Exception
     */
    private function updateCardData()
    {
        $amount = null;
        $this->_paymentCardData = new resurs_cardData();
        if (!isset($this->cardDataCardNumber)) {
            if ($this->cardDataUseAmount && $this->cardDataOwnAmount) {
                $this->_paymentCardData->amount = $this->cardDataOwnAmount;
            } else {
                $this->_paymentCardData->amount = $this->_paymentOrderData->totalAmount;
            }
        } else {
            if (isset($this->cardDataCardNumber) && !empty($this->cardDataCardNumber)) {
                $this->_paymentCardData->cardNumber = $this->cardDataCardNumber;
            }
        }
        if (!empty($this->cardDataCardNumber) && !empty($this->cardDataUseAmount)) {
            throw new \ResursException("Card number and amount can not be set at the same time", 500, __FUNCTION__);
        }
        return $this->_paymentCardData;
    }

    /**
     * Prepare API for cards. Make sure only one of the parameters are used. Cardnumber cannot be combinad with amount.
     *
     * @param null $cardNumber
     * @param bool|false $useAmount Set to true when using new cards
     * @param bool|false $setOwnAmount If customer applies for a new card specify the credit amount that is applied for. If $setOwnAmount is not null, this amount will be used instead of the specrow data
     * @throws Exception
     */
    public function prepareCardData($cardNumber = null, $useAmount = false, $setOwnAmount = null)
    {
        if (!is_null($cardNumber)) {
            if (is_numeric($cardNumber)) {
                $this->cardDataCardNumber = $cardNumber;
            } else {
                throw new \ResursException("Card number must be numeric", 500, __FUNCTION__);
            }
        }
        if ($useAmount) {
            $this->cardDataUseAmount = true;
            if (!is_null($setOwnAmount) && is_numeric($setOwnAmount)) {
                $this->cardDataOwnAmount = $setOwnAmount;
            }
        }
    }


    /**
     * The Major bookPayment Method.
     *
     * Primary "compiler" for booking payments. Needs an array that is built in a similar way that is documented at test.resurs.com, but simplified.<br>
     * Example:<br>
     * <pre>
     * $bookData['specLine'] = array(
     * 'artNo' => 'art_0_1',
     * 'description' => 'Artikel nummer 1',
     * 'quantity' => 1,
     * 'unitAmountWithoutVat' => 500,
     * 'vatPct' => 25
     * );
     * $bookData['address'] = array(
     * 'fullName' => 'Test Testsson',
     * 'firstName' => 'Test',
     * 'lastName' => 'Testsson',
     * 'addressRow1' => 'Testgatan 1',
     * 'postalArea' => 'Testort',
     * 'postalCode' => '12121',
     * 'country' => 'SE'
     * );
     * $bookData['customer'] = array(
     * 'governmentId' => '198305147715',
     * 'phone' => '0101010101',
     * 'email' => 'test@test.com',
     * 'type' => 'NATURAL'
     * );
     * $bookData['signing'] = array(
     * 'successUrl' => 'http://test.example.com/success/',
     * 'failUrl' => 'http://test.example.com/fail/',
     * 'forceSigning' => false
     * );
     * $rbapi->bookPayment("112", $bookData);
     * </pre>
     * @link https://test.resurs.com/docs/display/ecom/bookPayment
     * @link URL PHPURL goes here
     *
     * @param $paymentMethodId
     * @param array $bookData
     * @throws Exception
     */
    public function bookPayment($paymentMethodId = '', $bookData = array())
    {
        if (empty($paymentMethodId)) {
            return;
        }
        $this->InitializeWsdl();
        $this->updatePaymentdata($paymentMethodId, isset($bookData['paymentData']) && is_array($bookData['paymentData']) && count($bookData['paymentData']) ? $bookData['paymentData'] : array());
        $this->updateCart(isset($bookData['specLine']) ? $bookData['specLine'] : array());
        $this->updatePaymentSpec($this->_paymentSpeclines);
        if (isset($bookData['deliveryAddress'])) {
            $addressArray = array(
                'address' => $bookData['address'],
                'deliveryAddress' => $bookData['deliveryAddress']
            );
            $this->updateAddress(isset($addressArray) ? $addressArray : array(), isset($bookData['customer']) ? $bookData['customer'] : array());
        } else {
            $this->updateAddress(isset($bookData['address']) ? $bookData['address'] : array(), isset($bookData['customer']) ? $bookData['customer'] : array());
        }
        $bookPaymentInit = new resurs_bookPayment($this->_paymentData, $this->_paymentOrderData, $this->_paymentCustomer);

        if (!empty($this->cardDataCardNumber) || $this->cardDataUseAmount) {
            $bookPaymentInit->card = $this->updateCardData();
        }
        if (!empty($this->_paymentDeliveryAddress) && is_object($this->_paymentDeliveryAddress)) {
            $bookPaymentInit->customer->deliveryAddress = $this->_paymentDeliveryAddress;
        }
        $bookPaymentInit->signing = $bookData['signing'];
        $bookPaymentResult = $this->simplifiedShopFlowService->bookPayment($bookPaymentInit);
        return $bookPaymentResult;
    }


    /**
     * Simplified AfterShopFlow starts here
     */


    /**
     * Get next invoice number - and initialize if not set.
     * @param bool $initInvoice Initializes invoice number if not set (if not set, this is set to 1 if nothing else is set)
     * @param int $firstInvoiceNumber Initializes invoice number sequence with this value if not set and requested
     * @return int Returns
     * @throws Exception
     */
    public function getNextInvoiceNumber($initInvoice = true, $firstInvoiceNumber = 1) {
        $this->InitializeWsdl();
        $invoiceNumber = null;
        $peek = null;
        try {
            $peek = $this->configurationService->peekInvoiceSequence(array('nextInvoiceNumber' => null));
            $invoiceNumber = $peek->nextInvoiceNumber;
        } catch (\Exception $e) { }
        if (empty($invoiceNumber) && $initInvoice) {
            $this->configurationService->setInvoiceSequence(array('nextInvoiceNumber' => $firstInvoiceNumber));
            $invoiceNumber = $firstInvoiceNumber;
        }
        return $invoiceNumber;
    }

    /**
     * Convert version number to decimals
     * @return string
     */
    private function versionToDecimals() {
        $splitVersion = explode(".", $this->version);
        $decVersion = "";
        foreach ($splitVersion as $ver) {
            $decVersion .= str_pad(intval($ver), 2, "0", STR_PAD_LEFT);
        }
        return $decVersion;
    }

    /**
     * Scan client specific specrows for matches
     *
     * @param $clientPaymentSpec
     * @param $artNo
     * @param $quantity
     * @param bool $quantityMatch
     * @param bool $useSpecifiedQuantity If set to true, the quantity set clientside will be used rather than the exact quantity from the spec in getPayment (This requires that $quantityMatch is set to false)
     * @return bool
     */
    private function inSpec($clientPaymentSpec, $artNo, $quantity, $quantityMatch = true, $useSpecifiedQuantity = false)
    {
        $foundArt = false;
        foreach ($clientPaymentSpec as $row) {
            if (isset($row['artNo'])) {
                if ($row['artNo'] == $artNo) {
                    // If quantity match is true, quantity must match the request to return a true value
                    if ($quantityMatch)
                    {
                        // Consider full quantity if no quantity is set
                        if (!isset($row['quantity'])) {
                            $foundArt = true;
                            return true;
                        }
                        if (isset($row['quantity']) && (float)$row['quantity'] === (float)$quantity) {
                            return true;
                        } else {
                            // Eventually set this to false, unless the float controll is successful
                            $foundArt = false;
                            // If the float control fails, also try check against integers
                            if (isset($row['quantity']) && intval($row['quantity']) > 0 && intval($quantity)> 0 && intval($row['quantity']) === intval($quantity)) {
                                return true;
                            }
                        }
                    } else {
                        return true;
                    }
                } else {
                    $foundArt = false;
                }
            }
        }
        return $foundArt;
    }

    private function handleClientPaymentSpec($clientPaymentSpec = array()) {
        /**
         * Make sure we are pushing in this spec in the correct format, which is:
         * array(
         *  [0] => array(
         *      'artNo' => [...]
         *      ),
         *  [1] = array(
         *      'artNo' => [...]
         *      )
         * )
         * - etc and not like: array('artNo'=>[...]);
         */
        if (isset($clientPaymentSpec['artNo'])) {
            $newClientSpec = array();
            $newClientSpec[] = $clientPaymentSpec;
        } else {
            $newClientSpec = $clientPaymentSpec;
        }
        return $newClientSpec;
    }

    /**
     * Finalize payment by payment ID. Finalizes an order based on the order content.
     *
     * clientPaymentSpec (not required) should contain array[] => ('artNo' => 'articleNumber', 'quantity' => numberOfArticles). Example:
     * array(
     *  0=>array(
     *      'artNo' => 'art999',
     *      'quantity' => '1'
     *    ),
     *  1=>array(
     *      'artNo' => 'art333',
     *      'quantity' => '2'
     * )
     *
     * @param string $paymentId
     * @param array $clientPaymentSpec (Optional) paymentspec if only specified lines are being finalized
     * @param array $finalizeParams
     * @param bool $quantityMatch (Optional) Match quantity. If false, quantity will be ignored during finalization and all client specified paymentspecs will match
     * @param bool $useSpecifiedQuantity If set to true, the quantity set clientside will be used rather than the exact quantity from the spec in getPayment (This requires that $quantityMatch is set to false)
     * @return bool True if successful
     * @throws Exception
     */
    public function finalizePayment($paymentId = "", $clientPaymentSpec = array(), $finalizeParams = array(), $quantityMatch = true, $useSpecifiedQuantity = false)
    {
        $clientPaymentSpec = $this->handleClientPaymentSpec($clientPaymentSpec);
        $finalizeResult = false;
        if (null === $paymentId) { throw new \Exception("Payment ID must be ID"); }
        $paymentArray = $this->getPayment($paymentId);
        $finalizePaymentContainer = $this->renderPaymentSpecContainer($paymentId, ResursAfterShopRenderTypes::FINALIZE, $paymentArray, $clientPaymentSpec, $finalizeParams, $quantityMatch);
        if (isset($paymentArray->id)) {
            try {
                $this->afterShopFlowService->finalizePayment($finalizePaymentContainer);
                $finalizeResult = true;
            } catch (\Exception $e) {
                throw new \ResursException($e->getMessage(), 500, __FUNCTION__);
            }
        }
        return $finalizeResult;
    }

    /**
     * Credit a payment
     *
     * If you need fully automated credits (where payment specs are sorted automatically) you should use cancelPayment
     *
     * @param string $paymentId
     * @param array $clientPaymentSpec
     * @param array $creditParams
     * @param bool $quantityMatch
     * @param bool $useSpecifiedQuantity
     * @return bool
     * @throws Exception
     * @throws ResursException
     *
     */
    public function creditPayment($paymentId = "", $clientPaymentSpec = array(), $creditParams = array(), $quantityMatch = true, $useSpecifiedQuantity = false)
    {
        $clientPaymentSpec = $this->handleClientPaymentSpec($clientPaymentSpec);
        $creditResult = false;
        if (null === $paymentId) { throw new \Exception("Payment ID must be ID"); }
        $paymentArray = $this->getPayment($paymentId);
        $creditPaymentContainer = $this->renderPaymentSpecContainer($paymentId, ResursAfterShopRenderTypes::CREDIT, $paymentArray, $clientPaymentSpec, $creditParams, $quantityMatch);
        if (isset($paymentArray->id)) {
            try {
                $this->afterShopFlowService->creditPayment($creditPaymentContainer);
                $creditResult = true;
            } catch (\Exception $e) {
                throw new \ResursException($e->getMessage());
            }
        }
        return $creditResult;
    }

    /**
     * Annul a payment
     *
     * If you need fully automated annullments (where payment specs are sorted automatically) you should use cancelPayment
     *
     * @param string $paymentId
     * @param array $clientPaymentSpec
     * @param array $annulParams
     * @param bool $quantityMatch
     * @param bool $useSpecifiedQuantity If set to true, the quantity set clientside will be used rather than the exact quantity from the spec in getPayment (This requires that $quantityMatch is set to false)
     * @return bool
     * @throws Exception
     * @throws ResursException
     */
    public function annulPayment($paymentId = "", $clientPaymentSpec = array(), $annulParams = array(), $quantityMatch = true, $useSpecifiedQuantity = false)
    {
        $clientPaymentSpec = $this->handleClientPaymentSpec($clientPaymentSpec);
        $annulResult = false;
        if (null === $paymentId) { throw new \Exception("Payment ID must be ID"); }
        $paymentArray = $this->getPayment($paymentId);
        $annulPaymentContainer = $this->renderPaymentSpecContainer($paymentId, ResursAfterShopRenderTypes::ANNUL, $paymentArray, $clientPaymentSpec, $annulParams, $quantityMatch);
        if (isset($paymentArray->id)) {
            try {
                $this->afterShopFlowService->annulPayment($annulPaymentContainer);
                $annulResult = true;
            } catch (\Exception $e) {
                throw new \ResursException($e->getMessage());
            }
        }
        return $annulResult;
    }

    private function stripPaymentSpec($specLines = array()) {
        $newSpec = array();
        if (is_array($specLines) && count($specLines)) {
            foreach ($specLines as $specRow) {
                if (isset($specRow->artNo) && !empty($specRow->artNo)) {
                    $newSpec[] = array(
                        'artNo' => $specRow->artNo,
                        'quantity' => $specRow->quantity
                    );
                }
            }
        }
        return $newSpec;
    }

    /**
     * Automatically cancel (credit or annul) a payment with "best practice".
     *
     * Since the rendered container only returns payment data if the rows are available for the current requested action, this function will try to both credit a payment and annul it depending on the status.
     *
     * @param string $paymentId
     * @param array $clientPaymentSpec
     * @param array $cancelParams
     * @param bool $quantityMatch
     * @param bool $useSpecifiedQuantity If set to true, the quantity set clientside will be used rather than the exact quantity from the spec in getPayment (This requires that $quantityMatch is set to false)
     * @return bool
     * @throws ResursException
     */
    public function cancelPayment($paymentId = "", $clientPaymentSpec = array(), $cancelParams = array(), $quantityMatch = true, $useSpecifiedQuantity = false)
    {
        $clientPaymentSpec = $this->handleClientPaymentSpec($clientPaymentSpec);
        $creditStateSuccess = false;
        $annulStateSuccess = false;
        $cancelStateSuccess = false;
        $lastErrorMessage = "";

        $cancelPaymentArray = $this->getPayment($paymentId);
        $creditSpecLines = array();
        $annulSpecLines = array();

        /*
         * If no clientPaymentSpec are defined, we should consider this a full cancellation. In that case, we'll sort the full payment spec so we'll pick up rows
         * that should be credited separately and vice versa for annullments. If the clientPaymentSpec are defined, the $cancelPaymentArray will be used as usual.
         */
        if (is_array($clientPaymentSpec) && !count($clientPaymentSpec)) {
            try {
                $creditSpecLines = $this->stripPaymentSpec($this->renderSpecLine($creditSpecLines, ResursAfterShopRenderTypes::CREDIT, $cancelParams));
            } catch (Exception $ignoreCredit) {
                $creditSpecLines = array();
            }
            try {
                $annulSpecLines = $this->stripPaymentSpec($this->renderSpecLine($annulSpecLines, ResursAfterShopRenderTypes::ANNUL, $cancelParams));
            } catch (Exception $ignoreAnnul) {
                $annulSpecLines = array();
            }
        }

        /* First, try to credit the requested order, if debited rows are found */
        try {
            if (!count($creditSpecLines)) {
                $creditPaymentContainer = $this->renderPaymentSpecContainer($paymentId, ResursAfterShopRenderTypes::CREDIT, $cancelPaymentArray, $clientPaymentSpec, $cancelParams, $quantityMatch, $useSpecifiedQuantity);
            } else {
                $creditPaymentContainer = $this->renderPaymentSpecContainer($paymentId, ResursAfterShopRenderTypes::CREDIT, $creditSpecLines, $clientPaymentSpec, $cancelParams, $quantityMatch, $useSpecifiedQuantity);
            }
            $this->afterShopFlowService->creditPayment($creditPaymentContainer);
            $creditStateSuccess = true;
        } catch (Exception $e) {
            $creditStateSuccess = false;
            $lastErrorMessage = $e->getMessage();
        }

        /* Second, try to annul the rest of the order, if authorized (not debited) rows are found */
        try {
            if (!count($creditSpecLines)) {
                $annulPaymentContainer = $this->renderPaymentSpecContainer($paymentId, ResursAfterShopRenderTypes::ANNUL, $cancelPaymentArray, $clientPaymentSpec, $cancelParams, $quantityMatch, $useSpecifiedQuantity);
            } else {
                $annulPaymentContainer = $this->renderPaymentSpecContainer($paymentId, ResursAfterShopRenderTypes::ANNUL, $annulSpecLines, $clientPaymentSpec, $cancelParams, $quantityMatch, $useSpecifiedQuantity);
            }
            if (is_array($annulPaymentContainer) && count($annulPaymentContainer)) {
                $this->afterShopFlowService->annulPayment($annulPaymentContainer);
                $annulStateSuccess = true;
            }
        } catch (Exception $e) {
            $annulStateSuccess = false;
            $lastErrorMessage = $e->getMessage();
        }

        /* Check if one of the above statuses is true and set the cancel as successful. If none of them are true, the cancellation has failed completely. */
        if ($creditStateSuccess) {$cancelStateSuccess=true;}
        if ($annulStateSuccess) {$cancelStateSuccess=true;}

        /* On total fail, throw the last error */
        if (!$cancelStateSuccess) { throw new \ResursException($lastErrorMessage); }

        return $cancelStateSuccess;
    }


    /**
     * Decides if a payment can be credited
     * @param array $paymentArray
     * @return bool
     */
    private function canCredit($paymentArray = array()) {
        if (isset($paymentArray->status)) {
            if (in_array("CREDITABLE", $paymentArray->status)) { return true; }
        }
        return false;
    }

    /**
     * Decides if a payment can be debited
     * @param array $paymentArray
     * @return bool
     */
    private function canDebit($paymentArray = array()) {
        if (isset($paymentArray->status)) {
            if (in_array("DEBITABLE", $paymentArray->status)) { return true; }
        }
        return false;
    }

    /**
     * Render a full paymentSpec for AfterShop
     *
     * Depending on the rendering type the specrows may differ, but the primary goal is to only handle rows from a payment spec that is actual for the moment.
     *
     * Examples:
     *   - Request: Finalize. The payment has credited and annulled rows. Credited, annulled and formerly debited rows are ignored.
     *   - Request: Annul. The payment is partially debited. Debited and former annulled rows are ignored.
     *   - Request: Annul. The payment is partially credited. Credited and debited rows is ignored.
     *   - Request: Credit. The payment is partially annulled. Only debited rows will be chosen.
     *
     * @param $paymentId
     * @param $renderType
     * @param array $paymentArray The actual full speclineArray to handle
     * @param array $clientPaymentSpec (Optional) paymentspec if only specified lines are being finalized
     * @param array $renderParams Finalize parameters received from the server-application
     * @param bool $quantityMatch (Optional, Passthrough) Match quantity. If false, quantity will be ignored during finalization and all client specified paymentspecs will match
     * @param bool $useSpecifiedQuantity If set to true, the quantity set clientside will be used rather than the exact quantity from the spec in getPayment (This requires that $quantityMatch is set to false)
     * @return array
     * @throws ResursException
     */
    private function renderPaymentSpecContainer($paymentId, $renderType, $paymentArray = array(), $clientPaymentSpec = array(), $renderParams = array(), $quantityMatch = true, $useSpecifiedQuantity = false)
    {
        $paymentSpecLine = $this->renderSpecLine($paymentArray, $renderType, $renderParams);
        $totalAmount = 0;
        $totalVatAmount = 0;
        $newSpecLine = array();
        $paymentContainerContent = array();
        $paymentContainer = array();

        if (!count($paymentSpecLine)) {
            /* Should occur when you for example try to annul an order that is already debited or credited */
            throw new \ResursException("No articles was added during the renderingprocess (RenderType $renderType)", 500, __FUNCTION__);
        }

        if (is_array($paymentSpecLine) && count($paymentSpecLine)) {
            /* Calculate totalAmount to finalize */

            foreach ($paymentSpecLine as $row) {
                if (is_array($clientPaymentSpec) && count($clientPaymentSpec)) {
                    /**
                     * Partial payments control
                     * If the current article is missing in the requested $clientPaymentSpec, it should be included into the summary and therefore not be calculated.
                     */
                    if ($this->inSpec($clientPaymentSpec, $row->artNo, $row->quantity, $quantityMatch, $useSpecifiedQuantity)) {
                        /**
                         * Partial specrow quantity modifier - Beta
                         * Activated by setting $useSpecifiedQuantity to true
                         * Warning: Do not use this special feature unless you know what you are doing
                         *
                         * Used when own quantity values are set instead of the one set in the received payment spec. This is actually being used
                         * when we are for example are trying to annul parts of a specrow instead of the full row.
                         */
                        if ($useSpecifiedQuantity) {
                            foreach ($clientPaymentSpec as $item) {
                                if (isset($item['artNo']) && !empty($item['artNo']) && $item['artNo'] == $row->artNo && isset($item['quantity']) && intval($item['quantity']) > 0) {
                                    /* Recalculate the new totalVatAmount */
                                    $newTotalVatAmount = ($row->unitAmountWithoutVat * ($row->vatPct/100)) * $item['quantity'];
                                    /* Recalculate the new totalAmount */
                                    $newTotalAmount = ($row->unitAmountWithoutVat * $item['quantity']) + $newTotalVatAmount;
                                    /* Change the new values in the current row */
                                    $row->quantity = $item['quantity'];
                                    $row->totalVatAmount = $newTotalVatAmount;
                                    $row->totalAmount = $newTotalAmount;
                                    break;
                                }
                            }
                            /* Put the manipulated row into the specline*/
                            $newSpecLine[] = $this->objectsIntoArray($row);
                            $totalAmount += $row->totalAmount;
                            $totalVatAmount += $row->totalVatAmount;
                        } else {
                            $newSpecLine[] = $this->objectsIntoArray($row);
                            $totalAmount += $row->totalAmount;
                            $totalVatAmount += $row->totalVatAmount;
                        }
                    }
                } else {
                    $newSpecLine[] = $this->objectsIntoArray($row);
                    $totalAmount += $row->totalAmount;
                    $totalVatAmount += $row->totalVatAmount;
                }
            }
            $paymentSpec = array(
                'specLines' => $newSpecLine,
                'totalAmount' => $totalAmount,
                'totalVatAmount' => $totalVatAmount
            );
            $paymentContainerContent = array(
                'paymentId' => $paymentId,
                'partPaymentSpec' => $paymentSpec,
                'orderDate' => date('Y-m-d', time()),
                'invoiceDate' => date('Y-m-d', time()),
            );

            /**
             * Note: If the paymentspec are rendered without speclines, this may be caused by for example a finalization where the speclines already are finalized.
             */
            if (!count($newSpecLine)) {
                throw new \ResursException("No articles has been added to the paymentspec due to mismatching clientPaymentSpec", 500, __FUNCTION__);
            }

            /* If no invoice id is set, we are presuming that Resurs Bank Invoice numbering sequence is the right one - Enforcing an invoice number if not exists */
            if (!isset($renderParams['invoiceId'])) {
                $renderParams['invoiceId'] = $this->getNextInvoiceNumber();
            }
            $renderParams['createdBy'] = $this->clientName . "_" . $this->versionToDecimals();
            $paymentContainer = array_merge($paymentContainerContent, $renderParams);
            return $paymentContainer;

            /*
             * Other data fields that can be sent from client (see below).
             * Please note the orderId, this may be important for the order.
             */

            /*
                $renderParams['ourReference'] = '';
                $renderParams['yourReference'] = '';
                $renderParams['preferredTransactionId'] = '';
                $renderParams['orderId'] = '';
            */
        }
    }

    /**
     * PaymentSpecCleaner
     * @param array $currentArray The current speclineArray
     * @param array $cleanWith The array with the speclines that should be removed from currentArray
     * @param bool $includeId Include matching against id (meaning both id and artNo is trying to match to make the search safer)
     * @return array New array
     */
    private function removeFromArray($currentArray = array(), $cleanWith = array(), $includeId = false)
    {
        $cleanedArray = array();
        foreach ($currentArray as $currentObject) {
            if (is_array($cleanWith)) {
                $foundObject = false;
                foreach ($cleanWith as $currentCleanObject) {
                    if (is_object($currentCleanObject)) {
                        if (!empty($currentObject->artNo)) {
                            /**
                             * Search with both id and artNo - This may fail so we are normally ignoring the id from a specline.
                             * If you are absolutely sure that your speclines are fully matching each other, you may enabled id-searching.
                             */
                            if (!$includeId) {
                                if ($currentObject->artNo == $currentCleanObject->artNo) {
                                    $foundObject = true;
                                    break;
                                }
                            } else {
                                if ($currentObject->id == $currentCleanObject->id && $currentObject->artNo == $currentCleanObject->artNo) {
                                    $foundObject = true;
                                    break;
                                }
                            }
                        }
                    }
                }
                if (!$foundObject) {
                    $cleanedArray[] = $currentObject;
                }
            } else {
                $cleanedArray[] = $currentObject;
            }
        }
        return $cleanedArray;
    }

    /**
     * Render a specLine-array depending on the needs (This function is explicitly used for the AfterShopFlow together with Finalize/Annul/Credit
     * @param array $paymentArray
     * @param int $renderType
     * @param array $finalizeParams
     * @return array
     * @throws Exception
     */
    private function renderSpecLine($paymentArray = array(), $renderType = ResursAfterShopRenderTypes::NONE, $finalizeParams = array())
    {
        $returnSpecObject = array();
        if ($renderType == ResursAfterShopRenderTypes::NONE) {
            throw new \ResursException("Can not render specLines without RenderType");
        }
        /* Preparation of the returning array*/
        $specLines = array();

        /* Preparation */
        $currentSpecs = array(
            'AUTHORIZE' => array(),
            'DEBIT' => array(),
            'CREDIT' => array(),
            'ANNUL' => array()
        );

        /*
         * This method summarizes all specrows in a proper objectarray, depending on the paymentdiff type.
         */
        if (isset($paymentArray->paymentDiffs->paymentSpec->specLines)) {
            $specType = $paymentArray->paymentDiffs->type;
            $specLineArray = $paymentArray->paymentDiffs->paymentSpec->specLines;
            if (is_array($specLineArray)) {
                foreach ($specLineArray as $subObjects) { array_push($currentSpecs[$specType], $subObjects); }
            } else {
                array_push($currentSpecs[$specType], $specLineArray);
            }
        } else {
            // If the paymentarray does not have speclines, something else has been done with this payment
            if (isset($paymentArray->paymentDiffs)) {
                foreach ($paymentArray->paymentDiffs as $specsObject) {
                    /* Catch up the payment and split it up */
                    $specType = $specsObject->type;
                    /* Making sure that everything is handled equally */
                    $specLineArray = $specsObject->paymentSpec->specLines;
                    if (isset($specsObject->paymentSpec->specLines)) {
                        if (is_array($specLineArray)) {
                            foreach ($specLineArray as $subObjects) { array_push($currentSpecs[$specType], $subObjects); }
                        } else {
                            array_push($currentSpecs[$specType], $specLineArray);
                        }
                    }
                }
            }
        }

        /*
        if ($renderType == ResursAfterShopRenderTypes::FINALIZE) { $returnSpecObject = $this->removeFromArray($currentSpecs['AUTHORIZE'], array_merge($currentSpecs['DEBIT'], $currentSpecs['ANNUL'], $currentSpecs['CREDIT'])); }
        if ($renderType == ResursAfterShopRenderTypes::CREDIT) { $returnSpecObject = $this->removeFromArray($currentSpecs['DEBIT'], array_merge($currentSpecs['CREDIT'], $currentSpecs['ANNUL'])); }
        if ($renderType == ResursAfterShopRenderTypes::ANNUL) { $returnSpecObject = $this->removeFromArray($currentSpecs['AUTHORIZE'], array_merge($currentSpecs['DEBIT'], $currentSpecs['CREDIT'])); }
        */

        /* Finalization is being done on all authorized rows that is not already finalized (debit), annulled or crediter*/
        if ($renderType == ResursAfterShopRenderTypes::FINALIZE) { $returnSpecObject = $this->removeFromArray($currentSpecs['AUTHORIZE'], array_merge($currentSpecs['DEBIT'], $currentSpecs['ANNUL'], $currentSpecs['CREDIT'])); }
        /* Credit is being done on all authorized rows that is not annuled or already credited */
        if ($renderType == ResursAfterShopRenderTypes::CREDIT) { $returnSpecObject = $this->removeFromArray($currentSpecs['DEBIT'], array_merge($currentSpecs['ANNUL'], $currentSpecs['CREDIT'])); }
        /* Annul is being done on all authorized rows that is not already annulled, debited or credited */
        if ($renderType == ResursAfterShopRenderTypes::ANNUL) { $returnSpecObject = $this->removeFromArray($currentSpecs['AUTHORIZE'], array_merge($currentSpecs['DEBIT'], $currentSpecs['ANNUL'], $currentSpecs['CREDIT'])); }
        return $returnSpecObject;
    }

    public static function __callStatic($name, $arguments)
    {
        // TODO: Implement __callStatic() method.
    }
}

/**
 * Class ResursCallbackTypes: Callbacks that can be registered with Resurs Bank.
 */
abstract class ResursCallbackTypes {

    /**
     * Resurs Callback Types. Callback types available from Resurs Ecommerce.
     *
     * @subpackage ResursCallbackTypes
     */

    /**
     * Callback UNFREEZE
     *
     * Informs when an payment is unfrozen after manual fraud screening. This means that the payment may be debited (captured) and the goods can be delivered.
     * @link https://test.resurs.com/docs/display/ecom/UNFREEZE
     */
    const UNFREEZE = 1;
    /**
     * Callback ANNULMENT
     *
     * Will be sent once a payment is fully annulled at Resurs Bank, for example when manual fraud screening implies fraudulent usage. Annulling part of the payment will not trigger this event.
     * If the representative is not listening to this callback orders might be orphaned (i e without connected payment) and products bound to these orders never released.
     * @link https://test.resurs.com/docs/display/ecom/ANNULMENT
     */
    const ANNULMENT = 2;
    /**
     * Callback AUTOMATIC_FRAUD_CONTROL
     *
     * Will be sent once a payment is fully annulled at Resurs Bank, for example when manual fraud screening implies fraudulent usage. Annulling part of the payment will not trigger this event.
     * @link https://test.resurs.com/docs/display/ecom/AUTOMATIC_FRAUD_CONTROL
     */
    const AUTOMATIC_FRAUD_CONTROL = 3;
    /**
     * Callback FINALIZATION
     *
     * Once a payment is finalized automatically at Resurs Bank, for this will trigger this event, when the parameter finalizeIfBooked parmeter is set to true in paymentData. This callback will only be called if you are implementing the paymentData method with finilizedIfBooked parameter set to true, in the Simplified Shop Flow Service.
     * @link https://test.resurs.com/docs/display/ecom/FINALIZATION
     */
    const FINALIZATION = 4;
    /**
     * Callback TEST
     *
     * To test the callback mechanism. Can be used in integration testing to assure that communication works. A call is made to DeveloperService (triggerTestEvent) and Resurs Bank immediately does a callback. Note that TEST callback must be registered in the same way as all the other callbacks before it can be used.
     * @link https://test.resurs.com/docs/display/ecom/TEST
     */
    const TEST = 5;
    /**
     * Callback UPDATE
     *
     * Will be sent when a payment is updated. Resurs Bank will do a HTTP/POST call with parameter paymentId and the xml for paymentDiff to the registered URL.
     * @link https://test.resurs.com/docs/display/ecom/UPDATE
     */
    const UPDATE = 6;
}
abstract class ResursAfterShopRenderTypes {
    const NONE = 0;
    const FINALIZE = 1;
    const CREDIT = 2;
    const ANNUL = 3;
}
abstract class ResursEnvironments {
    const ENVIRONMENT_PRODUCTION = 0;
    const ENVIRONMENT_TEST = 1;

}
