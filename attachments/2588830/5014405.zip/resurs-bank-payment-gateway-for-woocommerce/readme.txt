=== Plugin Name ===
Contributors: -
Tags: WooCommerce, Resurs Bank, Payment, Payment gateway
Requires at least: 3.0.1
Tested up to: 4.4.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Resurs Bank Payment Gateway for WooCommerce


== Description ==

Resurs Bank payment gateway for WooCommerce.
Tested with WooCommerce up to version 2.5.2
Requires PHP 5.4 or later.

[Project URL](https://test.resurs.com/docs/display/ecom/WooCommerce)
[Plugin URL](https://wordpress.org/plugins/resurs-bank-payment-gateway-for-woocommerce/)


== Installation ==

1. Upload the plugin archive to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure the plugin via admin control panel

(Or install and activate the plugin through the WordPress plugin installer)


== Frequently Asked Questions ==



== Screenshots ==



== Changelog ==

= 1.0.0 =

* Issue 61071 Add: Implementation Extended AfterShopFlow (Partial handlers)
* Issue 60842 Add: Aftershop WordPress using EcomBridge AfterShop
* Issue 60915 Add: Aftershop-WooCommerce: Partial Annullments
* Issue 60914 Add: Aftershop-WooCommerce: Partial Crediting
* Issue 61231 Add: Checkbox for activating Extended AftershopFlow (Related to 61071)
* Issue 59612 Fix: Payment method name are sent as specline when payment fees are included
* Issue 61315 Fix: Frozen orders are not properly annulled from Woocommerce admin
* Issue 61316 Fix: Partial annulled orders are not entirely annuled at Resurs Ecommerce
* Issue 61398 Fix: Choosing customer type will update the information in the "get address"-field
* Issue 61402 Fix: When choosing customer type "Company" the address request are updating wrong fields
* Issue 61401 Behaviour changed: Locking the field "Company name" when "private person" (NATURAL) are selected
* Issue 61691 Fix: add_fee() does not add payment fees in order confirmations but payment admin see the specrows for newer versions of woocommerce
* Issue 61486 Prepared plugin for wordpress repo. Version 0.2 has been officially released as a plugin at wordpress.org (160204)

= 0.4 =

* Issue 59482: Add: Helper for billing address added, to make it easier to get the correct address depending on the customer type
* Issue 59295: Fix: Making sure that the correct payment method are used depending on customer type
* Issue 60161: Fix: PHP 5.3 is not supported, but no notice are shown - from 0.3 the admin gui has a warning displayed if current version is lower than 5.4.0


== Upgrade Notice ==

= 0.2 =

Last version developed by Web2Life.
