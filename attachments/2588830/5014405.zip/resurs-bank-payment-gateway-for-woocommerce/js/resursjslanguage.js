var jsResursLanguage = {
    "se":{
        "getAddressEnterGovernmentId":"Ange personnummer",
        "getAddressEnterCompany":"Ange organisationsnummer",
        "labelGovernmentId":"Personnummer",
        "labelCompanyId":"Organisationsnummer"
    },
    "en":{
        "getAddressEnterGovernmentId":"Enter social security number",
        "getAddressEnterCompany":"Enter corporate government identity",
        "labelGovernmentId":"Personnummer",
        "labelCompanyId":"Organisationsnummer"
    },
    "dk":{
        "getAddressEnterGovernmentId":"Ange personnummer",
        "getAddressEnterCompany":"Ange organisationsnummer",
        "labelGovernmentId":"Personnummer",
        "labelCompanyId":"Organisationsnummer"
    },
    "no":{
        "getAddressEnterGovernmentId":"Ange personnummer",
        "getAddressEnterCompany":"Ange organisationsnummer",
        "labelGovernmentId":"Personnummer",
        "labelCompanyId":"Organisationsnummer"
    },
    "fi":{
        "getAddressEnterGovernmentId":"Ange personnummer",
        "getAddressEnterCompany":"Ange organisationsnummer",
        "labelGovernmentId":"Personnummer",
        "labelCompanyId":"Organisationsnummer"
    }
}
