/*jQuery.noConflict();*/
window.onload = function(){
	jQuery(document).ready(function( $ ) {

        if (jQuery('#ssnCustomerType').length && jQuery('#ssnCustomerType:checked').length > 0) {
            getMethodType(jQuery('#ssnCustomerType:checked').val());
        }

        jQuery('input[id*="payment_method_"]').each(function () {
            if (typeof jQuery().live === "function") {
                jQuery('#' + this.id).live("click", function() {
                    methodChangers(this);
                });
            } else {
                jQuery('#' + this.id).on("click", function() {
                    methodChangers(this);
                });
            }
        });

		woocommerce_resurs_bank = {

            init: function () {
                var that = this;
                that.register_payment_update();
                that.register_ssn_address_fetch();
                that.shipping_address = $('.shipping_address');
                that.sign_notice = $('<p></p>').addClass('sign_notice').text('Ändring av leveransadress kräver e-signering.');

                if ($('.resurs-bank-payment-method').length !== 0) {
                    that.shipping_address.prepend(that.sign_notice);
                } else {
                    if ($(that.shipping_address).find(that.sign_notice).length) {
                        this.sign_notice.remove();
                    }
                }
                $(document).ajaxStop(function () {
                    that.register_payment_update();
                    if ($('.resurs-bank-payment-method').length !== 0) {
                        $('#applicant-government-id').val($('#ssn_field').val());
                        $('#applicant-full-name').val($("#billing_first_name").val() + ' ' + $("#billing_last_name").val());
                        //$('#applicant-telephone-number');
                        $('#applicant-mobile-number').val($("#billing_phone").val());
                        $('#applicant-telephone-number').val($("#billing_phone").val());
                        $('#applicant-email-address').val($("#billing_email").val());
                        that.shipping_address.prepend(that.sign_notice);
                    } else {
                        if ($(that.shipping_address).find(that.sign_notice).length) {
                            that.sign_notice.remove();
                        }
                    }
                });

                $('#billing_email').on('keyup', function () {
                    $('#applicant-email-address').val($(this).val());
                });

                $('#billing_phone').on('keyup', function () {
                    $('#applicant-mobile-number').val($(this).val());
                });

                $('#ssn_field').on('keyup', function () {
                    $('#applicant-government-id').val($(this).val());
                });
            },

            register_payment_update: function () {
                var checked = $('#order_review input[name=payment_method]:checked');
                var parent = $(checked).parent();
                var that = this;
                if (parent.has('.resurs-bank-payment-method').length !== 0) {
                    var methodId = parent.find('.resurs-bank-payment-method').val();
                }

                $('input[name="payment_method"]').on('change', function () {
                    var parent = $(this).parent();
                    var temp = $('.resurs-bank-payment-method');

                    if (parent.has('.resurs-bank-payment-method').length !== 0) {
                        var methodId = parent.find('.resurs-bank-payment-method').val();
                    }

                    $('body').trigger('update_checkout');
                });
            },

            // DEPRECATED
            start_payment_session: function (methodId, parent) {
                var result;
                $.ajax({
                    type: 'GET',
                    url: ajax_object.ajax_url,
                    data: {
                        action: 'start_payment_session_ajax',
                        methodId: methodId,
                    }
                }).done(function (data) {
                    data = $.parseJSON(data);
                    result = data;
                    var div = parent.find('div');
                    var origHtml = div.html();
                    div.html('');
                    var containerDiv = $("<div></div>");
                    for (var i = 0; i < data.limitApplicationFormAsObjectGraph.formElement.length; i++) {
                        var temp = data.limitApplicationFormAsObjectGraph.formElement[i];
                        var element;

                        if (temp.type === 'heading') {
                            /*switch(temp.level) {
                             case 1:
                             element = $("<h1></h1>");
                             break;
                             default:
                             element = $("<h1></h1>");
                             break;
                             }

                             element.text( temp.label );*/
                        } else {
                            var tempDiv = $('<div></div>', {
                                id: temp.name.replace(/-/g, '') + '-div',
                            });

                            var tempLabel = $('<label></label>', {
                                'for': temp.name.replace(/-/g, ''),
                                'text': temp.label + ( temp.mandatory ? ' *' : '' ),
                            });

                            element = $("<input>", {
                                id: temp.name.replace(/-/g, ''),
                                type: temp.type
                            });

                            if (temp.type !== 'hidden') {
                                tempDiv.append(tempLabel);
                            }
                            tempDiv.append(element);
                            containerDiv.append(tempDiv);
                        }


                        //containerDiv.append( element );
                    }
                    var reqDiv = $('<div></div>', {
                        'text': '* obligatorisk'
                    });
                    containerDiv.append(reqDiv);
                    div.append(containerDiv);
                });

                return result;
            },

            register_ssn_address_fetch: function () {
                var form = $('form.checkout');
                var ssnField = $('#ssn_field');
                var fetchAddressButton = $('#fetch_address');
                var that = this;

                ssnField.keypress(function (e) {
                    var charCode = e.keyCoe || e.which;
                    var input = ssnField.val().trim();

                    if (input.length !== 0) {
                        if (charCode === 13) {
                            fetchAddressButton.click();
                            e.preventDefault();
                            return false;
                        }
                    }
                });

                $(fetchAddressButton).click(function (e) {
                    var input = ssnField.val().trim();
                    var customerType = $(' #ssnCustomerType:checked ').val();
                    if (that.validate_ssn_address_field(input)) {
                        that.fetch_address(input, customerType);
                    }
                    e.preventDefault();
                    return false;
                });
            },

            validate_ssn_address_field: function (ssn) {
                if (ssn.trim().length === 0) {
                    return false;
                }

                return true;
            },

            fetch_address: function (ssn, customerType) {
                /* Make sure the loader url exists, or do not run this part -151202 */
                if (typeof wc_checkout_params.ajax_loader_url !== "undefined") {
                    $('form[name="checkout"]').block({
                        message: null,
                        overlayCSS: {
                            background: '#fff url(' + wc_checkout_params.ajax_loader_url + ') no-repeat center',
                            backgroundSize: '16px 16px',
                            opacity: 0.6
                        }
                    });
                }

                $.ajax({
                    type: 'GET',
                    url: ajax_object.ajax_url,
                    data: {
                        'action': 'get_address_ajax',
                        'ssn': ssn,
                        'customerType': customerType
                    }
                }).done(function (data) {
                    data = $.parseJSON(data);
                    var info = data["return"];
                    this.ssnP = $('p[class="form-row ssn form-row-wide woocommerce-validated"]');
                    this.ssnInput = this.ssnP.find('input');

                    if (typeof data.errorTypeId !== 'undefined') {
                        var form = $('form[name="checkout"]');
                        var tempSpan = $('<span></span>', {
                            'class': 'ssn-error-message',
                            'text': data.userErrorMessage
                        });
                        //"form-row form-row-first validate-required woocommerce-invalid woocommerce-invalid-required-field"

                        this.ssnP.append(tempSpan);
                        this.ssnInput.css('border-color', '#fb7f88');
                        this.ssnErrorTimeout = window.setTimeout(function () {
                            $('.ssn-error-message').fadeOut('slow', function () {
                                $(this.parent).find('input').css('border-color', '');
                                $(this).remove();
                            });
                            $('p[class="form-row ssn form-row-wide woocommerce-validated"]').find('input').css('border-color', '');
                        }, 5000);
                    } else {
                        $('.ssn-error-message').remove();
                        this.ssnInput.css('border-color', '');

                        var customerType = "";
                        if (jQuery('#ssnCustomerType').length > 0 && jQuery('input[id^="payment_method_resurs_bank"]').length > 0) {
                            var selectedType = jQuery('#ssnCustomerType:checked');
                            customerType = selectedType.val();
                            /* Put up as much as possible as default */
                            $("#billing_first_name").val(typeof info.firstName !== "undefined" ? info.firstName : "");
                            $("#billing_last_name").val(typeof info.lastName !== "undefined" ? info.lastName : "");
                            $("#billing_address_1").val(typeof info.addressRow1 !== "undefined" ? info.addressRow1 : "");
                            $("#billing_address_2").val(typeof info.addressRow1 !== "undefined" ? info.addressRow2 : "");
                            $("#billing_postcode").val(typeof info.postalCode !== "undefined" ? info.postalCode : "");
                            $("#billing_city").val(typeof info.postalArea !== "undefined" ? info.postalArea : "");

                            $("#applicant-government-id").val($('#ssn_field').val());

                            if (customerType !== "NATURAL") {
                                /* If this is a company, add available content to right location field */
                                if (typeof info.lastName === "undefined") {
                                    $("#billing_company").val(info.firstName);
                                } else {
                                    $("#billing_company").val(info.firstName + " " + info.lastName);
                                }
                            } else {
                                /* Naturals has lastnames, normally - add the rest here */
                                $("#billing_last_name").val(typeof info.lastName !== "undefined" ? info.lastName : "");
                            }
                        }

                        $('form[name="checkout"]').unblock();
                    }
                })
            },
            remove_first_checkout_button: function () {

                $('.checkout-button').each(function (index, value) {

                    var $value = $(value);

                    if (!$value.hasClass('second-checkout-button'))
                        $value.hide();
                });
            }
        };

		$( document ).ready( function( $ ) {
			woocommerce_resurs_bank.init();
		} );
	} );
}

function getResursPhrase(phraseName, countryId) {
    if (typeof jsResursLanguage[countryId.toLowerCase()] !== "undefined" && typeof jsResursLanguage[countryId.toLowerCase()][phraseName] !== "undefined") {
        return jsResursLanguage[countryId.toLowerCase()][phraseName];
    }
    return "";
}

function getMethodType(customerType) {
    var checkedPaymentMethod = null;
    var hasResursMethods = false;

    var currentResursCountry = "";
    var currentCustomerType = "";
    var enterNumberPhrase = "";
	var labelNumberPhrase = "";
    if (jQuery('#resursSelectedCountry').length > 0 && jQuery('#ssn_field').length > 0) {
        currentResursCountry = jQuery('#resursSelectedCountry').val();
        currentCustomerType = customerType.toLowerCase();
        if (currentCustomerType === "natural") {
            enterNumberPhrase = getResursPhrase("getAddressEnterGovernmentId", currentResursCountry);
			labelNumberPhrase = getResursPhrase("labelGovernmentId", currentResursCountry);
        } else {
            enterNumberPhrase = getResursPhrase("getAddressEnterCompany", currentResursCountry);
			labelNumberPhrase = getResursPhrase("labelCompanyId", currentResursCountry);
        }
        jQuery('#ssn_field').attr("placeholder", enterNumberPhrase);
		jQuery("label[for*='ssn_field']").html(labelNumberPhrase);
    }

    if (jQuery('#ssnCustomerType').length > 0 && jQuery('input[id^="payment_method_resurs_bank"]').length > 0) {

        var selectedType = jQuery('#ssnCustomerType:checked');
        if (jQuery('#billing_company').length > 0 && jQuery('#billing_company').val() !== "") {
            customerType = "legal";
        } else {
            if (selectedType.length > 0) {
                customerType = selectedType.val();
            }
        }
        jQuery('input[id^="payment_method_resurs_bank"]').each(
            function(id, obj) {
                hasResursMethods = true;
                if (jQuery('#' + obj.id).is(':checked')) {
                    checkedPaymentMethod = obj.value;
                }
            }
        );
        if (customerType != "" && hasResursMethods) {
            jQuery.ajax({
                type: 'GET',
                url: ajax_object.ajax_url,
                data: {
                    'action': 'get_address_customertype',
                    'customerType': customerType,
                    'paymentMethod': checkedPaymentMethod
                }
            }).done(function (data) {
                preSetResursMethods(customerType, data);
            });
        }
    }
}
function preSetResursMethods(customerType, returnedObjects) {
    var hideElm;
    var showElm;

    // Only invoke if there are multiple customer types
    if (customerType.toLowerCase() == "natural") {var hideCustomerType = "legal";} else {var hideCustomerType = "natural";}
    if (typeof customerType === "undefined") {return;}
    customerType = customerType.toLowerCase();

    if (jQuery('#ssnCustomerType:checked').length === 0 && (jQuery('#billing_company').length > 0 && jQuery('#billing_company').val() == "")) {
        /* The moment when we cannot predict the method of choice, we'll show both methods */
        jQuery('li[class*=payment_method_resurs]').each(function() {
            showElm = document.getElementsByClassName(this.className);
            if (showElm.length > 0) {
                for (var showElmCount = 0; showElmCount < showElm.length; showElmCount++) {
                    if (showElm[showElmCount].tagName.toLowerCase() === "li") {
                        showElm[showElmCount].style.display = "";
                    }
                }
            }
        });
    }
    else
    {
        if (typeof returnedObjects['natural'] !== "undefined" && typeof returnedObjects['legal'] !== "undefined" && typeof returnedObjects[hideCustomerType] !== "undefined") {
            for (var cType = 0; cType < returnedObjects[hideCustomerType].length; cType++) {
                hideElm = document.getElementsByClassName('payment_method_' + returnedObjects[hideCustomerType][cType]);
                if (hideElm.length > 0) {
                    for (var hideElmCount = 0; hideElmCount < hideElm.length; hideElmCount++) {
                        if (hideElm[hideElmCount].tagName.toLowerCase() === "li") {
							for (var getChild = 0; getChild < hideElm[hideElmCount].childNodes.length ; getChild ++) {
								if (typeof hideElm[hideElmCount].childNodes[getChild].type !== "undefined" && hideElm[hideElmCount].childNodes[getChild].type === "radio") {
									// Unselect this radio buttons if found, just to make sure no method are chosen in a moment like this
									hideElm[hideElmCount].childNodes[getChild].checked = false;
								}
							}
                            hideElm[hideElmCount].style.display = "none";
                        }
                    }
                }
            }
            for (var cType = 0; cType < returnedObjects[customerType].length; cType++) {
                showElm = document.getElementsByClassName('payment_method_' + returnedObjects[customerType][cType]);
                if (showElm.length > 0) {
                    for (var showElmCount = 0; showElmCount < showElm.length; showElmCount++) {
                        if (showElm[showElmCount].tagName.toLowerCase() === "li") {
                            showElm[showElmCount].style.display = "";
                        }
                    }
                }
            }
        }
    }
	if (jQuery('#billing_company').length > 0) {
		var currentCustomerType = jQuery('#ssnCustomerType:checked').val();
		if (currentCustomerType === "NATURAL") {
			jQuery('#billing_company').val("");
			jQuery('#billing_company').prop('readonly', true);
		} else {
			jQuery('#billing_company').prop('readonly', false);
		}
	}
}

function methodChangers(currentSelectionObject) {
    getMethodType(jQuery('#ssnCustomerType:checked').val());
}