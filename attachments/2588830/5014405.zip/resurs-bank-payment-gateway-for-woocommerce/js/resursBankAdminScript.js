jQuery.noConflict();
( function( $ ) {

	woocommerce_resurs_bank = {

		init: function () {
			//console.log('Hello World');
			console.log(ajax_object);
			this.countrySelect = $('#woocommerce_resurs-bank_country');
			this.taxSelect = $('#woocommerce_resurs-bank_pricePct');
			this.country = this.countrySelect.val();
			this.options = [];
			this.change(true);
			var that = this;

			$(this.countrySelect).on('change', function () {
				that.country = $(this).val();
				that.change(false);
			});

			$('#woocommerce_resurs-bank_country option:eq(' + ajax_object.resurs_bank_settings.pricePct + ')').prop('selected', true);
		},

		change: function (setDefault) {
			console.log(this.country);
			var that = this;
			$(this.taxSelect).html('');
			switch (this.country) {
				case 'SE':
					this.options = [0, 6, 12, 25];
					break;
				case 'DK':
					this.options = [0, 25];
					break;
				case 'FI':
					this.options = [0, 10, 14, 24];
					break;
				case 'NO':
					this.options = [0, 8, 15, 25];
					break;
			}
			console.log(this.options);
			for (var i = 0; i < this.options.length; i++) {
				var value = this.options[i];
				var key = this.options[i];
				var option = $('<option>', { value : key }).text(value + '%');

				if ( setDefault ) {
					if (parseInt(ajax_object.resurs_bank_settings.pricePct) === value) {
						option.prop('selected', true);
					}
				}

				$(this.taxSelect).append(option);
			}
		}
	};

	$( document ).ready( function( $ ) {
		woocommerce_resurs_bank.init();
	} );
} )( jQuery );
























