<?php

if (!class_exists("resurs_customerType", false)) 
{
class resurs_customerType
{
    const __default = 'LEGAL';
    const LEGAL = 'LEGAL';
    const NATURAL = 'NATURAL';


}

}
