<?php

if (!class_exists("resurs_finalizePaymentResponse", false)) 
{
class resurs_finalizePaymentResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
