<?php

if (!class_exists("resurs_annulPaymentResponse", false)) 
{
class resurs_annulPaymentResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
