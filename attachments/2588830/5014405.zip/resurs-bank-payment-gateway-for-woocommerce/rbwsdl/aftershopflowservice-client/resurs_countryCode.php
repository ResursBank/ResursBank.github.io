<?php

if (!class_exists("resurs_countryCode", false)) 
{
class resurs_countryCode
{
    const __default = 'SE';
    const SE = 'SE';
    const NO = 'NO';
    const DK = 'DK';
    const FI = 'FI';


}

}
