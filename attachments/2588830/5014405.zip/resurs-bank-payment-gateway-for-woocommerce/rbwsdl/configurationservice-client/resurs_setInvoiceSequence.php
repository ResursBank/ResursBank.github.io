<?php

if (!class_exists("resurs_setInvoiceSequence", false)) 
{
class resurs_setInvoiceSequence
{

    /**
     * @var int $nextInvoiceNumber
     * @access public
     */
    public $nextInvoiceNumber = null;

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
