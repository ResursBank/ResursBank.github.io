<?php

if (!class_exists("resurs_changePasswordResponse", false)) 
{
class resurs_changePasswordResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
