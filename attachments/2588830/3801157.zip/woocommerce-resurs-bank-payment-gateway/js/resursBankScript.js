/*jQuery.noConflict();*/
window.onload = function(){
	jQuery(document).ready(function( $ ) {

		woocommerce_resurs_bank = {

			init: function () {
				var that = this;
				that.register_payment_update();
				that.register_ssn_address_fetch();
				that.shipping_address = $('.shipping_address');
				that.sign_notice = $('<p></p>').addClass('sign_notice').text('Ändring av leveransadress kräver e-signering.');
				
				if ($('.resurs-bank-payment-method').length !== 0) {
					that.shipping_address.prepend(that.sign_notice);
				} else {
					if ($(that.shipping_address).find(that.sign_notice).length) {
						this.sign_notice.remove();
					}
				}
				$(document).ajaxStop(function () {
					that.register_payment_update();
					if ( $('.resurs-bank-payment-method').length !== 0 ) {
						$('#applicant-government-id').val($('#ssn_field').val());
						$('#applicant-full-name').val($("#billing_first_name").val() + ' ' + $("#billing_last_name").val());
						$('#applicant-telephone-number');
						$('#applicant-mobile-number').val($("#billing_phone").val());
						$('#applicant-email-address').val($("#billing_email").val());
						that.shipping_address.prepend(that.sign_notice);
					} else {
						if ($(that.shipping_address).find(that.sign_notice).length) {
							that.sign_notice.remove();
						}
					}
				});

				$('#billing_email').on('keyup', function () {
					$('#applicant-email-address').val($(this).val());
				});

				$('#billing_phone').on('keyup', function () {
					$('#applicant-mobile-number').val($(this).val());
				});

				$('#ssn_field').on('keyup', function () {
					$('#applicant-government-id').val($(this).val());
				});
			},

			register_payment_update: function () {
				var checked = $( '#order_review input[name=payment_method]:checked' );
				var parent = $( checked ).parent();
				var that = this;
				if ( parent.has('.resurs-bank-payment-method').length !== 0) {
					var methodId = parent.find('.resurs-bank-payment-method').val();
				}

				$( 'input[name="payment_method"]' ).on( 'change', function () {
					var parent = $( this ).parent();
					var temp = $('.resurs-bank-payment-method');

					if ( parent.has( '.resurs-bank-payment-method' ).length !== 0 ) {
						var methodId = parent.find( '.resurs-bank-payment-method' ).val();
					}

					$('body').trigger('update_checkout');
				});
			},

			// DEPRECATED
			start_payment_session: function ( methodId, parent ) {
				var result;
				$.ajax({
					type: 'GET',
					url: ajax_object.ajax_url,
					data: {
						action: 'start_payment_session_ajax',
						methodId: methodId,
					}
				}).done(function (data) {
					data = $.parseJSON(data);
					result = data;
					var div = parent.find('div');
					var origHtml = div.html();
					div.html('');
					var containerDiv = $("<div></div>");
					for (var i = 0; i < data.limitApplicationFormAsObjectGraph.formElement.length; i++) {
						var temp = data.limitApplicationFormAsObjectGraph.formElement[i];
						var element;

						if (temp.type === 'heading') {
							/*switch(temp.level) {
								case 1:
									element = $("<h1></h1>");
									break;
								default:
									element = $("<h1></h1>");
									break;
							}

							element.text( temp.label );*/
						} else {
							var tempDiv = $('<div></div>', {
								id: temp.name.replace(/-/g, '') + '-div',
							});

							var tempLabel = $('<label></label>', {
								'for': temp.name.replace(/-/g, ''),
								'text': temp.label + ( temp.mandatory ? ' *' : '' ),
							});

							element = $("<input>", {
								id: temp.name.replace(/-/g, ''),
								type: temp.type
							});

							if (temp.type !== 'hidden') {
								tempDiv.append(tempLabel);
							}
							tempDiv.append(element);
							containerDiv.append(tempDiv);
						}



						//containerDiv.append( element );
					}
					var reqDiv = $('<div></div>', {
						'text': '* obligatorisk'
					});
					containerDiv.append(reqDiv);
					div.append( containerDiv );
				});

				return result;
			},

			register_ssn_address_fetch: function () {
				var form = $( 'form.checkout' );
				var ssnField = $( '#ssn_field' );
				var fetchAddressButton = $( '#fetch_address' );
				var that = this;

				ssnField.keypress(function ( e ) {
					var charCode = e.keyCoe || e.which;
					var input = ssnField.val().trim();

					if ( input.length !== 0 ) {
						if ( charCode === 13 ) {
							fetchAddressButton.click();
							e.preventDefault();
							return false;
						}
					}
				});

				$(fetchAddressButton).click(function ( e ) {
					var input = ssnField.val().trim();

					if ( that.validate_ssn_address_field( input ) ) {
						that.fetch_address( input );
					}
					e.preventDefault();
					return false;
				});
			},

			validate_ssn_address_field: function ( ssn ) {
				if ( ssn.trim().length === 0 ) {
					return false;
				}

				return true;
			},

			fetch_address: function ( ssn ) {
				$('form[name="checkout"]').block({
					message: null,
					overlayCSS: {
						background: '#fff url(' + wc_checkout_params.ajax_loader_url + ') no-repeat center',
						backgroundSize: '16px 16px',
						opacity: 0.6
					}
				});
				$.ajax({
					type: 'GET',
					url: ajax_object.ajax_url,
					data: {
						action: 'get_address_ajax',
						ssn: ssn,
					}
				}).done(function (data) {
					data = $.parseJSON(data);
					var info = data.return;
					this.ssnP = $('p[class="form-row ssn form-row-wide woocommerce-validated"]');
					this.ssnInput = this.ssnP.find('input');

					if ( typeof data.errorTypeId != 'undefined' ) {
						var form = $('form[name="checkout"]');
						var tempSpan = $('<span></span>', {
							'class': 'ssn-error-message',
							'text': data.userErrorMessage
						});
						//"form-row form-row-first validate-required woocommerce-invalid woocommerce-invalid-required-field"
						
						this.ssnP.append(tempSpan);
						this.ssnInput.css('border-color', '#fb7f88');
						this.ssnErrorTimeout = window.setTimeout(function () {
							$('.ssn-error-message').fadeOut('slow', function () {
								$(this.parent).find('input').css('border-color', '');
								$(this).remove();
							});
							$('p[class="form-row ssn form-row-wide woocommerce-validated"]').find('input').css('border-color', '');
						}, 5000);
					} else {
						$('.ssn-error-message').remove();
						this.ssnInput.css('border-color', '');
						$("#billing_first_name").val(info.firstName);
						$("#billing_last_name").val(info.lastName);
						$("#billing_address_1").val(info.addressRow1);
						$("#billing_postcode").val(info.postalCode);
						$("#billing_city").val(info.postalArea);
						$("#applicant-government-id").val($('#ssn_field').val());
					}

					$('form[name="checkout"]').unblock();
				});
			},

			remove_first_checkout_button: function () {

				$( '.checkout-button' ).each( function( index, value ) {

					var $value = $( value );

					if ( ! $value.hasClass( 'second-checkout-button' ) )
						$value.hide();
				});
			}
		};

		$( document ).ready( function( $ ) {
			woocommerce_resurs_bank.init();
		} );
	} );
}
























