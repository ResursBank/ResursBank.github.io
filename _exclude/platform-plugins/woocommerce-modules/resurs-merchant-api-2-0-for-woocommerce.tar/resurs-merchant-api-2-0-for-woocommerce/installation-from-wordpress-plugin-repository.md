---
layout: page
title: Installation From Wordpress Plugin Repository
nav_exclude: true
permalink: /platform-plugins/woocommerce/resurs-merchant-api-2-0-for-woocommerce/installation-from-wordpress-plugin-repository/
parent: Resurs Merchant Api 2.0 For Woocommerce
grand_parent: Woocommerce
---



# Installation from WordPress plugin repository 
This page contains information about how to install the plugin properly.

The official release is located at
[https://www.wordpress.org/plugins/resurs-bank-payments-for-woocommerce/](https://www.wordpress.org/plugins/resurs-bank-payments-for-woocommerce/)
and can be installed directly from the plugin installation system in
WordPress.

![](../../../../attachments/91029967/91030037.png)

