<?php

if (!class_exists("resurs_setInvoiceDataResponse", false)) 
{
class resurs_setInvoiceDataResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
