<?php

if (!class_exists("resurs_registerEventCallbackResponse", false)) 
{
class resurs_registerEventCallbackResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
