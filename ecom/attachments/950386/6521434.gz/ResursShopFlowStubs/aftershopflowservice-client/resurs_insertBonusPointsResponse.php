<?php

if (!class_exists("resurs_insertBonusPointsResponse", false)) 
{
class resurs_insertBonusPointsResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
