<?php

if (!class_exists("resurs_paymentDiffType", false)) 
{
class resurs_paymentDiffType
{
    const __default = 'AUTHORIZE';
    const AUTHORIZE = 'AUTHORIZE';
    const DEBIT = 'DEBIT';
    const CREDIT = 'CREDIT';
    const ANNUL = 'ANNUL';


}

}
