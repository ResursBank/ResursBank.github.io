<?php

if (!class_exists("resurs_addMetaDataResponse", false)) 
{
class resurs_addMetaDataResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
