<?php

if (!class_exists("resurs_invoiceDeliveryTypeEnum", false)) 
{
class resurs_invoiceDeliveryTypeEnum
{
    const __default = 'NONE';
    const NONE = 'NONE';
    const EMAIL = 'EMAIL';
    const POSTAL = 'POSTAL';


}

}
