<?php

if (!class_exists("resurs_paymentMethodType", false)) 
{
class resurs_paymentMethodType
{
    const __default = 'INVOICE';
    const INVOICE = 'INVOICE';
    const REVOLVING_CREDIT = 'REVOLVING_CREDIT';
    const CARD = 'CARD';
    const PAYMENT_PROVIDER = 'PAYMENT_PROVIDER';


}

}
