<?php

if (!class_exists("resurs_invalidateCustomerIdentificationTokenResponse", false)) 
{
class resurs_invalidateCustomerIdentificationTokenResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
