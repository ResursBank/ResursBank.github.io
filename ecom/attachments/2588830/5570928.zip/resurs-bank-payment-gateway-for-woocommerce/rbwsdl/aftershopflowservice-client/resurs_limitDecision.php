<?php

if (!class_exists("resurs_limitDecision", false)) 
{
class resurs_limitDecision
{
    const __default = 'DENIED';
    const DENIED = 'DENIED';
    const GRANTED = 'GRANTED';
    const TRIAL = 'TRIAL';


}

}
