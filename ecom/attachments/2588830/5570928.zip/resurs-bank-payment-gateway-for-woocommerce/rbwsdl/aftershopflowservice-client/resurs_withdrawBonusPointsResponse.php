<?php

if (!class_exists("resurs_withdrawBonusPointsResponse", false)) 
{
class resurs_withdrawBonusPointsResponse
{

    /**
     * @access public
     */
    public function __construct()
    {
    
    }

}

}
