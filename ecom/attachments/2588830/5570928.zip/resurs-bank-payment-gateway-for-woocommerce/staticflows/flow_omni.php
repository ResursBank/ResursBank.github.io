<?php

/**
 * Static Payment Flow: OmniCheckout
 *
 * Class WC_Resurs_Bank_Omni
 */
class WC_Gateway_ResursBank_Omni extends WC_Resurs_Bank {

    /**
     * WC_Resurs_Bank_Omni constructor (simplified)
     * Enabling is not controlled from this class.
     */
    public function __construct() {
        $this->id = "resurs_bank_omnicheckout";
        $this->method_title = "Resurs Bank Omnicheckout";
        $this->has_fields = true;

        $icon_name = "resurs-standard";
        $path_to_icon = $this->icon = apply_filters( 'woocommerce_resurs_bank_checkout_icon',  $this->plugin_url() . '/img/' . $icon_name . '.png');
        $temp_icon = plugin_dir_path( __FILE__ ) . 'img/' . $icon_name . '.png';
        $has_icon = (string)file_exists($temp_icon);

        $this->has_icon();
        $this->init_form_fields();
        $this->init_settings();
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');


        if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
        } else {
            add_action( 'woocommerce_update_options_payment_gateways', array( $this, 'process_admin_options' ) );
        }
        //add_action( 'woocommerce_api_resurs_bank_omnicheckout', array( $this, 'check_signing_response' ) );
    }

    /**
     * There is a slight different design for this method since it's enabled through the choice of flow from Resurs primary configuration.
     * Very few settings are configured from here.
     */
    function admin_options()
    {
        ?>
        <table class="form-table">
            <h2>Custom shopFlow - <?php echo $this->method_title; ?></h2>
            <h3>Status: <?php echo hasResursOmni() ? __("Enabled") : __("Disabled"); ?></h3>
        <?php
        $this->generate_settings_html();
        ?>
        </table>
            <?php
    }

    function init_form_fields()
    {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Enable/Disable', 'woocommerce'),
                'type'  => 'checkbox',
                'label' => 'Aktivera Resurs Bank Faktura privat',
            ),
            'title' => array(
                'title'       => 'Title',
                'type'        => 'text',
                'default'     => 'Resurs Bank Omnicheckout',
                'description' => __( 'This controls the payment method title which the user sees during checkout.', 'woocommerce' ),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => 'Description',
                'type'        => 'textarea',
                'default'     => 'Betala med OmniCheckout (Resurs Bank)',
                'description' => __( 'This controls the payment method description which the user sees during checkout.', 'woocommerce' ),
                'desc_tip'    => true,
            ),
        );
    }

    /*
     * Imports
     */

    public function calculate_totals($totals) {
        global $woocommerce;
    }
    public function add_payment_gateway_extra_charges_row() {
        // Not in use at this position, since everything is handled externally
    }
    public function payment_fields()
    {
        echo '<div id="omni-checkout-container">' . $this->resurs_omnicheckout_create_frame() . "</div>";
    }

    public function get_current_gateway() {
        global $woocommerce;
        $available_gateways = $woocommerce->payment_gateways->get_available_payment_gateways();
        $current_gateway = null;
        $default_gateway = get_option( 'woocommerce_default_gateway' );
        if ( ! empty( $available_gateways ) ) {

            // Chosen Method
            if ( isset( $woocommerce->session->chosen_payment_method ) && isset( $available_gateways[ $woocommerce->session->chosen_payment_method ] ) ) {
                $current_gateway = $available_gateways[ $woocommerce->session->chosen_payment_method ];
            } elseif ( isset( $available_gateways[ $default_gateway ] ) ) {
                $current_gateway = $available_gateways[ $default_gateway ];
            } else {
                $current_gateway = current( $available_gateways );
            }
        }
        if ( ! is_null( $current_gateway ) )
            return $current_gateway;
        else
            return false;
    }

    public function has_icon() {}
    public static function interfere_checkout_process($posted) {}

}

if (hasResursOmni()) {
    function woocommerce_add_resurs_bank_omnicheckout($methods)
    {
        if (!resursOption('enabled')) {
            return $methods;
        }
        global $woocommerce;
        if (defined('INCLUDE_RESURS_OMNI') && INCLUDE_RESURS_OMNI) {
            $methods[] = "WC_Gateway_ResursBank_Omni";
        }
        return $methods;
    }
    add_filter('woocommerce_payment_gateways', 'woocommerce_add_resurs_bank_omnicheckout', 0);
}