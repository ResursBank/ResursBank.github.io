<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Entity;

// NOTE: Do not remove this import statement, it's required for the docblock parser to work!
use Doctrine\ORM\Mapping as ORM;
use InvalidArgumentException;

/**
 * NOTE: This class is named in a weird way to make sure it works with
 * Prestashop's internal Entity -> Table mapping
 * (Entity model -> _DB_PREFIX_ . [entity model class in snake casing]).
 *
 * @ORM\Table()
 * @ORM\Entity()
 * @ORM\HasLifecycleCallbacks()
 */
class ResursbankOrder
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer", name="id", nullable=false, scale=10, options={"unsigned":true})
     */
    private int $id;

    /**
     * @ORM\Column(type="integer", name="order_id", nullable=false, scale=10, options={"unsigned":true})
     */
    private int $orderId;

    /**
     * @ORM\Column(type="boolean", nullable=false, length=1)
     */
    private bool $test;

    /**
     * @ORM\Column(type="boolean", nullable=false, length=1, options={"default": 0})
     */
    private bool $readyForCallback;

    /**
     * @ORM\Column(type="string", name="mapi_id", nullable=true, length=36)
     */
    private ?string $mapiId;

    public function setId(int $id): ResursbankOrder
    {
        $this->id = $id;
        return $this;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getOrderId(): int
    {
        return $this->orderId;
    }

    public function getReadyForCallback(): bool
    {
        return $this->readyForCallback;
    }

    public function setReadyForCallback(bool $ready): ResursbankOrder
    {
        $this->readyForCallback = $ready;

        return $this;
    }

    public function setOrderId(int $orderId): ResursbankOrder
    {
        if ($orderId === 0) {
            throw new InvalidArgumentException('Order ID not supplied.');
        }

        $this->orderId = $orderId;

        return $this;
    }

    public function getTest(): bool
    {
        return $this->test ?? false;
    }

    public function setTest(
        bool $test
    ): ResursbankOrder {
        $this->test = $test;

        return $this;
    }

    public function getMapiId(): ?string
    {
        return $this->mapiId;
    }

    public function setMapiId(
        ?string $value
    ): ResursbankOrder {
        $this->mapiId = $value;

        return $this;
    }
}
