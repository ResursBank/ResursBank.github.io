<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Exception;

use PrestaShopException;

/**
 * Indicates a general data problem.
 */
class ContextException extends PrestaShopException
{
}
