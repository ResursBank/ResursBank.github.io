<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Controller\Admin\Order;

use Db;
use Exception;
use OrderPayment;
use PrestaShopException;
use Resursbank\Ecom\Lib\Utilities\Price;
use Resursbank\Ecom\Module\Payment\Repository;
use Resursbank\MerchantApi\Exception\PaymentException;
use Resursbank\MerchantApi\Service\Order;
use Resursbank\MerchantApi\Util\Log;
use Resursbank\MerchantApi\Util\Translator;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Capture entire, remaining, payment at Resurs Bank.
 */
class Capture extends Aftershop
{
    /**
     * Capture payment.
     */
    public function execute(Request $request): RedirectResponse
    {
        try {
            $order = $this->getOrder(request: $request);
            $payment = $this->getMapiPayment(request: $request);

            if (!$payment->canCapture() ||
                !Order::isResursbank(orderReference: $order->reference)
            ) {
                throw new PaymentException(
                    message: Translator::translate('payment-cannot-be-captured')
                );
            }

            $payment2 = Repository::capture(paymentId: $payment->id);
            $capturedAmount = $payment2->order->capturedAmount - $payment->order->capturedAmount;

            $this->session->getFlashBag()->add(
                type: 'success',
                message: sprintf(
                    Translator::translate('capture-success'),
                    Price::format($capturedAmount)
                )
            );

            $this->setOrderStatus(request: $request, status: Order::ORDER_STATE_PAID);

            // Create invoice in PrestaShop to reflect captured amount.
            Order::createInvoice(
                payment: $payment2,
                order: $this->getOrder(request: $request),
                capturedAmount: $capturedAmount
            );
        } catch (Exception $e) {
            Log::error(message: $e);
            $this->session->getFlashBag()->add(
                type: 'error',
                message: Translator::translate('failed-to-capture-payment') . ' (' . $e->getMessage() . ')'
            );
        }

        return $this->redirectBack();
    }
}
