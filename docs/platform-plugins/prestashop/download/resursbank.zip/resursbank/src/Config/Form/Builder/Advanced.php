<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Config\Form\Builder;

use PrestaShopBundle\Form\Admin\Type\SwitchType;
use Resursbank\MerchantApi\Util\Translator;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;

/**
 * Generates the form containing advanced settings on config page.
 */
class Advanced extends AbstractType
{
    /**
     * {@inheritdoc}
     *
     * @noinspection PhpMissingParentCallCommonInspection
     */
    public function buildForm(
        FormBuilderInterface $builder,
        array $options
    ): void {
        $builder
            ->add('debug', SwitchType::class, [
                'required' => false,
                'label' => Translator::translate('log-enabled'),
                'help' => '_PS_ROOT_DIR_/var/logs/ecom.log',
            ]);
    }

    /**
     * {@inheritdoc}
     *
     * @noinspection PhpMissingParentCallCommonInspection
     */
    public function getBlockPrefix(): string
    {
        return 'resursbank_merchantapi_advanced';
    }
}
