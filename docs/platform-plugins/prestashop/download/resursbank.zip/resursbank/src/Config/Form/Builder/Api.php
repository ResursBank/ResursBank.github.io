<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Config\Form\Builder;

use PrestaShopBundle\Form\Admin\Type\SwitchType;
use Resursbank\Ecom\Lib\Api\Environment;
use Resursbank\Ecom\Module\Store\Repository;
use Resursbank\MerchantApi\Util\Log;
use Resursbank\MerchantApi\Util\Translator;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ButtonType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Throwable;

/**
 * Generates the form containing API settings on config page.
 */
class Api extends AbstractType
{
    /**
     * {@inheritdoc}
     *
     * @noinspection PhpMissingParentCallCommonInspection
     */
    public function buildForm(
        FormBuilderInterface $builder,
        array $options
    ): void {
        $test = Environment::TEST->value;
        $prod = Environment::PROD->value;

        $builder
            ->add('environment', ChoiceType::class, [
                'label' => Translator::translate('environment'),
                'choices' => [
                    'Test' => $test,
                    'Production' => $prod,
                ],
                'required' => false,
            ])
            ->add('store_id', ChoiceType::class, [
                'label' => Translator::translate('store-id'),
                'choices' => $this->getStoreChoices(),
                'required' => false,
            ])
            ->add('fetch_stores', ButtonType::class, [
                'label' => Translator::translate('fetch-stores'),
            ])
            ->add("client_id_$test", TextType::class, [
                'label' => Translator::translate('client-id'),
                'required' => false,
            ])
            ->add("client_secret_$test", PasswordType::class, [
                'label' => Translator::translate('client-secret'),
                'required' => false,
            ])
            ->add("client_id_$prod", TextType::class, [
                'label' => Translator::translate('client-id'),
                'required' => false,
            ])
            ->add("client_secret_$prod", PasswordType::class, [
                'label' => Translator::translate('client-secret'),
                'required' => false,
            ])->add('aftershop_enabled', SwitchType::class, [
                'required' => false,
                'label' => Translator::translate('order-management')
            ]);;
    }

    /**
     * {@inheritdoc}
     *
     * @noinspection PhpMissingParentCallCommonInspection
     */
    public function getBlockPrefix(): string
    {
        return 'resursbank_merchantapi_api';
    }

    public static function getStoreChoices(): array
    {
        $result = [];

        try {
            foreach (Repository::getStores() as $store) {
                // PrestaShop form rendering expects definition in reverse
                // order, name => id instead of id => name.
                $result[$store->name] = $store->id;
            }
        } catch (Throwable $error) {
            Log::error(message: $error);
        }

        return $result;
    }
}
