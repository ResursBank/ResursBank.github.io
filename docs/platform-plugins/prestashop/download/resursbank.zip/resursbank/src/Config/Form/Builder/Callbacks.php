<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Config\Form\Builder;

use PrestaShop\PrestaShop\Core\ConstraintValidator\Constraints\PositiveOrZero;
use Symfony\Component\Form\Extension\Core\Type\ButtonType;
use Resursbank\MerchantApi\Util\Translator;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;

/**
 * Add elements to the callback section of the config form.
 */
class Callbacks extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @return void
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add(
                child: 'callback_test',
                type: ButtonType::class,
                options: [
                    'label' => Translator::translate(phraseId: 'test-callbacks')
                ]
            )->add(child: 'ttl', type: TextType::class, options: [
                'required' => false,
                'constraints' => [new PositiveOrZero()],
                'label' => Translator::translate(phraseId: 'callback-ttl')
            ]);
    }
}
