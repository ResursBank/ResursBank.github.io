<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Service;

use mysqli_result;
use PDOStatement;

/**
 * Database related helper methods.
 */
class Database
{
    /**
     * Resolve records from SQL query as array.
     *
     * This method is required because the native method to fetch multiple rows from the database has been deprecated
     * by PrestaShop team since version 1.5.x, and no other means are available to resolve multiple records through
     * frontend repository integrations.
     *
     * @param PDOStatement|mysqli_result|resource|bool|null $result
     * @return array
     */
    public static function getAll(mixed $result): array
    {
        if ($result instanceof PDOStatement) {
            return $result->fetchAll();
        }

        if ($result instanceof mysqli_result) {
            return $result->fetch_all(MYSQLI_ASSOC);
        }

        return [];
    }
}
