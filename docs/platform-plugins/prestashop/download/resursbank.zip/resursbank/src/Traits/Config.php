<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Traits;

use InvalidArgumentException;

/**
 * Common configuration related methods relevant for all modules.
 */
trait Config
{
    /**
     * Returns configuration name.
     *
     * @param string $key
     *
     * @return string
     */
    public function getId(
        string $key
    ): string {
        if ($key === '') {
            throw new InvalidArgumentException(
                'Please supply configuration value key.'
            );
        }

        return strtoupper("RESURSBANK_$key");
    }
}
