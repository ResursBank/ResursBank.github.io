<?php // phpcs:disable PSR1.Files.SideEffects.FoundWithSymbols

/*
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

use Resursbank\Ecom\Module\Widget\ReadMore\Js as ReadMoreJs;
use Resursbank\MerchantApi\Util\Log;

/**
 * Wrapper class for Read More widget javascript.
 */
// phpcs:disable
class ResursbankReadMoreModuleFrontController extends ModuleFrontController
// phpcs:enable
{
    /** @var int */
    public $ajax = 0;

    /**
     * Output widget JS.
     *
     * @return void
     */
    public function display(): void
    {
        try {
            $container = (string)Tools::getValue(key: 'container');
            $widget = new ReadMoreJs(
                containerElDomPath: $container
            );
            $this->ajaxRender(value: $widget->content);
            return;
        } catch (Throwable $error) {
            Log::error(message: $error);
        }

        http_response_code(response_code: 500);
    }
}
