<?php // phpcs:disable PSR1.Files.SideEffects.FoundWithSymbols

/** @noinspection PhpCSValidationInspection */

/*
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

use Resursbank\MerchantApi\Service\CallbackTest;
use Resursbank\MerchantApi\Service\FakeContainer;
use Resursbank\MerchantApi\Util\Log;

/**
 * Handles incoming callback tests.
 */
// phpcs:disable
class ResursbankCallbacktestModuleFrontController extends ModuleFrontController
// phpcs:enable
{
    /**
     * @return void
     */
    public function postProcess(): void
    {
        try {
            $fakeContainer = new FakeContainer();
            $callbackTest = new CallbackTest(
                config: $fakeContainer->getConfig()
            );

            $callbackTest->registerTestReceived();
        } catch (Throwable $error) {
            Log::error(message: $error);
        }
    }
}
