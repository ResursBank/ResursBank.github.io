<?php // phpcs:disable PSR1.Files.SideEffects.FoundWithSymbols

/** @noinspection PhpCSValidationInspection */

/*
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

use Resursbank\Ecom\Exception\HttpException;
use Resursbank\Ecom\Lib\Model\Callback\Authorization as AuthorizationModel;
use Resursbank\Ecom\Lib\Model\Callback\CallbackInterface;
use Resursbank\Ecom\Lib\Model\Callback\Enum\Status as CallbackStatus;
use Resursbank\Ecom\Module\Callback\Http\AuthorizationController;
use Resursbank\Ecom\Module\Callback\Repository;
use Resursbank\Ecom\Module\Payment\Repository as PaymentRepository;
use Resursbank\MerchantApi\Repository\ResursbankOrderRepositoryFrontend;
use Resursbank\MerchantApi\Service\Order as OrderService;
use Resursbank\MerchantApi\Util\Log;
use Resursbank\MerchantApi\Util\Translator;

// phpcs:disable
class ResursbankAuthorizationModuleFrontController extends ModuleFrontController
// phpcs:enable
{
    public function postProcess(): void
    {
        try {
            $callback = (new AuthorizationController())->getRequestData();

            if ($callback->paymentId === '') {
                throw new HttpException(
                    __('rb-callback-error-no-resource-id')->getText()
                );
            }

            $order = ResursbankOrderRepositoryFrontend::getOrderByMapiId(
                $callback->paymentId
            );

            if ($order === null) {
                throw new HttpException(
                    message: Translator::translate('rb-callback-error-order-not-found'),
                    code: 503
                );
            }

            if (!Repository::isReady(paymentId: $callback->paymentId)) {
                throw new HttpException(
                    message: Translator::translate('rb-called-error-order-not-ready'),
                    code: 503
                );
            }

            $code = Repository::process(
                callback: $callback,
                process: static function (
                    CallbackInterface $callback
                ): void {
                    if (!($callback instanceof AuthorizationModel)) {
                        return;
                    }

                    $payment = PaymentRepository::get($callback->paymentId);
                    $order = ResursbankOrderRepositoryFrontend::getOrderByMapiId(
                        $callback->paymentId
                    );

                    // If callback is REJECTED cancel the order.
                    if ($callback->status === CallbackStatus::REJECTED) {
                        OrderService::cancel(order: $order);
                        return;
                    }

                    // Update order status to "paid" if payment is captured and
                    // add payment to order.
                   if ($payment->isCaptured()) {
                        $order->addOrderPayment(
                            $payment->order->capturedAmount,
                            $payment->paymentMethod->name,
                            $payment->id
                        );
                    }

                    $order->save();
                }
            );
        } catch (Throwable $error) {
            $code = 503;
            Log::error(message: $error);
        }

        http_response_code($code);
        exit;
    }
}
