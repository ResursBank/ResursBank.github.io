/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

let RB_PP_WIDGET_INSTANCE = null;

document.addEventListener('DOMContentLoaded', function () {
  if (typeof Resursbank_PartPayment !== 'function') {
    return;
  }

  const overrides = {
    getObservableElements: function () {
      return [this.getQtyElement()];
    },

    getQtyElement: function() {
      return document.querySelector('#quantity_wanted');
    },

    getAmountElement: function () {
      return document.querySelector('.current-price .current-price-value');
    }
  }

  RB_PP_WIDGET_INSTANCE = Resursbank_PartPayment.createInstance(
      document.getElementById('rb-pp-widget-container'),
      overrides
  );
});
