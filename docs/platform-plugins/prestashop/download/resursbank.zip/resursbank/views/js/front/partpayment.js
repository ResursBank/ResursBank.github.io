/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

let RB_PP_WIDGET_INSTANCE = null;

document.addEventListener('DOMContentLoaded', function () {
  if (typeof Resursbank_PartPayment !== 'function') {
    return;
  }

  const overrides = {
    getObservableElements: function () {
      let result = [this.getQtyElement()];

      let qtyBtns = document.querySelectorAll('.product-add-to-cart button.btn');

      // If there are no quantity buttons, append them to the observable elements.
      if (qtyBtns.length > 0) {
        qtyBtns.forEach(function (btn) {
          result.push(btn);
        });
      }

      return result;
    },

    getQtyElement: function() {
      return document.querySelector('#quantity_wanted');
    },

    getAmountElement: function () {
      return document.querySelector('.current-price .current-price-value');
    }
  }

  RB_PP_WIDGET_INSTANCE = Resursbank_PartPayment.createInstance(
      document.getElementById('rb-pp-widget-container'),
      overrides
  );

  // Pick up all .rb-pp-widget-container elements, and move them to up to the
  // parent element.
  const containers = document.querySelectorAll('.rb-pp-widget-container');
  containers.forEach(function (container) {
    // Insert container after parent.
    container.parentElement.insertAdjacentElement('afterend', container);

    // Display the container again.
    container.style.display = 'block';
  });

  // Reload widget instance when the DOM of .product-add-to-cart changes.
  const productAddToCart = document.querySelector('.product-add-to-cart');
  if (productAddToCart) {
    const observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        if (mutation.type === 'childList') {
          RB_PP_WIDGET_INSTANCE.reloadElementObservers();
        }
      });
    });

    observer.observe(productAddToCart, {
      childList: true,
      subtree: true
    });
  }
});
