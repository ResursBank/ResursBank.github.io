CREATE TABLE IF NOT EXISTS `[PREFIX]resursbank_payment_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Prim Key',
  `resursbank_order_id` int(10) unsigned NOT NULL COMMENT 'Order reference.',
  `event` varchar(255) NOT NULL COMMENT 'Event that was triggered.',
  `user` varchar(255) NOT NULL COMMENT 'User that triggered the event.',
  `extra` text NULL COMMENT 'Additional information about what happened.',
  `status_from` varchar(255) NULL COMMENT 'What status the payment went from.',
  `status_to` varchar(255) NULL COMMENT 'What status the payment went to.',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Created At',
  `result` varchar(255) NULL COMMENT 'Event result, e.g. success, failure, info. Only used by Ecom widget.',
  `user_reference` varchar(255) NULL COMMENT 'Admin username or similar. Only used by Ecom widget.',
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_RB_PH_RB_ORDER` FOREIGN KEY (`resursbank_order_id`) REFERENCES `[PREFIX]resursbank_order` (`id`) ON DELETE CASCADE
) CHARSET=utf8 COMMENT='Resurs Bank Payment History';
