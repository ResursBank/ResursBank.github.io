CREATE TABLE IF NOT EXISTS `[PREFIX]resursbank_order` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Prim Key',
    `order_id` int(10) unsigned NOT NULL COMMENT 'Order reference.',
    `test` tinyint(1) unsigned NOT NULL COMMENT 'Whether the purchase was conducted in test.',
    `ready_for_callback` tinyint(1) unsigned NOT NULL COMMENT 'Indicates whether order is ready to accept callbacks',
    `mapi_id` varchar(36) NULL DEFAULT NULL COMMENT 'MAPI payment UUID',
    PRIMARY KEY (`id`),
    CONSTRAINT `FK_RB_ORDER_ORDER` FOREIGN KEY (`order_id`) REFERENCES `[PREFIX]orders` (`id_order`) ON DELETE CASCADE,
    UNIQUE (`order_id`)
) CHARSET=utf8 COMMENT='Resurs Bank Order Data Table';
