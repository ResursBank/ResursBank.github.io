<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

namespace Resursbank\MerchantApi\Hook;

use Context;
use Exception;
use Product;
use Resursbank\Ecom\Module\PriceSignage\Widget\CostList;
use Resursbank\Ecom\Module\PriceSignage\Widget\CostListJs;
use Resursbank\MerchantApi\Exception\FakeContainerException;
use Resursbank\MerchantApi\Service\PartPayment;
use Resursbank\MerchantApi\Service\FakeContainer;
use Resursbank\MerchantApi\Util\Log;
use Throwable;
use Tools;
use Validate;

/**
 * Add stylesheet to header.
 */
class DisplayHeader
{
    private static $context;
    private static string $path;

    /**
     * @param Context $context
     * @param string $path
     * @return void
     * @throws FakeContainerException
     */
    public static function exec(Context $context, string $path)
    {
        self::$path = $path;
        self::$context = $context;

        self::renderCheckoutAssets();
        self::renderPartPaymentAssets();
    }

    /**
     * @return void
     */
    private static function renderCheckoutAssets(): void
    {
        if (self::$context->controller->php_self === 'order') {
            // Add checkout CSS.
            self::$context->controller->registerStylesheet(
                id: 'rb-checkout',
                relativePath: self::$path . 'views/css/front/checkout.css',
                params: [
                    // @todo version should be resolved as md5 of file content.
                    'version' => '1.0.0',
                ]
            );

            // Add checkout JS.
            self::$context->controller->registerJavascript(
                id: 'rb-checkout',
                relativePath: self::$path . 'views/js/front/checkout.js',
                params: [
                    // @todo version should be resolved as md5 of file content.
                    'version' => '1.0.0',
                ]
            );

            $dynamicCostListCss = CostList::getCss();
            self::$context->controller->registerStylesheet(
                'dynamic-cost-list-css',
                'data:text/css;base64,' . base64_encode($dynamicCostListCss),
                ['media' => 'all', 'priority' => 150, 'server' => 'remote']
            );

            $costListJs = (new CostListJs('body'))->content;
            self::$context->controller->registerJavascript(
                'dynamic-cost-list-js',
                'data:text/javascript;base64,' . base64_encode($costListJs),
                ['position' => 'head', 'priority' => 150, 'server' => 'remote']
            );

            $readMoreJsLink = self::$context->link->getModuleLink(
                module: 'resursbank',
                controller: 'readmore',
                params: ['container' => '#checkout-payment-step']
            );
            self::$context->controller->registerJavascript(
                id: 'resursbank-readmore',
                relativePath: $readMoreJsLink,
                params: ['media' => 'all', 'priority' => 150, 'server' => 'remote']
            );
        }
    }

    /**
     * @return void
     * @throws FakeContainerException
     */
    private static function renderPartPaymentAssets(): void
    {
        $config = FakeContainer::getConfig();

        if (self::$context->controller->php_self === 'product' &&
            $config->getPartPaymentEnabled()
        ) {
            try {
                $product = new Product((int) Tools::getValue('id_product'));

                if (!Validate::isLoadedObject($product)) {
                    throw new Exception('Product not found');
                }

                $widget = PartPayment::getWidget(
                    context: self::$context,
                    amount: (float) $product->price
                );

                self::$context->controller->registerJavascript(
                    'rb-pp-widget',
                    'data:text/javascript;base64,' . base64_encode($widget->js),
                    ['position' => 'head', 'priority' => 150, 'server' => 'remote']
                );
            } catch (Throwable $error) {
                Log::error(message: $error);
            }

            $readMoreJsLink = self::$context->link->getModuleLink(
                module: 'resursbank',
                controller: 'readmore',
                params: ['container' => '#rb-pp-widget-container']
            );
            self::$context->controller->registerJavascript(
                id: 'resursbank-readmore',
                relativePath: $readMoreJsLink,
                params: ['media' => 'all', 'priority' => 150, 'server' => 'remote']
            );

            self::$context->controller->registerJavascript(
                id: 'resursbank-partpayment-overrides',
                relativePath: self::$path . 'views/js/front/partpayment.js'
            );
        }
    }
}
