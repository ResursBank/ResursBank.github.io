<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

namespace Resursbank\MerchantApi\Service;

use Resursbank\Ecom\Config;
use Resursbank\Ecom\Exception\FilesystemException;
use Resursbank\Ecom\Exception\Validation\EmptyValueException;
use Resursbank\Ecom\Exception\Validation\FormatException;
use Resursbank\Ecom\Lib\Api\Environment;
use Resursbank\Ecom\Lib\Api\GrantType;
use Resursbank\Ecom\Lib\Api\Scope;
use Resursbank\Ecom\Lib\Log\FileLogger;
use Resursbank\Ecom\Lib\Model\Network\Auth\Jwt;
use Resursbank\MerchantApi\Config\Config as PrestaConfig;
use Resursbank\MerchantApi\Util\Log;
use Throwable;

class Ecom
{
    public function __construct(
        private readonly PrestaConfig $config
    ) {
    }

    /**
     * Configure Ecom.
     *
     * NOTE: This cannot be placed in the constructor since that requires the
     * container (for DI) and our classes haven't been loaded yet at that time.
     *
     * @throws EmptyValueException
     * @throws FilesystemException
     * @throws FormatException
     */
    public function configure(): void
    {
        $env = $this->config->getEnvironment();

        $jwt = null;
        try {
            // Only create JWT if client ID and secret are set.
            // Log all other errors.
            if ($this->config->getClientId(environment: $env) !== '') {
                $jwt = new Jwt(
                    clientId: $this->config->getClientId(environment: $env),
                    clientSecret: $this->config->getClientSecret(environment: $env),
                    grantType: GrantType::CREDENTIALS,
                    scope: $env === Environment::PROD ?
                        Scope::MERCHANT_API :
                        Scope::MOCK_MERCHANT_API
                );
            }
        } catch (Throwable $jwtException) {
            // Log the error and continue with the default configuration.
            Log::error(
                message: 'Failed to create JWT: ' . $jwtException->getMessage(),
            );
        }

        Config::setup(
            logger: new FileLogger(
                path: _PS_ROOT_DIR_ . '/var/logs'
            ),
            jwtAuth: $jwt,
            paymentHistoryDataHandler: new PaymentHistory(),
            storeId: $this->config->getStoreId(),
            isProduction: $env === Environment::PROD,
        );
    }
}
