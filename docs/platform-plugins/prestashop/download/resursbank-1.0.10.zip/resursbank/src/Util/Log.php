<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Util;

use Resursbank\Ecom\Config;
use Resursbank\Ecom\Exception\ConfigException;
use Throwable;

/**
 * Log wrapper.
 */
class Log
{
    /**
     * Wrapper to handle ConfigException
     */
    public static function error(string|Throwable $message): void
    {
        try {
            Config::getLogger()->error(message: $message);
        } catch (ConfigException $e) {
            // @todo Implement alternative error handling.
            // @todo Check the Controller\Admin\Config\Save controller. Maybe we can flash in admin at least?
        }
    }

    public static function info(string|Throwable $message): void
    {
        try {
            Config::getLogger()->info(message: $message);
        } catch (ConfigException $e) {
            // @todo Implement alternative error handling.
            // @todo Check the Controller\Admin\Config\Save controller. Maybe we can flash in admin at least?
        }
    }

    public static function debug(string|Throwable $message): void
    {
        try {
            Config::getLogger()->debug(message: $message);
        } catch (ConfigException $e) {
            // @todo Implement alternative error handling.
            // @todo Check the Controller\Admin\Config\Save controller. Maybe we can flash in admin at least?
        }
    }
}
