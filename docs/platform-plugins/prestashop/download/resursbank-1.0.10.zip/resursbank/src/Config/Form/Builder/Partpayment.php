<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Config\Form\Builder;

use PrestaShop\PrestaShop\Core\ConstraintValidator\Constraints\PositiveOrZero;
use PrestaShopBundle\Form\Admin\Type\SwitchType;
use Resursbank\MerchantApi\Util\Translator;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;

/**
 * Add elements to the part payment section of the config form.
 */
class Partpayment extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     * @return void
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add(child: 'enabled', type: SwitchType::class, options: [
                'required' => false,
                'label' => Translator::translate(phraseId: 'enabled')
            ])
            ->add(child: 'payment_method', type: ChoiceType::class, options: [
                'required' => false,
                'label' => Translator::translate(phraseId: 'payment-method')
            ])
            ->add(child: 'annuity_period', type: ChoiceType::class, options: [
                'required' => false,
                'label' => Translator::translate(phraseId: 'annuity-period')
            ])
            ->add(child: 'threshold', type: TextType::class, options: [
                'required' => false,
                'constraints' => [new PositiveOrZero()],
                'label' => Translator::translate(phraseId: 'threshold')
            ]);
    }

    /**
     * {@inheritdoc}
     *
     * @noinspection PhpMissingParentCallCommonInspection
     */
    public function getBlockPrefix(): string
    {
        return 'resursbank_merchantapi_partpayment';
    }
}
