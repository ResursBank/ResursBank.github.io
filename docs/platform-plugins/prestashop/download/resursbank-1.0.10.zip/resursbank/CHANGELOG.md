# 1.0.10

* PD-3962 Callback authorization hangs due to loading of failing assets.
* PD-3961 ActionDispatcher improvements by cache (continued from PD-3954).
* PD-3954 Fixed HTTP 503 errors in authorization callbacks by conditionally initializing Ecom at runtime when Config is unavailable.

# 1.0.9

PD-3889 Incorrect order line data sent to Ecom when discounts are applied.
PD-3884 "Read more" is now displayed both in the green box and under repex
PD-3885 Text in the green box at checkout is hard to read.
PD-3857 Character length support via ecom 3.3.10 - patched all widgets up to correct version.
PD-3860 Added plugininfo in user-agent.

# 1.0.8

PD-3877 displayFooter is unreliable for rendering PPW in PS 8 checkout

# 1.0.7

PD-3876 Translation and location issues for others than SE fixed.

# 1.0.6

* PD-3874 Default currency issue.

# 1.0.5

* PD-3862 Order status (still) resets to "Paid" when refreshing the success page after a Swish payment.

# 1.0.4

* PD-3859 When invoice generating is disabled invoice object can't be handled since they are missing.

# 1.0.3

* Changed the way statuses are handled in contrast to payments and direct debits.
* Character length for SKU (hotfix).
* PD-516 Correct cache clearing on installation

# 1.0.2

* PD-3732 Fixed reported bugs from pilot (sub-tasks PD-3734 and PD-3735)
* PD-3486 Misbehaviour after upgrade
* PD-3487 Problem when switching to production (Staffanstorp)
* PD-545 Missing amount in Payment History during order management
* PD-457 Replaces hardcoded value 15000 in DisplayFooter::exec (PPW empty costlist)

# 1.0.1

* PD-460 Merge development into master

# 1.0.0

* PD-527 Investigate caching bug
* PD-474 Set up old Presta with mapimodule
* PD-500 Update the docs and images
* PD-554 Missing green box in order view
* PD-494 PrestaShop Documentation
* PD-453 How can user be prefilled after creating a new instance?
* PD-524 Prestashop installer crashes on reset
* PD-530 Purchase flow in checkout
* PD-504 Cannot perform purchase
* PD-487 Make ECP-980 adjustments
* PD-466 When changing a product attribute which affect pricing, the part payment widget should be updated to reflect
  the new price
* PD-559 Problems on product page with price tag not updating
* PD-565 No update in paymentHistory after modification
* PD-499 Confirm error logging works (php/logs/error.log)
* PD-561 ppw displayed incorrectly for psp in checkout
* PD-447 Missing timeToLiveInMinutes for callbacks, and order cleanup
* PD-522 Missing control of amount range in checkout
* PD-536 PPW is broken
* PD-560 In admin order view the green box does not appear for a resursOrder in status: Redirected to gateway
* PD-570 Costlist readmore in checkout seems to have become unclickable
* PD-528 Images missing in checkout
* PD-518 Revert setLocation
* PD-523 Broken checkout view (with costlist)
* PD-555 Partpayment widget issues
* PD-550 Invisible error classList
* PD-563 Orders failing during create
* PD-488 Centralize shopconstraint due to deprecation warnings
* PD-571 Saving settings in admin has no effect
* PD-541 Status from and to not updating in paymentHistory
* PD-572 Payment History modal not showing in order view
* PD-562 Cannot complete order without using getAddress
* PD-511 Add a save button for each block with settings to update
* PD-547 Fetch address error
* PD-479 Payment history entry to reflect that customer has returned from gateway
* PD-543 Redirecting to checkout notice missing in Payment History
* PD-542 Problem with refunding and ordering
* PD-537 Uninstall / Install issue
* PD-576 Part payment widget in admin panel does not reflect list of payment methods / periods until widget is activated
* PD-463 Automatically create invoice in PS when using direct debit methods like Swish
* PD-501 Default config values
* PD-490 Confirm functionality of purchase/get address logged in/out
* PD-558 Dual transaction records
* PD-529 Incorrect email in checkout cancels order
* PD-476 Add LEGAL support in checkout
* PD-556 Ciphertext has invalid hex encoding
* PD-519 Fix order repo
* PD-577 Module cannot be reset
* PD-478 Uninstaller
* PD-557 You need to install twice
* PD-472 [Discuss] log errors from installer
* PD-469 Separate installer and fix country restrictions
* PD-498 Start development
* PD-497 Callback settings
* PD-509 Cart re-instatement
* PD-484 Partial refunds
* PD-455 Support Info widget
* PD-508 After-shop settings
* PD-452 Cancel
* PD-450 Refunds
* PD-489 QA
* PD-473 Capture
* PD-468 Problems with order status
* PD-507 Authorization callback readiness
* PD-446 Payment history widget
* PD-510 Resurs Bank order check
* PD-464 Payment history data table
* PD-471 Database migration system
* PD-505 Payment method styling
* PD-448 Read more button
* PD-482 Get address widget
* PD-521 Part payment widget
* PD-480 Part payment settings
* PD-520 Module manager logotype
* PD-493 Planning work, create tasks
