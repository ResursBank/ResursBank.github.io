<?php // phpcs:disable PSR1.Files.SideEffects.FoundWithSymbols

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

namespace Resursbank\MerchantApi\Service;

class Autoloader
{
    // @todo Seems useless, move to Event\Autoloader instead.
    public static function load(string $class): void
    {
        $map = [
            'Resursbank\Ecom' => 'lib/ecom/src',
            'Resursbank\MerchantApi' => 'src',
        ];

        foreach ($map as $namespace => $dir) {
            if (str_starts_with(haystack: $class, needle: $namespace)) {
                require _PS_MODULE_DIR_ . '/resursbank/' . $dir .
                    str_replace(
                        search: '\\',
                        replace: '/',
                        subject: substr(
                            string: $class,
                            offset: strlen($namespace)
                        )
                    ) . '.php';
            }
        }
    }
}

spl_autoload_register("Resursbank\MerchantApi\Service\Autoloader::load");
