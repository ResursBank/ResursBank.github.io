<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Util;

use Resursbank\Ecom\Lib\Locale\Translator as EcomTranslator;
use Throwable;

/**
 * Translator wrapper.
 */
class Translator
{
    /**
     * Wrapper to avoid \Resursbank\Ecom\Exception\ConfigException. Defaults to
     * the phrase id and logs the error.
     *
     * @todo Consider moving to Ecom since most implementations want this.
     */
    public static function translate(
        string $phraseId,
        ?string $translationFile = null
    ): string {
        $result = $phraseId;

        try {
            $result = EcomTranslator::translate(
                phraseId: $phraseId,
                translationFile: $translationFile
            );
        } catch (Throwable $e) {
            Log::error(message: $e);
        }

        return $result;
    }
}
