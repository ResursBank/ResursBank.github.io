<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Config\Form;

use PrestaShop\PrestaShop\Core\Form\FormDataProviderInterface;
use PrestaShopBundle\Service\Routing\Router;
use Resursbank\MerchantApi\Config\Form\Builder\Advanced;
use Resursbank\MerchantApi\Config\Form\Builder\Api;
use Resursbank\MerchantApi\Config\Form\Builder\Callbacks;
use Resursbank\MerchantApi\Config\Form\Builder\Partpayment;
use Symfony\Component\Form\FormFactoryInterface;
use Symfony\Component\Form\FormInterface;

/**
 * Configuration form builder.
 */
class Builder
{
    /**
     * @param FormFactoryInterface $formFactory
     * @param FormDataProviderInterface $formDataProvider
     * @param Router $router
     */
    public function __construct(
        private readonly FormFactoryInterface $formFactory,
        private readonly FormDataProviderInterface $formDataProvider,
        private readonly Router $router
    ) {
    }

    /**
     * @return FormInterface
     */
    public function getForm(): FormInterface
    {
        return $this->formFactory->createBuilder()
            ->setData($this->formDataProvider->getData())
            ->add(child: 'api', type: Api::class)
            ->add(child: 'advanced', type: Advanced::class)
            ->add(child: 'callbacks', type: Callbacks::class)
            ->add(child: 'partpayment', type: Partpayment::class)
            ->setAction(
                $this->router->generate(name: 'resursbank_admin_config_save')
            )->getForm();
    }
}
