<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Service;

use Resursbank\Ecom\Module\Callback\Repository;
use Resursbank\MerchantApi\Config\Config;
use Resursbank\MerchantApi\Util\Log;
use Throwable;

/**
 *
 */
class CallbackTest
{
    /**
     * @param Config $config
     */
    public function __construct(
        private readonly Config $config
    ) {
    }

    /**
     * Trigger callback test.
     *
     * @param string $targetUrl
     * @return void
     */
    public function triggerTest(string $targetUrl): void
    {
        try {
            Repository::triggerTest(
                url: $targetUrl
            );

            $this->config->setCallbackTestTriggered();
        } catch (Throwable $error) {
            Log::error(message: $error);
        }
    }

    /**
     * Register callback test received.
     *
     * @return void
     * @throws \Exception
     */
    public function registerTestReceived(): void
    {
        $this->config->setCallbackTestReceived();
    }
}
