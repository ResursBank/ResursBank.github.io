<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\MerchantApi\Config\Form\Builder;

use PrestaShopBundle\Form\Admin\Type\SwitchType;
use Resursbank\MerchantApi\Util\Translator;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;


/**
 * Generates the form containing advanced settings on config page.
 */
class Advanced extends AbstractType
{
    /**
     * {@inheritdoc}
     *
     * @noinspection PhpMissingParentCallCommonInspection
     */
    public function buildForm(
        FormBuilderInterface $builder,
        array $options
    ): void {
        $builder
            ->add(child: 'debug', type: SwitchType::class, options: [
                'required' => false,
                'label' => Translator::translate(phraseId: 'log-enabled'),
                'help' => '_PS_ROOT_DIR_/var/logs/ecom.log',
            ])->add(child: 'xdebug_session', type: TextType::class, options: [
                'label' => 'Xdebug session name',
                'help' => 'Used to activate IDE debugging globally (default: PHPSTORM)',
                'required' => false,
            ]);;
    }

    /**
     * {@inheritdoc}
     *
     * @noinspection PhpMissingParentCallCommonInspection
     */
    public function getBlockPrefix(): string
    {
        return 'resursbank_merchantapi_advanced';
    }
}
