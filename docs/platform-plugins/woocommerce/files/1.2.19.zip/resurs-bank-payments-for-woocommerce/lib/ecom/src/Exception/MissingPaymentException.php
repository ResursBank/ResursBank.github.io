<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\Ecom\Exception;

use Exception;

/**
 * Specifies a payment, or payment identification information, is missing.
 */
class MissingPaymentException extends Exception
{
}
