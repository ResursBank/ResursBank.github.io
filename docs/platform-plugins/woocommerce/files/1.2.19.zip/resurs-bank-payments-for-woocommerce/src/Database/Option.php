<?php

/**
 * Copyright © Resurs Bank AB. All rights reserved.
 * See LICENSE for license details.
 */

declare(strict_types=1);

namespace Resursbank\Woocommerce\Database;

use function is_string;

/**
 * Basic database interface for options in options table.
 */
abstract class Option
{
    /**
     * Name prefix for entries in options table.
     *
     * @noinspection PhpMissingClassConstantTypeInspection
     */
    public const NAME_PREFIX = 'resursbank_';

    /**
     * Resolve data from options table as string, defaults to NULL.
     *
     * @noinspection PhpArgumentWithoutNamedIdentifierInspection
     */
    public static function getRawData(): ?string
    {
        // Temporary workaround: API scope has been removed,
        // so environment (prod/test) must be resolved via request overrides.
        $val = apply_filters('rb_raw_data_config', get_option(
            static::getName(),
            null
        ));

        return is_string(value: $val) ? $val : null;
    }

    /**
     * Sets option data.
     *
     * @noinspection PhpArgumentWithoutNamedIdentifierInspection
     */
    public static function setData(string $value): bool
    {
        return update_option(
            static::getName(),
            $value
        ) === true;
    }
}
